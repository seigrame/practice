using System;
[Serializable]
public class NoFormatData : MsgData
{
    public string title;

    public UInt16 year;
    public byte month;
    public byte day;
    public byte hour;
    public byte minute;

    public string[] lines = new string[7];
}
