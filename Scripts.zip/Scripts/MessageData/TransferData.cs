using System;
using Vtas;
[Serializable]
public class TransferData : MsgData
{
    public string rescuePosition;

    public UInt16 patient;
    public UInt16 stretcher;

    public TransferPriority transferPriority;
    public AreaMark mark;
    public Pollution pollution;
    public MarkColor markColor;
    public AreaSafetyLevel areaSafetyLevel;
    public National national;

    public string note;
}
