using System;
using Vtas;
[Serializable]
public class CBRN_FirstData : MsgData
{
    public CBRNType cbrnType;

    public string myPosition;

    public int myRotation_do;
    public int myRotation_mil;

    public UInt16 atkStartD;
    public UInt16 atkStartH;
    public UInt16 atkStartM;
    public UInt16 atkEndD;
    public UInt16 atkEndH;
    public UInt16 atkEndM;

    public string attackedPosition;

    public Situation situation;

    public Classifications classifications;
    public Property property;
    public Kinds kinds;
    public ExplosionShape explosionShape;

    public FireMethod fireMethod;

    public int NumberOfAmmunition;
    public int NumberOfAircraft;

    public string note;
}
