using System;
using Vtas;
[Serializable]
public class ObstacleData : MsgData
{
    public UInt16 year;
    public byte month;
    public byte day;
    public byte hour;
    public byte minute;

    public string obtaclePosition;
    //�켱����
    public ClassifyEnemies classifyEnemies;

    public ObstacleShape obstacleShape;

    public string numberOfObstacle;
    public string controlNumber;
    public string installUnit;

    public ObstacleBarbedWireType obstacleBarbedWireType;

    public ObstacleMineType obstacleMineType;

    public ObstacleWallType obstacleWallType;

    public ObstacleCategory obstacleCategory;

    public float width;
    public float length;

    public string note;
}
