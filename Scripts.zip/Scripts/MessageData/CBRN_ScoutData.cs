using System;
using System.Collections.Generic;
using Vtas;
[Serializable]
public class CBRN_ScoutData : MsgData
{
    public UInt16 startDay;
    public UInt16 startHour;
    public UInt16 startMin;
    public float radiationRate;
    public Classifications classifications;
    public Property property;
    public Kinds kinds;
    public ExplosionShape explosionShape;
    public CBRNScoutItemData[] scoutItems = new CBRNScoutItemData[6];
    public string note;
}
