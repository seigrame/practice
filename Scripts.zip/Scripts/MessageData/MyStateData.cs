using System;
using Vtas;
[Serializable]
public class MyStateData : MsgData
{
    public UInt16 year;
    public UInt16 month;
    public UInt16 day;
    public UInt16 hour;
    public UInt16 minute;
    public string title;
    //�켱����
    public EnemyPosture enemyPosture;
    public string myPosition;
    //ǥ��
    public EnemyPostureLevel enemyPostureLevel;
    public LastOrder lastOrder;
    //������������
    public string LeftCoord;
    public string RightCoord;
    //�ο�
    public byte combat;
    public byte death;
    public byte injury;

    //ź��
    public byte ammo_h;
    public byte ammo_a;
    public byte ammo_c;
    public byte ammo_s;
    public byte ammo_m;

    public string note;
}
