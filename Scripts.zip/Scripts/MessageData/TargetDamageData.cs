using System;
using Vtas;
[Serializable]
public class TargetDamageData : MsgData
{
    public TargetType targetType;

    public int targetTypeNum;
    public string targetScale;
    public string targetPos;

    public MeasnsOfAttack measnsOfAttack;

    public string note;
}
