using System;
using Vtas;
[Serializable]
public class CommandData : MsgData
{
    public CommandReportType commandReportType;
    public string title;
    public string releavantOverlay;
    public string[] lines = new string[35];
    public Job_Position job_Position;
    public Rank rank;
    public MARGINAL_NOTE marginalNoteInfo;
}
