using System;
using Vtas;
[Serializable]
public class FindEnemyData : MsgData
{
    public UInt16 day;
    public UInt16 hour;
    public UInt16 min;

    public string myPosition;

    public string targetPosition;

    public TargetType targetType1;
    public TargetType targetType2;
    public TargetType targetType3;

    public UInt16 target1Count;
    public UInt16 target2Count;
    public UInt16 target3Count;

    public TargetPosture targetPosture;
    public TargetDirection targetDirection;

    public string note;
}
