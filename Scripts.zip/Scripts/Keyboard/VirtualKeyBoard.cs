using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using TMPro;
public class VirtualKeyBoard : MonoBehaviour
{
    public enum Language
    {
        [InspectorName("Kor")]
        korean,
        [InspectorName("Eng")]
        English,
    };

    [System.Serializable]
    public class ReturnEvent: UnityEvent<string> { }

    public delegate bool VirtualKeyboardReturnDelegate(string text);

    public Language defaultLang = Language.korean;

    public VirtualKeyboardReturnDelegate OnReturnDelegate { get; set; }

    public ReturnEvent OnReturnEventHandler;

    public VirtualTextInputBox TextInputBox = null;
    public int maxTextCount = 20;

    public TextMeshProUGUI TextViewer;

    protected bool mPressShift = false;
    protected bool mCapsLock = false;
    protected Language mLanguage = Language.korean;
    protected Dictionary<char, char> CHARACTER_TABLE = new Dictionary<char, char>
    {
        {'1', '!'}, {'2', '@'}, {'3', '#'}, {'4', '$'}, {'5', '%'},{'6', '^'}, {'7', '&'}, {'8', '*'}, {'9', '('},{'0', ')'},
        { '`', '~'},   {'-', '_'}, {'=', '+'}, {'[', '{'}, {']', '}'}, {'\\', '|'}, {',', '<'}, {'.', '>'}, {'/', '?'}
    };

    private void Awake()
    {
        VirtualKey.keyBoard = this;
    }
    private void OnEnable()
    {
        mLanguage = defaultLang;
        mPressShift = false;
    }

    public void Clear()
    {
        if (TextInputBox != null)
        {
            TextInputBox.Clear();
        }
    }
    public void Keydown(VirtualKey key)
    {
        if (TextInputBox != null)
        {
            switch (key.keyType)
            {
                case VirtualKey.KeyType.SHIFT:
                    {
                        mPressShift = !mPressShift;
                    }
                    break;
                case VirtualKey.KeyType.CAPSLOOK:
                    {
                        mCapsLock = !mCapsLock;
                    }
                    break;
                case VirtualKey.KeyType.HANGUL:
                    {
                        if (mLanguage == Language.korean) mLanguage = Language.English;
                        else mLanguage = Language.korean;
                    }
                    break;
                case VirtualKey.KeyType.SPACE:
                    {
                        if (TextInputBox.TextField.Length <= maxTextCount)
                        {
                            TextInputBox.KeyDown(key);
                        }
                    }
                    break;
                case VirtualKey.KeyType.BACKSPACE:
                    {
                        TextInputBox.KeyDown(key);
                    }
                    break;
                case VirtualKey.KeyType.RETURN:
                    {
                        if (OnReturnEventHandler != null)
                        {
                            //OnReturnEventHandler(TextInputBox.TextField);

                        }
                        //do somehing
                        //OnReturnEventHandler?.Invoke(TextInputBox.TextField);
                        //if ((bool)OnReturnDelegate?.Invoke(TextInputBox.TextField))
                        //{
                        //    //PlayKeyAudio();
                        //}
                        TextViewer.text = TextInputBox.TextField;
                        Clear();
                    }
                    break;
                case VirtualKey.KeyType.CHARACTER:
                    {
                        if (TextInputBox.TextField.Length <= maxTextCount)
                        {
                            char keyCharacter = key.KeyCharacter;
                            if (mPressShift)
                            {
                                keyCharacter = char.ToUpper(keyCharacter);
                                mPressShift = false;
                            }

                            if (mLanguage == Language.korean)
                            {
                                TextInputBox.KeyDownHangul(keyCharacter);
                            }
                            else if (mLanguage == Language.English)
                            {
                                if (mCapsLock)
                                {
                                    keyCharacter = char.ToUpper(keyCharacter);
                                }
                                TextInputBox.KeyDown(keyCharacter);
                            }
                        }

                    }
                    break;
                case VirtualKey.KeyType.OTHER:
                    {
                        if (TextInputBox.TextField.Length <= maxTextCount)
                        {
                            char keyCharacter = key.KeyCharacter;
                            if (mPressShift)
                            {
                                if (key.HasShiftedChar())
                                {
                                    keyCharacter = CHARACTER_TABLE[keyCharacter];
                                }
                                mPressShift = false;
                            }
                            TextInputBox.KeyDown(keyCharacter);
                        }
                    }
                    break;
            }
        }
    }
    public bool PressedShift
    {
        get
        {
            return mPressShift;
        }
    }

    public bool CapLockOn
    {
        get
        {
            return mCapsLock;
        }
    }

    public Language language
    {
        get
        {
            return mLanguage;
        }
    }

    private void OnDisable()
    {
        TextInputBox.Clear();
    }
}
