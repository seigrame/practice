using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class VirtualKey : MonoBehaviour ,IPointerDownHandler,IPointerUpHandler
{

    static public VirtualKeyBoard keyBoard = null;

    public enum KeyType
    {
        CHARACTER,
        OTHER,
        RETURN,
        SPACE,
        BACKSPACE,
        SHIFT,
        TAB,
        CAPSLOOK,
        HANGUL,
    }

    public float AlphaHitTestMinimumThreshold;
    public char KeyCharacter;
    public KeyType keyType = KeyType.CHARACTER;
    private bool mKeepPresed;


    public bool KeepPressed
    {
        set { mKeepPresed = value; }
        get { return mKeepPresed; }
    }

    // private bool mIsPressed = false;
    private TextMeshProUGUI mKeyText;
    private TextMeshProUGUI mShiftedText = null;
    //private TextMeshProUGUI mLanguageBtnTxtKor = null;
    //private TextMeshProUGUI mLanguageBtnTxtEng = null;

    static Color Color_Deactivate = new Color(0.4588236f, 0.4588236f, 0.4588236f);

    private void Awake()
    {
        if (AlphaHitTestMinimumThreshold > float.Epsilon)
        {
            Image image = GetComponent<Image>();

            if (image != null)
            {
                image.alphaHitTestMinimumThreshold = AlphaHitTestMinimumThreshold;
            }
        }

        //mShiftedText = transform.Find("ShiftedText")?.GetComponent<Text>();
        Transform t = transform.Find("ShiftedText");
        if (t != null)
        {
            mShiftedText = t.GetComponent<TextMeshProUGUI>();
        }

        if (keyType == KeyType.HANGUL)
        {
            //mLanguageBtnTxtKor = transform.Find("Kor").GetComponent<Text>();
            //mLanguageBtnTxtEng = transform.Find("Eng").GetComponent<Text>();
        }

        var txtTransform = transform.Find("Text (TMP)");

        if (txtTransform != null)
        {
            mKeyText = txtTransform.GetComponent<TextMeshProUGUI>();
        }

        if (keyType == KeyType.OTHER)
        {
            //mShiftedText = mSubTransform.Find("ShiftedChar").GetComponent<Text>();
        }
    }
    void Start()
    {
        Button _button = gameObject.GetComponent<Button>();
        if (_button != null)
        {
            /*
            if(mSubTransform != null)
            {
                var targetGraphic = mSubTransform.GetComponent<Image>();
                _button.targetGraphic = targetGraphic;
            }
            */

            _button.onClick.AddListener(onKeyClick);
        }
    }

    void onKeyClick()
    {
        //VirtualKeyboard _keybord = GameObject.FindObjectOfType< VirtualKeyboard>();
        if (keyBoard != null)
        {
            keyBoard.Keydown(this);
        }
    }

    // Update is called once per frame
    void Update()
    {

        if (KeepPressed)
        {
            //do something
        }

        switch (keyType)
        {
            case KeyType.CHARACTER:
                {
                    if (keyBoard.language == VirtualKeyBoard.Language.korean)
                    {
                        if (mShiftedText != null)
                        {
                            if (!mShiftedText.gameObject.activeSelf)
                            {
                                mShiftedText.gameObject.SetActive(true);
                            }
                        }

                        if (keyBoard.PressedShift)
                        {
                            if (mShiftedText != null)
                            {
                                mShiftedText.text = AutomateKR.GetHangulSound(KeyCharacter).ToString();
                                mKeyText.text = AutomateKR.GetHangulSound(char.ToUpper(KeyCharacter)).ToString();
                            }
                            else
                            {
                                mKeyText.text = AutomateKR.GetHangulSound(char.ToUpper(KeyCharacter)).ToString();
                            }
                        }
                        else
                        {
                            if (mShiftedText != null)
                            {
                                mShiftedText.text = AutomateKR.GetHangulSound(char.ToUpper(KeyCharacter)).ToString();
                            }
                            mKeyText.text = AutomateKR.GetHangulSound(KeyCharacter).ToString();
                        }
                    }
                    else
                    {
                        if (keyBoard.CapLockOn || keyBoard.PressedShift)
                        {
                            mKeyText.text = char.ToUpper(KeyCharacter).ToString();
                        }
                        else
                        {
                            mKeyText.text = KeyCharacter.ToString();
                        }

                        if (mShiftedText != null)
                        {
                            if (mShiftedText.gameObject.activeSelf)
                            {
                                mShiftedText.gameObject.SetActive(false);
                            }
                        }
                    }
                }
                break;
            case KeyType.OTHER:
                {
                    if (mShiftedText != null)
                    {
                        if (keyBoard.PressedShift)
                        {
                            mKeyText.color = Color_Deactivate;
                            mShiftedText.color = Color.black;
                        }
                        else
                        {
                            mKeyText.color = Color.black;
                            mShiftedText.color = Color_Deactivate;
                        }
                    }
                }
                break;
            case KeyType.SHIFT:
                {
                    if (keyBoard.PressedShift)
                    {
                        if (mKeyText != null)
                        {
                            mKeyText.color = Color.black;
                        }
                    }
                    else
                    {
                        if (mKeyText != null)
                        {
                            mKeyText.color = Color_Deactivate;
                        }
                    }
                }
                break;
            case KeyType.CAPSLOOK:
                {
                    if (keyBoard.CapLockOn)
                    {
                        mKeyText.color = Color.white;
                    }
                    else
                    {
                        mKeyText.color = Color_Deactivate;
                    }
                }
                break;
            case KeyType.HANGUL:
                {
                    if (keyBoard.language == VirtualKeyBoard.Language.korean)
                    {
                        //mLanguageBtnTxtKor.color = Color.black;
                        //mLanguageBtnTxtEng.color = Color_Deactivate;
                    }
                    else
                    {
                        //mLanguageBtnTxtKor.color = Color_Deactivate;
                        //mLanguageBtnTxtEng.color = Color.black;
                    }
                }
                break;
        }
    }

    public bool HasShiftedChar()
    {
        return mShiftedText != null;
    }
    public void OnPointerDown(PointerEventData eventData)
    {
        //mIsPressed = true;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        //mIsPressed = false;
    }

    [ExecuteInEditMode]
    public void GetKeyCharacterFromObjectName()
    {
        string name = transform.name;

        if (name.Length > 0)
        {
            char[] array = name.ToCharArray(0, 1);

            KeyCharacter = array[0];
        }
    }
}
