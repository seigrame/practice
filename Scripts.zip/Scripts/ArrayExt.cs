using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public static class ArrayExt
{
    public static T[] GetRow<T>(this T[,] arr, int row)
    {
        if (!typeof(T).IsPrimitive)
            Debug.LogError("Not Supported for managed type");
        if (arr == null)
            Debug.LogError("Not array");

        int cols = arr.GetUpperBound(1) + 1;
        T[] result = new T[cols];

        int size;

        if (typeof(T) == typeof(bool))
            size = 1;
        else if (typeof(T) == typeof(char))
            size = 2;
        else
            size = Marshal.SizeOf(typeof(T));

        Buffer.BlockCopy(arr, row * cols * size, result, 0, cols * size);

        return result;
    }
    //public T[] GetColumn(T[,] matrix, int columnNumber)
    //{
    //    return Enumerable.Range(0, matrix.GetLength(0))
    //            .Select(x => matrix[x, columnNumber])
    //            .ToArray();
    //}

    //public T[] GetRow(T[,] matrix, int rowNumber)
    //{
    //    return Enumerable.Range(0, matrix.GetLength(1))
    //            .Select(x => matrix[rowNumber, x])
    //            .ToArray();
    //}

}
