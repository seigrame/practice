using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;

namespace Vtas
{
    public class UDPServer : MonoBehaviour
    {
        MyInfo myInfo;//테스트용
        public Vector3 unityPos;
        public Quaternion rot, weaponRot;
        SelectRole selectRole;
        ContentsItemManager itemManager;      
        UIManager uiManager;
        public Transform uiContainer;
        //소켓        
        public Socket serverUDPSocket; //호스트들의 자차정보를 수신받을 소켓

        //접속한 위치들을 관리함
        public List<EndPoint> listEP = new List<EndPoint>();

        public int udpPort;

        private Thread dataSendThread; //데이타 송수신 쓰레드
        private Thread dataRecvThread; //데이타 송수신 쓰레드

        public Stack<PACKET_TYPE> SendMessageStack;
        public Stack<Packet> ReceiveMessageStack;

        // Start is called before the first frame update
        void Start()
        {
            uiManager = FindObjectOfType<UIManager>();
            itemManager = FindObjectOfType<ContentsItemManager>();
            selectRole = FindObjectOfType<SelectRole>();
            myInfo = FindObjectOfType<MyInfo>(); // 테스트용
            SendMessageStack = new Stack<PACKET_TYPE>();
            ReceiveMessageStack = new Stack<Packet>();

            if (File.Exists(INIParser.NetSessionPath) == false)
            {
                //파일이없는 경우
                Debug.Log("Load NetSetting file failed : " + INIParser.NetSessionPath);
            }
            else
            {
                string strPort = INIParser.Read(INIParser.NetSessionPath, "UDPSERVER", "PORT");
                udpPort = int.Parse(strPort);
            }
            InitServer(udpPort);

            dataSendThread = new Thread(ThreadSend);
            dataSendThread.Start();

            dataRecvThread = new Thread(ThreadRecv);
            dataRecvThread.Start();

        }
       
        private void OnApplicationQuit()
        {
            if (dataSendThread != null)
            {
                dataSendThread.Abort();
            }

            if (dataRecvThread != null)
            {
                dataRecvThread.Abort();
            }
        }

        private void ThreadSend()
        {
            while (true)
            {
                //자차정보를 상위로 보내는 작업
                //훈련이 시작되면 보낸다
                if (uiManager.selectRole.setRole != SelectRole.SELECT_ROLE.TANK_CREW)
                {
                    SendMessageStack.Push(PACKET_TYPE.U2L_MOVING_OBJECT);
                }
                Thread.Sleep(33);
            }
        }

        private void ThreadRecv()
        {
            while (true)
            {
                ReceiveData();

                Thread.Sleep(0);
            }
        }

        public void InitServer(int port)
        {
            serverUDPSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, port);
            serverUDPSocket.Bind(endPoint);

            Debug.Log("UDP 서버를 초기화하는 중..."); //버튼을 눌렀을 때 처음은 이 함수를 실행, 다음 버튼을 눌렀을때는 다른 함수를 실행해야함.

        }

        void ReceiveData()
        {
            byte[] ReceivePacket = new byte[NetworkManager.MAX_PACKET_SIZE];

            EndPoint cltEP = new IPEndPoint(IPAddress.None, 0);

            int nRecv = serverUDPSocket.ReceiveFrom(ReceivePacket, ref cltEP); // 받은 문자 바이트

            //받은 아이피가 자기자신이라면 무시한다.
            if (((IPEndPoint)cltEP).Address == NetworkManager.instance.myIP) return;

            if (nRecv > 0)
            {
                Packet packet = (Packet)Packet.Deserialize(ReceivePacket);
                ReceiveMessageStack.Push(packet);

                //등록안된 포인트라면 추가한다
                if (listEP.Contains(cltEP) == false) listEP.Add(cltEP);
                //currentUserCount = listEP.Count;
                print("receive data ip : " + ((IPEndPoint)cltEP).Address.ToString() + " port : " + ((IPEndPoint)cltEP).Port.ToString());
            }
        }

        //이 함수는 상위체계모의에서 연동객체를 융합하여 전체로 뿌리는 함수로 써야한다. 전차장의 경우 소대원의 정보를 상위체계로 전달한다.
        public void SendDataMovingObjectInfo()
        {
            if (selectRole.setRole == SelectRole.SELECT_ROLE.PLATOON_MEMBER || selectRole.setRole == SelectRole.SELECT_ROLE.TANK_CREW) return; //소대원과 조종수/사수일 경우는 제외한다.
            var movingObject = new U2LMovingObject();
            movingObject.peerIconList = new List<H2TMovingObject>();

            //아군탱크들의 정보를 전부 담는다.
            for (int i = 0; i < uiManager.overlayIconManager.peerIconList.Count; i++)
            {
                if (uiManager.overlayIconManager.peerIconList[i] == null) uiManager.overlayIconManager.peerIconList.Remove(uiManager.overlayIconManager.peerIconList[i]); //null객체 삭제
                else
                {
                    IconInfo equip = uiManager.overlayIconManager.peerIconList[i].GetComponent<IconInfo>();
                    //객에id와 transform의 위치,각도만 보낸다.
                    H2TMovingObject obj = new H2TMovingObject();
                    obj.objectID = movingObject.objectID = (ushort)equip.userId;
                    Vector2 gps = VtasMapManager.Instance.UCStoGPS(new Vector3(equip.myPosition.x, equip.myPosition.y, equip.myPosition.z));
                    obj.locationLatitude = gps.x;
                    obj.locationLongitude = gps.y;
                    Vector3 rot = new Vector3(equip.myRotation.x, equip.myRotation.y, equip.myRotation.z);
                    obj.orientationPitch = rot.x;
                    obj.orientationHeading = rot.y;
                    obj.orientationRoll = rot.z;
                    movingObject.peerIconList.Add(obj);
                }            
            }
            SendData(movingObject);
        }
        //서버가 가지고있는 데이터를 전송
        public void SendData(Packet packet)
        {
            for (int i = 0; i < listEP.Count; i++)
            {
                try
                {
                    byte[] SendPacket = new byte[NetworkManager.MAX_PACKET_SIZE];
                    //메세지 보냄                    
                    if (packet is H2TMovingObject)//호스트로부터 받아 탱크로 전하는 정보
                    {
                        H2TMovingObject movingObject = (H2TMovingObject)packet;
                        Packet.Serialize(movingObject).CopyTo(SendPacket, 0);
                        
                    }
                    else if (packet is U2LMovingObject)//상위체계에서 받아 하위로 보내는 정보
                    {
                        U2LMovingObject movingObject = (U2LMovingObject)packet;
                        Packet.Serialize(movingObject).CopyTo(SendPacket, 0);
                    }
                    serverUDPSocket.SendTo(SendPacket, listEP[i]);
                    print("send data ip : " + ((IPEndPoint)listEP[i]).Address.ToString() + " port : " + ((IPEndPoint)listEP[i]).Port);
                }
                catch (Exception e)
                {
                    Debug.Log(e.Message);
                    return;
                }
            }
        }
        //전차장일때 호스트로부터 받음, 상위체계일때 전차장으로부터 받음
        public void ProcessReceivePacket(Packet packet)
        {
            var peerIdList = uiManager.overlayIconManager.peerIdList;
            if (packet != null)
            {
                switch (packet.packetType)
                {

                    case PACKET_TYPE.H2T_MOVING_OBJECT: //호스트로부터 받은 정보
                        H2TMovingObject ownshipInfo = (H2TMovingObject)packet;
                        //자차정보를 수신해서 화면에 갱신해야함
                        if (selectRole.setRole != SelectRole.SELECT_ROLE.HIGH_COMMANDER)//체계모의가 아닐경우 자차심볼을 먼저 그림
                        {
                            myInfo.timeLimit = 0f;//신호를 보낼때마다 시간 갱신
                            if (myInfo.mySymbolPos != null)//내 아이콘이 존재한다면 위치를 바꿈
                            {   //위 경도를 전달
                                if (myInfo.myId == 0)
                                {
                                    myInfo.myId = ownshipInfo.objectID;
                                }//호스트로부터 아이디를 받음 
                                myInfo.latlonText = ownshipInfo.locationLatitude.ToString("F6") + " " + ownshipInfo.locationLongitude.ToString("F6");
                                //위 경도를 유니티 좌표로 변환  
                                unityPos = VtasMapManager.Instance.GPStoUCS(new Vector2((float)ownshipInfo.locationLatitude, (float)ownshipInfo.locationLongitude));// 위/경도를 다시 유니티 좌표로 바꾼 코드 투명도 아이콘 생성좌표와 일치시킴

                                rot = Quaternion.Euler(new Vector3(ownshipInfo.orientationPitch, ownshipInfo.orientationHeading, ownshipInfo.orientationRoll) * -1);
                                weaponRot = Quaternion.Euler(new Vector3(ownshipInfo.weaponPitch, 0, ownshipInfo.weaponHeading));
                            }
                        }
                        else  //체계모의의 경우
                        {                                                 
                            if (peerIdList.Contains(ownshipInfo.objectID) == false)
                            {
                                peerIdList.Add(ownshipInfo.objectID);//없으면 객체를 생성
                                //uiManager.overlayIconManager.iconList.Clear();
                                IconInfo[] oldIcon = uiContainer.GetComponentsInChildren<IconInfo>(); //기존의 아이콘을 지움
                                for (int i = 0; i < oldIcon.Length; i++)
                                {
                                    Destroy(oldIcon[i].gameObject);
                                }
                                for (int i = 0; i < peerIdList.Count; i++) //접속한 유저수만큼 다시 그림
                                {
                                    GameObject go = Instantiate(itemManager.peerSymbol, uiContainer);
                                    go.GetComponent<IconInfo>().userId = peerIdList[i];//객체의 아이디를 부여 
                                    uiManager.overlayIconManager.peerIconList.Add(go);
                                }
                            }
                            else//있으면 정보를 갱신 
                            {
                                for (int i = 0; i < uiManager.overlayIconManager.peerIconList.Count; i++)
                                {
                                    if (uiManager.overlayIconManager.peerIconList[i] == null) uiManager.overlayIconManager.peerIconList.Remove(uiManager.overlayIconManager.peerIconList[i]); //null객체 삭제
                                    GameObject obj = uiManager.overlayIconManager.peerIconList[i]; //아이콘 리스트를 읽어옴
                                    if (ownshipInfo.objectID == obj.GetComponent<IconInfo>().userId)
                                    {
                                        unityPos = VtasMapManager.Instance.GPStoUCS(new Vector2((float)ownshipInfo.locationLatitude, (float)ownshipInfo.locationLongitude));// 위/경도를 다시 유니티 좌표로 바꾼 코드 투명도 아이콘 생성좌표와 일치시킴 
                                        Vector2 iconPos = uiManager.rightPanel.overlayIcon.GetScreenPosition(unityPos);                                                                                                              
                                        obj.GetComponent<IconInfo>().myPosition = unityPos;
                                        obj.transform.position = iconPos;
                                        obj.GetComponent<IconInfo>().myRotation = (new Vector3(ownshipInfo.orientationPitch, ownshipInfo.orientationHeading, ownshipInfo.orientationRoll));
                                        obj.transform.rotation = Quaternion.Euler(new Vector3(ownshipInfo.orientationPitch, ownshipInfo.orientationHeading, -ownshipInfo.orientationRoll));
                                        obj.GetComponent<IconInfo>().timeLimit = 0;
                                        uiManager.overlayIconManager.UpdateObjectInfo();
                                    }                            
                                }
                            }
                        } 
                        if (selectRole.setRole != SelectRole.SELECT_ROLE.HIGH_COMMANDER)
                        {   //상위체계가 아닐 경우 호스트에서 받은 정보를 상위체계모의로 그대로 올려주자
                            NetworkManager.instance.udpClient.SendData(ownshipInfo);//클라이언트에서 받은 데이터를 전송
                        }                      
                        break;
                    case PACKET_TYPE.C2P_MOVING_OBJECT: //소대원으로부터 받은 정보 => 자차정보는 받지않음.
                        C2PMovingObject ownshipInfo2 = (C2PMovingObject)packet;
                        if (peerIdList.Contains(ownshipInfo2.objectID) == false)
                        {
                            peerIdList.Add(ownshipInfo2.objectID);//없으면 객체를 생성
                            IconInfo[] oldIcon = uiContainer.GetComponentsInChildren<IconInfo>(); //기존의 아이콘을 지움
                            for (int i = 0; i < oldIcon.Length; i++)
                            {
                                Destroy(oldIcon[i].gameObject);
                            }
                            for (int i = 0; i < peerIdList.Count; i++) //접속한 유저수만큼 다시 그림
                            {
                                GameObject go = Instantiate(itemManager.peerSymbol, uiContainer);
                                go.GetComponent<IconInfo>().userId = peerIdList[i];//객체의 아이디를 부여 
                                uiManager.overlayIconManager.peerIconList.Add(go);
                            }
                        }
                        else//있으면 정보를 갱신 
                        {
                            for (int i = 0; i < uiManager.overlayIconManager.peerIconList.Count; i++)
                            {
                                if (uiManager.overlayIconManager.peerIconList[i] == null) uiManager.overlayIconManager.peerIconList.Remove(uiManager.overlayIconManager.peerIconList[i]); //null객체 삭제
                                GameObject obj = uiManager.overlayIconManager.peerIconList[i]; //아이콘 리스트를 읽어옴
                                if (ownshipInfo2.objectID == obj.GetComponent<IconInfo>().userId)
                                {
                                    unityPos = VtasMapManager.Instance.GPStoUCS(new Vector2((float)ownshipInfo2.locationLatitude, (float)ownshipInfo2.locationLongitude));// 위/경도를 다시 유니티 좌표로 바꾼 코드 투명도 아이콘 생성좌표와 일치시킴 
                                    Vector2 iconPos = uiManager.rightPanel.overlayIcon.GetScreenPosition(unityPos);
                                    obj.GetComponent<IconInfo>().myPosition = unityPos;
                                    obj.transform.position = iconPos;
                                    obj.GetComponent<IconInfo>().myRotation = (new Vector3(ownshipInfo2.orientationPitch, ownshipInfo2.orientationHeading, ownshipInfo2.orientationRoll));
                                    obj.transform.rotation = Quaternion.Euler(new Vector3(ownshipInfo2.orientationPitch, ownshipInfo2.orientationHeading, -ownshipInfo2.orientationRoll));
                                    obj.GetComponent<IconInfo>().timeLimit = 0;
                                    uiManager.overlayIconManager.UpdateObjectInfo();
                                }
                            }
                        }                       
                        if (selectRole.setRole != SelectRole.SELECT_ROLE.HIGH_COMMANDER)
                        {   //상위체계가 아닐 경우 호스트에서 받은 정보를 상위체계모의로 그대로 올려주자
                            NetworkManager.instance.udpClient.SendData(ownshipInfo2);//클라이언트에서 받은 데이터를 전송
                        }
                        break;
                }
            }
        }
    }
}

