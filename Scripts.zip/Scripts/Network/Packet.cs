using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Vtas
{
    public enum PACKET_TYPE : Byte
    {
        INIT = 0,

        //ȣ��Ʈ->ü�����(������)
        H2T_INSTRUCTOR_MISSION_COMMAND,   //��������
        H2T_LEVEL_SET_COMMAND,            //��������
        H2T_SCENARIO_LOADING,             //�ó����� �ε�
        H2T_SIM_RUN_CONTROL_COMMAND,      //�ùķ��̼� ��Ʈ��(���� �簳 ���� ��)
        H2T_MOVING_OBJECT,                //��ü �̵�
        H2T_WEAPON_FIRE,                  //�߻�
        H2T_OWNSHIP_FIRE_IMPACT,          //���󿡼� �ִ� �ǰ�����_ȣ��Ʈ������ ������ �ȴ�.
        H2T_ENVIRONMENT_STATUS_CHANGE,    //���� �ı� ����(���ڸ� ����->����)
        H2T_MISSION_COMPLETE,             //�ӹ��ϼ�
        H2T_OWNSHIP_STATUS_CHANGE,        //�Ʒ����� ���� ����

        //ü�����(������) -> ü�����(���,������)
        WAY_POINT,                        //�̵���
        TARGET_ASSIGNMENT,                //ǥ���Ҵ�
        //ü�����(������) -> ����ü�����
        //����ü����� -> ü�����(������)
        FIND_ENEMY,                   //���߰�
        TRANSFER,                         //�ļ�
        CBRN_FIRST,                       //ȭ���� ���� ����
        CBRN_SCOUT,                       //ȭ���� ���� ����
        MY_STATE,                         //������Ȳ����  �� UDP�� �ְ� ����, �̰� �ܿ��� ���� TCP�� 
        OBSTACLE,                         //��ֹ�
        TARGET_DAMAGE,                    //ǥ������
        NO_FORMAT,                        //����
        FIRE_SUPPORT,                     //ȭ������
        COMMAND,                          //��������
        OVERLAY,                          //������
        MARGINAL_NOTE,                    //�����ֱ�
        //ü�����(���,������) -> ������
        //�������� ������
        U2L_MOVING_OBJECT,
        //�Ҵ���� �Ҵ���(������)���� 
        C2P_MOVING_OBJECT,
        NONE,
        NUM
    }
    [Serializable]
    public class Packet
    {
        //icd header
        public UInt32 hTimestamp;
        public UInt16 hLength;
        public UInt16 hStatus;

        public PACKET_TYPE packetType; //UInt8
        public Byte packetLength; //UInt8
        public string createDate;
        public static byte[] Serialize(Object data)
        {
            try
            {
                MemoryStream ms = new MemoryStream(1024 * 4); // packet size will be maximum 4k
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ms, data);
                return ms.ToArray();
            }
            catch
            {
                return null;
            }
        }

        public static Object Deserialize(byte[] data)
        {
            try
            {
                MemoryStream ms = new MemoryStream(1024 * 4);
                ms.Write(data, 0, data.Length);

                ms.Position = 0;
                BinaryFormatter bf = new BinaryFormatter();
                Object obj = bf.Deserialize(ms);
                ms.Close();
                return obj;
            }
            catch
            {
                return null;
            }
        }
    }

    #region ȣ��Ʈ -> ����
    [Serializable]
    public class H2TInstructorMissionCommand : Packet
    {
        public H2TInstructorMissionCommand()
        {
            packetType = PACKET_TYPE.H2T_INSTRUCTOR_MISSION_COMMAND;
            packetLength = 9;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public MISSION_TYPE missionType;
        public UInt16 objectID;
        public byte objectType; //uint8_t�� ����
        public double locationFirstLatitude;
        public double locationFirstLongtitude;
        public double locationSecondLatitude;
        public double locationSecondLongtitude;
        public float data;
    }

    [Serializable]
    public class H2TLevelSetCommand : Packet
    {
        public H2TLevelSetCommand()
        {
            packetType = PACKET_TYPE.H2T_LEVEL_SET_COMMAND;
            packetLength = 4;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public byte redSpeed;              //speed �� ���� �ִ� �ӷ� �ۼ�Ʈ�� ����
        public byte redResponseTime;      //�� ���� �����ð�(Ž�� �� �߻���� �����ð�) ����
        public RED_KILL_RATE redKillRate;
        public RED_DETECT_RATE redDetectRate;
    }

    [Serializable]
    public class H2TScenarioLoading : Packet
    {
        public H2TScenarioLoading()
        {
            packetType = PACKET_TYPE.H2T_SCENARIO_LOADING;
            packetLength = 6;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public EXERCISE_TYPE exerciseType;
        public EXERCISE_LEVEL exerciseLevel;
        public SEASON season;

        public UInt16 scenarioFileNameNum;
        public int hostType;
    }

    [Serializable]
    public class H2TSimRunControlCommand : Packet
    {
        public H2TSimRunControlCommand()
        {
            packetType = PACKET_TYPE.H2T_SIM_RUN_CONTROL_COMMAND;
            packetLength = 2;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public CONTROL_COMMAND controlCommand;
    }

    [Serializable]
    public class H2TMovingObject : Packet
    {
        public H2TMovingObject()
        {
            packetType = PACKET_TYPE.H2T_MOVING_OBJECT;
            packetLength = 15;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public UInt16 objectID;
        public byte objectType;
        public float objectSpeed;
        public UInt16 masterID;
        public double locationLatitude;
        public double locationLongitude;
        public double locationAltitude;
        public float orientationPitch;
        public float orientationRoll;
        public float orientationHeading;
        public float weaponHeading;
        public byte forceID;
        public float weaponPitch;
        public float CPSHeading;
        public float caterpillarRSpeed;
        public float caterpillarLSpeed;
        public double objectStatus;
    }


    [Serializable]
    public class H2TWeaponFireCommand : Packet
    {
        public H2TWeaponFireCommand()
        {
            packetType = PACKET_TYPE.H2T_WEAPON_FIRE;
            packetLength = 7;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public ushort objectID;
        public ushort targetID;
        public WEAPON_TYPE weaponType;
        public double targetX;
        public double targetY;
        public double targetZ;

        public ulong fireMission;//FireMission(ȣ)�� ���� ������ �𸣰���.
    }

    [Serializable]
    public class H2TOwnshipFireImpact : Packet
    {
        public H2TOwnshipFireImpact()
        {
            packetType = PACKET_TYPE.H2T_OWNSHIP_FIRE_IMPACT;
            packetLength = 7;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public UInt16 objectID;
        public UInt16 targetID;
        public SHELL_TYPE shellType;
        public double impactX;
        public double impactY;
        public double impactZ;
        public int detonationATT;
    }

    [Serializable]
    public class H2TEnvironmentStatusChange : Packet
    {
        public H2TEnvironmentStatusChange()
        {
            packetType = PACKET_TYPE.H2T_ENVIRONMENT_STATUS_CHANGE;
            packetLength = 3;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public UInt16 objectID;
        public byte objectType;
        public UInt16 environmentEntityID;
        public ENVIRONMENT_STATUS environmentStatus;
    }

    [Serializable]
    public class H2TMissionComplete : Packet
    {
        public H2TMissionComplete()
        {
            packetType = PACKET_TYPE.H2T_MISSION_COMPLETE;
            packetLength = 3;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public UInt16 ojectID;
        public UInt16 environmentEntityID;
        public MISSION_COMPLETE_TYPE missionCompleteType;
    }


    [Serializable]
    public class H2TOwnshipStatusChange : Packet
    {
        public H2TOwnshipStatusChange()
        {
            packetType = PACKET_TYPE.H2T_OWNSHIP_STATUS_CHANGE;
            packetLength = 3;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public UInt16 objectID;
        public byte objectType;
        public OWNSHIP_STATUS ownshipStatus;
    }

    #endregion

    #region ü����� �� ���� ����
    /// <summary>
    /// �Ϲ� ���� 
    /// </summary>
    //���߰� ���� 
    [Serializable]
    public class FIND_ENEMY : Packet
    {
        public FIND_ENEMY()
        {
            packetType = PACKET_TYPE.FIND_ENEMY;
            packetLength = 24;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public UInt16 day;
        public UInt16 hour;
        public UInt16 min;

        public string myPosition;

        public string targetPosition;

        public TargetType targetType1;
        public TargetType targetType2;
        public TargetType targetType3;

        public UInt16 target1Count;
        public UInt16 target2Count;
        public UInt16 target3Count;

        public TargetPosture targetPosture;   
        public TargetDirection targetDirection;

        public string note;
    }
    //�ļ� ���� 
    [Serializable]
    public class TRANSFER : Packet
    {
        public TRANSFER()
        {
            packetType = PACKET_TYPE.TRANSFER;
            packetLength = 20;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public string rescuePosition;

        public UInt16 patient;
        public UInt16 stretcher;

        public TransferPriority transferPriority;
        public AreaMark mark;
        public Pollution pollution;
        public MarkColor markColor;
        public AreaSafetyLevel areaSafetyLevel;
        public National national;

        public string note;
    }
    //ȭ���� ���ʺ���
    [Serializable]
    public class CBRN_FIRST : Packet
    {
        public CBRN_FIRST()
        {
            packetType = PACKET_TYPE.CBRN_FIRST;
            packetLength = 30;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public CBRNType cbrnType;

        public string myPosition;

        public int myRotation_do;
        public int myRotation_mil;

        public UInt16 atkStartD;
        public UInt16 atkStartH;
        public UInt16 atkStartM;
        public UInt16 atkEndD;
        public UInt16 atkEndH;
        public UInt16 atkEndM;

        public string attackedPosition;

        public Situation situation;

        public Classifications classifications;
        public Property property;
        public Kinds kinds;
        public ExplosionShape explosionShape;

        public FireMethod fireMethod;

        public int NumberOfAmmunition;
        public int NumberOfAircraft;

        public string note;
    }
    //ȭ���� ��������
    [Serializable]
    public class CBRN_SCOUT : Packet
    {
        public CBRN_SCOUT()
        {
            packetType = PACKET_TYPE.CBRN_SCOUT;
            packetLength = 20;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public UInt16 startDay;
        public UInt16 startHour;
        public UInt16 startMin;
        public float radiationRate;
        public Classifications classifications;
        public Property property;
        public Kinds kinds;
        public ExplosionShape explosionShape;
        public CBRNScoutItemData[] scoutItemArr = new CBRNScoutItemData[6];
        public string note;
    }

    //�������� ���� 
    [Serializable]
    public class MY_STATE : Packet
    {
        public MY_STATE()
        {
            packetType = PACKET_TYPE.MY_STATE;
            packetLength = 31;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public UInt16 year;
        public UInt16 month;
        public UInt16 day;
        public UInt16 hour;
        public UInt16 minute;
        public string title;
        //�켱����
        public EnemyPosture enemyPosture;
        public string myPosition;
        //ǥ��
        public EnemyPostureLevel enemyPostureLevel;
        public LastOrder lastOrder;
        //������������
        public string LeftCoord;
        public string RightCoord;
        //�ο�
        public byte combat;
        public byte death;
        public byte injury;

        //ź��
        public byte ammo_h;
        public byte ammo_a;
        public byte ammo_c;
        public byte ammo_s;
        public byte ammo_m;

        public string note;
    }
    //��ֹ� ���� 
    [Serializable]
    public class OBSTACLE : Packet
    {
        public OBSTACLE()
        {
            packetType = PACKET_TYPE.OBSTACLE;
            packetLength = 28;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public UInt16 year;
        public byte month;
        public byte day;
        public byte hour;
        public byte minute;

        public string obtaclePosition;
        //�켱����
        public ClassifyEnemies classifyEnemies;

        public ObstacleShape obstacleShape;

        public string numberOfObstacle;
        public string controlNumber;
        public string installUnit;

        public ObstacleBarbedWireType obstacleBarbedWireType;

        public ObstacleMineType obstacleMineType;

        public ObstacleWallType obstacleWallType;

        public ObstacleCategory obstacleCategory;

        public float width;
        public float length;

        public string note;
    }
    //ǥ������ 
    [Serializable]
    public class TARGET_DAMAGE : Packet
    {
        public TARGET_DAMAGE()
        {
            packetType = PACKET_TYPE.TARGET_DAMAGE;
            packetLength = 16;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public TargetType targetType;

        public int targetTypeNum;
        public string targetScale;
        public string targetPos;

        public MeasnsOfAttack measnsOfAttack;

        public string note;
    }
    //����
    [Serializable]
    public class NO_FORMAT : Packet
    {
        public NO_FORMAT()
        {
            packetType = PACKET_TYPE.NO_FORMAT;
            packetLength = 17;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public string title;

        public UInt16 year;
        public byte month;
        public byte day;
        public byte hour;
        public byte minute;

        public string[] lines = new string[7];
    }
    /// <summary>
    /// ȭ������
    /// </summary>
    [Serializable]
    public class FIRE_SUPPORT : Packet
    {
        public FIRE_SUPPORT()
        {
            packetType = PACKET_TYPE.FIRE_SUPPORT;
            packetLength = 26;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        //�ӹ�����
        public MissionType missionType;
        //��ݺδ�Ը�
        public SupportSquadSize squadSize;
        //ǥ�� ��ġ
        public string targetPos;
        //ǥ�� ��ȣ
        public string plannedTarget;
        //Ȱ��
        public PostureType targetActiveState;

        public int numberOfScale;

        //�Ը�
        public UnitScale targetScale;

        //����
        public TargetType targetType;
        //ȥ��ǥ������
        public TargetType mixedTargetType;

        //ǥ�� ���
        public TargetShape shape;
        //ũŰ 1,2
        public UInt16 size1;
        public UInt16 size2;
        //���������
        public float rad;

        public string note;
        //���ݹ��. �������
        public string atkMethod;
        public string ctrlMethod;
    }
    /// <summary>
    /// ��������
    /// </summary>
    [Serializable]
    public class COMMAND : Packet
    {
        public COMMAND()
        {
            packetType = PACKET_TYPE.COMMAND;
            packetLength = 50;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public CommandReportType commandReportType;
        public byte[] title = new byte[50];

        public byte[] releavantOverlay;

        public byte[,] lines = new byte[35,56];

        public Job_Position job_Position;
        public Rank rank;
        public byte[] name = new byte[20];
        public MARGINAL_NOTE marginalNoteInfo; //������¸� �����ϵ���
        public bool isLink;
    }
    #endregion
    #region ������ ����, �Ϲ� ������ �ణ �������� ���� 
    [Serializable]
    public class MARGINAL_NOTE : Packet //���������� ���� �ʿ��ϴٸ� info_packet�� ��ӹް�, �ʿ� ���ٸ� �ٷ� packet�� ��ӹ޴´�.
    {
        public MARGINAL_NOTE()
        {
            packetType = PACKET_TYPE.MARGINAL_NOTE;
            packetLength = 10;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        //��� ���
        public SecretLevel secretLevel;
        //������
        public string missionName;
        //����
        public string misstionTarget;

        //�ۼ���
        public byte[] jobPosition = new byte[10];//����
                                  //�Ҽ� InfoPacket�� ����
        public byte[] platoonText = new byte[10];//�Ҵ�
        public byte[] companyText = new byte[10];//�ߴ� 
        public byte[] battalionText = new byte[10];//���
        public byte[] userName = new byte[10]; //�ۼ��� ����   InfoPacket�� ����
        public byte[] date = new byte[100];//�ۼ� �Ͻ�     InfoPacket�� ����
        //�߰�����
        public byte[] note = new byte[150];
        //������ 40��
        public OverlayIconData[] overlayDataArr = new OverlayIconData[40];
        public int index;
        public bool isLink;
    }

    [Serializable]
    public class OVERLAY : Packet// ���� ������ ÷�εǾ����
    {
        public OVERLAY()
        {
            packetType = PACKET_TYPE.OVERLAY;
            packetLength = 3;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public int id;
        public List<OverlayIconData> overlayIcons;
    }
    #endregion
    #region ǥ������(����->����)
    [Serializable]
    public class TARGET_ASSIGNMENT : Packet
    {
        public TARGET_ASSIGNMENT()
        {
            packetType = PACKET_TYPE.MARGINAL_NOTE;
            packetLength = 7;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        //ǥ���Ҵ� ��ǥ
        public string targetPosition;
        //��������
        public Priority dangerPriority;
        public TargetAssignmentSymbolKind recieveTargetAssignmentSymbol;
    }
    #endregion
    #region  �̵��� (������-> ������)
    [Serializable]
    public class WAY_POINT : Packet //���� ui�� ��ġ�� �ʰ� �ٷ� ���� �ǹǷ� ���������� ���� �ʿ� ���� �ٷ� packet�� ��ӹ޴´�.
    {
        public WAY_POINT()
        {
            packetType = PACKET_TYPE.WAY_POINT;
            packetLength = 17;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public WayPointData[] wayPointArr = new WayPointData[7];//�� ����
    }
    #endregion
    //ü����ǰ� �Ʊ��ɺ� ����
    [Serializable]
    public class U2LMovingObject : Packet
    {
        public U2LMovingObject()
        {
            packetType = PACKET_TYPE.U2L_MOVING_OBJECT;
            packetLength = 15;
            hLength = Convert.ToUInt16(packetLength + 2);
        }
        public UInt16 objectID;
        public byte objectType;
        public float objectSpeed;
        public double locationLatitude;
        public double locationLongitude;
        public double locationAltitude;
        public float orientationPitch;
        public float orientationRoll;
        public float orientationHeading;
        public float weaponHeading;
        public float weaponPitch;
        public List<H2TMovingObject> peerIconList;
    }

    //�Ҵ��� �Ҵ���� �ְ����� ��Ŷ
    [Serializable]
    public class C2PMovingObject : Packet
    {
        public C2PMovingObject()
        {
            packetType = PACKET_TYPE.H2T_MOVING_OBJECT;
            packetLength = 15;
            hLength = Convert.ToUInt16(packetLength + 2);
        }

        public UInt16 objectID;
        public byte objectType;
        public float objectSpeed;
        public UInt16 masterID;
        public double locationLatitude;
        public double locationLongitude;
        public double locationAltitude;
        public float orientationPitch;
        public float orientationRoll;
        public float orientationHeading;
        public float weaponHeading;
        public byte forceID;
        public float weaponPitch;
        public float CPSHeading;
        public float caterpillarRSpeed;
        public float caterpillarLSpeed;
        public double objectStatus;
    }
}

