using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;

namespace Vtas
{
    public class UDPClient : MonoBehaviour
    {
        UIManager uiManager;
        SelectRole selectRole;
        ContentsItemManager itemManager;
        //소켓        
        //전차장일경우 상위체계모의로 접속한다
        //사수 조종수 일 경우 전차장에게 접속한다.
        //상위체계모의일 경우는 열 필요가 없다.
        public Socket clientUDPSocket;

        public string serverIP;
        public int udpPort;

        private Thread dataSendThread; //데이타 송수신 쓰레드
        private Thread dataRecvThread; //데이타 송수신 쓰레드

        public Stack<PACKET_TYPE> SendMessageStack;
        public Stack<Packet> ReceiveMessageStack;

        public IPEndPoint serverIPEndPoint; //보낼곳의 주소
        EndPoint remoteEndPoint; //받은곳의 주소

        public bool connected = false;

        // Start is called before the first frame update
        void Start()
        {
            uiManager = FindObjectOfType<UIManager>();
            itemManager = FindObjectOfType<ContentsItemManager>();
            selectRole = FindObjectOfType<SelectRole>();

            SendMessageStack = new Stack<PACKET_TYPE>();
            ReceiveMessageStack = new Stack<Packet>();

            if (File.Exists(INIParser.NetSessionPath) == false)
            {
                //파일이없는 경우
                Debug.Log("Load NetSetting file failed : " + INIParser.NetSessionPath);                
            }
            else
            {
                serverIP = INIParser.Read(INIParser.NetSessionPath, "UDPCLIENT", "IP");
                string strPort = INIParser.Read(INIParser.NetSessionPath, "UDPCLIENT", "PORT");
                udpPort = int.Parse(strPort);
            }
            StartConnect(serverIP, udpPort);

            dataSendThread = new Thread(ThreadSend);
            dataSendThread.Start();

            dataRecvThread = new Thread(ThreadRecv);
            dataRecvThread.Start();
        }

        private void OnApplicationQuit()
        {
            if (dataSendThread != null)
            {
                dataSendThread.Abort();
            }

            if (dataRecvThread != null)
            {
                dataRecvThread.Abort();
            }
        }

        private void ThreadSend()
        {
            while (true)
            {
                //전차장일경우는 자차정보를 상위로 보내는 위치가 여기다
                //사수 조종수일 경우는 보낼것이 없다
                //상위체계모의일 경우는 연동객체를 융합하여 전차장에게 보내는 위치가여기다 
                //if (connected)
                //{
                //    //훈련이 시작되면 보낸다
                //    if (VtasMain.instance.controlState == CONTROL_COMMAND.TRAINING_START)
                //    {
                //        SendMessageStack.Push(PACKET_TYPE.H2T_MOVING_OBJECT);
                //    }
                //}
                Thread.Sleep(33);
            }
        }

        private void ThreadRecv()
        {
            while (true)
            {
                if (connected)
                {
                    ReceiveData();
                }
                Thread.Sleep(0);
            }
        }

        public void StartConnect(string serverIP, int port)
        {
            serverIPEndPoint = new IPEndPoint(IPAddress.Parse(serverIP), port);
            clientUDPSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            connected = true;

            string str = $"IP: {serverIP}, Port: {port} setting UDP client..";
            print(str);

        }

        public void DisConnect()
        {
            clientUDPSocket.Shutdown(SocketShutdown.Both);
            clientUDPSocket.Close();

            connected = false;

            string str = $"IP: {serverIPEndPoint.Address}, Port: {serverIPEndPoint.Port} 서버 연결 해제됨";
            print(str);

        }

        public bool SendData(Packet packet)
        {
            if (clientUDPSocket == null)
            {
                print("can not connect to udp server..");
                return false;
            }

            //드롭다운의 인덱스를 받아 비주기 메시지 전달
            try
            {
                byte[] SendPacket = new byte[NetworkManager.MAX_PACKET_SIZE];
                //메세지 보냄                    

                //보내는 패킷들을 구분하여 직렬화 하는 부분

                if (packet is H2TMovingObject)
                {
                    H2TMovingObject ownshipInfo = (H2TMovingObject)packet;
                    Packet.Serialize(ownshipInfo).CopyTo(SendPacket, 0);
                }

                clientUDPSocket.SendTo(SendPacket, SendPacket.Length, SocketFlags.None, serverIPEndPoint);

                IPEndPoint localEp = (IPEndPoint)clientUDPSocket.LocalEndPoint;
                string str = "send UDP packet ip : " + localEp.Address.ToString() + " port : " + localEp.Port;
                print(str);

                return true;
            }
            catch (Exception e)
            {
                Debug.Log(e.Message);
                return false;
            }

        }

        public void ReceiveData()
        {
            byte[] packetData = new byte[NetworkManager.MAX_PACKET_SIZE];

            EndPoint remoteEP = new IPEndPoint(IPAddress.None, 0);

            if (clientUDPSocket.LocalEndPoint == null) return;

            //데이터 수신
            int recvcnt = clientUDPSocket.ReceiveFrom(packetData, ref remoteEP);

            //서버로부터 데이터를 받았다
            if (recvcnt > 0)
            {
                Packet packet = (Packet)Packet.Deserialize(packetData);
                ReceiveMessageStack.Push(packet);
            }

        }
        //전차장일때 상위체계로부터 받음
        public void ProcessReceivePacket(Packet packet)
        {
            if (packet != null)
            {
                switch (packet.packetType)
                {
                    case PACKET_TYPE.U2L_MOVING_OBJECT:
                        U2LMovingObject ownshipInfo = (U2LMovingObject)packet;//리스트를 추가한 객체를 받음

                        var peerIdList = uiManager.overlayIconManager.peerIdList;//id를 저장할 리스트                          
                        if (peerIdList.Contains(ownshipInfo.objectID) == false)//리스트가 해당 객체를 가지고있는지 찾음.
                        {                         
                            peerIdList.Add(ownshipInfo.objectID);//리스트에 추가 
                            IconInfo[] oldIcon = uiManager.networkManager.udpServer.uiContainer.GetComponentsInChildren<IconInfo>(); //기존의 아이콘을 지움
                            for (int i = 0; i < oldIcon.Length; i++)
                            {
                                Destroy(oldIcon[i].gameObject);
                            }
                            for (int i = 0; i < peerIdList.Count; i++) //상위로부터 받은 아이디만큼 다시 그림
                            {
                                if (ownshipInfo.objectID == 0) continue; //상위체계는 그리지않음.
                                GameObject go = Instantiate(itemManager.peerSymbol, uiManager.overlayIconManager.SymbolContainer);//아이콘을 생성
                                go.GetComponent<IconInfo>().userId = peerIdList[i];//객체의 아이디를 부여
                                if (MyInfo.instance.myId == go.GetComponent<IconInfo>().userId) Destroy(go); //자차객체와 동일한 아이디를 가졌으면 삭제
                                uiManager.overlayIconManager.peerIconList.Add(go);//리스트에 추가                                   
                            }
                        }
                        else//있으면 정보를 갱신 
                        {
                            for (int i = 0; i < ownshipInfo.peerIconList.Count; i++)
                            {
                                for (int j = 0; j < uiManager.overlayIconManager.peerIconList.Count; j++)//아이콘이 존재한다면
                                {
                                    GameObject obj = uiManager.overlayIconManager.peerIconList[j]; //아이콘 리스트를 읽어옴   
                                    if (obj == null) uiManager.overlayIconManager.peerIconList.Remove(obj); //null객체 삭제                                   
                                    if (ownshipInfo.peerIconList[i].objectID == obj.GetComponent<IconInfo>().userId)//리스트에서 생성한 객체를 찾음
                                    {
                                        Vector3 unityPos;
                                        unityPos = VtasMapManager.Instance.GPStoUCS(new Vector2((float)ownshipInfo.peerIconList[i].locationLatitude, (float)ownshipInfo.peerIconList[i].locationLongitude));// 위/경도를 다시 유니티 좌표로 바꾼 코드 투명도 아이콘 생성좌표와 일치시킴 
                                        Vector2 iconPos = uiManager.rightPanel.overlayIcon.GetScreenPosition(unityPos);
                                        obj.GetComponent<IconInfo>().myPosition = unityPos;
                                        obj.transform.position = iconPos;
                                        obj.GetComponent<IconInfo>().myRotation = (new Vector3(ownshipInfo.peerIconList[i].orientationPitch, ownshipInfo.peerIconList[i].orientationHeading, ownshipInfo.peerIconList[i].orientationRoll));
                                        obj.transform.rotation = Quaternion.Euler(new Vector3(ownshipInfo.peerIconList[i].orientationPitch, ownshipInfo.peerIconList[i].orientationHeading, -ownshipInfo.peerIconList[i].orientationRoll));
                                        obj.GetComponent<IconInfo>().timeLimit = 0;
                                        uiManager.overlayIconManager.UpdateObjectInfo();
                                    }
                                }
                            }                    
                        }
                        break;
                }      
            }
        }
    }
}

