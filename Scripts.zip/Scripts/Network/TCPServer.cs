using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

namespace Vtas
{
    public class TCPServer : MonoBehaviour
    {     
        //소켓        
        public Socket serverTCPSocket; //호스트들을 접속시킬 소켓
        ButtonManager buttonManager;
        public int tcpPort;
        NetworkManager networkManager;
        UIManager uiManager;
        MessageManager messageManager;
        ContentsItemManager itemManager;
        //접속한 체계모의 클라이언트들
        //전차장일 경우 호스트와 하위 사수조종수가 붙는다
        //상위체계모의일 경우 모든 전차장들이 붙는다.
        //사수 조종수일경우 사용되지 않는다.
        public List<Socket> listBMS = new List<Socket>();
        SelectRole selectRole;

        string RecordCoord, lon, lat;//좌표를 기록하기 위한 임시 변수, 적발견보고, 장애물보고의 좌표값이 string으로 들어오기때문에
                                     //string으로 받고 유니티 좌표로 변환한 이후에, 지도상에 띄워야한다.

        private void Awake()
        {         
            selectRole = FindObjectOfType<SelectRole>();
            buttonManager = FindObjectOfType<ButtonManager>();
            networkManager = FindObjectOfType<NetworkManager>();
            uiManager = FindObjectOfType<UIManager>();
            messageManager = FindObjectOfType<MessageManager>();
            itemManager = FindObjectOfType<ContentsItemManager>();
        }
        // Start is called before the first frame update
        void Start()
        {

            if (File.Exists(INIParser.NetSessionPath) == false)
            {
                //파일이없는 경우
                Debug.Log("Load NetSetting file failed : " + INIParser.NetSessionPath);
            }
            else
            {
                string strPort = INIParser.Read(INIParser.NetSessionPath, "TCPSERVER", "PORT");
                tcpPort = int.Parse(strPort);
            }

            InitServer(tcpPort); //서버를 초기화  
  
        }

        // Update is called once per frame
        void Update()
        {
            //접속 대기
            Accepted();

            //alive check
            CheckClientsList();

            ReceiveData();
        }

        public void InitServer(int port)
        {
            serverTCPSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            IPEndPoint ipep = new IPEndPoint(IPAddress.Any, port);
            serverTCPSocket.Bind(ipep);
            serverTCPSocket.Listen(100);

            Debug.Log("TCP 서버를 초기화하는 중..."); //버튼을 눌렀을 때 처음은 이 함수를 실행, 다음 버튼을 눌렀을때는 다른 함수를 실행해야함.

            //alive를 생성
            StartCoroutine(SendAliveMessage(5.0f));
        }

        //연결된 사람들을 myClient 리스트에 추가
        void Accepted()
        {
            List<Socket> clients = new List<Socket>();
            clients.Add(serverTCPSocket);
            Socket.Select(clients, null, null, 1000);

            for (int i = 0; i < clients.Count; i++)
            {
                Socket newSocket = ((Socket)clients[i]).Accept();
                if (!listBMS.Contains(newSocket))
                    listBMS.Add(newSocket);

                IPEndPoint localEp = (IPEndPoint)clients[i].LocalEndPoint;
                Debug.Log("새로운 호스트가 접속했습니다. ip : " + localEp.Address.ToString() + " port : " + localEp.Port);
                //접속한 유저들의 리스트를 만들어야한다.
                GameObject go = Instantiate(itemManager.connectingUserInfoPrefab, uiManager.nonMsgPanel.targetAssignmentPanel.contentsTr);
                uiManager.nonMsgPanel.targetAssignmentPanel.ConnectingUserList.Add(go);
                //go.GetComponentsInChildren<TextMeshProUGUI>()[1].text = go.GetComponent<UserInfo>().affiliatedUnit;
                //go.GetComponentsInChildren<TextMeshProUGUI>()[2].text = go.GetComponent<UserInfo>().userName;
            }
        }

        //연결이 끊긴 사람들을 목록에서 제거 
        void CheckClientsList()
        {
            for (int i = 0; i < listBMS.Count; i++)
            {
                Socket socket = listBMS[i];
                if (!IsConnected(socket))
                {
                    if (listBMS.Contains(socket))
                        listBMS.Remove(socket);

                    Debug.Log("접속 중인 유저를 확인하는 중..." + "// 현재 유저 " + i + " 명");
                }
            }
        }

        //연결여부 확인
        bool IsConnected(Socket socket)
        {
            try
            {
                if (socket != null && socket.Connected)
                {
                    if (socket.Poll(0, SelectMode.SelectRead))//poll은 소켓 객체를 확인하여 메소드 콜이 블록을 거는지 또는 성공적으로 완료했는지를 확인한다.
                    {   //0은 특정 이벤트에 대해 소켓을 수지하는 시간, selcetmode의 SelectRead는 Accept메소드가 성공, 읽어들일 데이터가 있을때, 연결이 종료 되었을때 true를 반환한다.
                        return !(socket.Receive(new byte[1], SocketFlags.Peek) == 0); //SelectWrite는 Connect에 성공했을때, 소켓으로 데이터를 전송할 수 있을 때 true를 반환한다.                
                    }  //Error는 Connect가 실패했을때, 대역외 데이터가 있는 소켓의 OutOfBandInline속성이 설정되지 않았을때 true를 반환한다.

                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        //전차장/상위체계모의의 경우이기때문에 여기를 집중적으로 봐야한다.
        public void ReceiveData()
        {
            for (int i = 0; i < listBMS.Count; i++)
            {
                Socket socket = listBMS[i];
                if (socket.Available != 0) //socket.Available => Receive전에 데이터를 읽기 위해 대기 중 여부를 확인하는 방법. 없으면 많이 느려짐.
                {
                    byte[] packetData = new byte[NetworkManager.MAX_PACKET_SIZE];

                    int ReceiveData = socket.Receive(packetData);

                    //클라이언트로부터 데이터를 받았다
                    if (ReceiveData > 0)
                    {
                        Packet packet = (Packet)Packet.Deserialize(packetData);
                        var symbol = uiManager.nonMsgPanel.targetAssignmentPanel;
                        if (packet == null) return;

                        switch (packet.packetType)
                        {
                            #region ICD영역
                            case PACKET_TYPE.H2T_INSTRUCTOR_MISSION_COMMAND:
                                H2TInstructorMissionCommand instructorMissionCommand = (H2TInstructorMissionCommand)packet;

                                print("objectID : " + instructorMissionCommand.objectID);
                                print("objectType : " + instructorMissionCommand.objectType);
                                print("missionType : " + instructorMissionCommand.missionType);
                                print("FirstLatitude : " + instructorMissionCommand.locationFirstLatitude);
                                print("FirstLongtitude : " + instructorMissionCommand.locationFirstLongtitude);
                                print("SecondLatitude : " + instructorMissionCommand.locationSecondLatitude);
                                print("SecondLongtitude : " + instructorMissionCommand.locationSecondLongtitude);
                                print("data : " + instructorMissionCommand.data);

                                //데이터를 받았는데 어떻게 처리할것인가?
                                print("Data Recieve " + packet.packetType.ToString());
                                break;

                            case PACKET_TYPE.H2T_LEVEL_SET_COMMAND:
                                H2TLevelSetCommand levelSetCommand = (H2TLevelSetCommand)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            case PACKET_TYPE.H2T_SCENARIO_LOADING:
                                H2TScenarioLoading scenarioLoading = (H2TScenarioLoading)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            case PACKET_TYPE.H2T_SIM_RUN_CONTROL_COMMAND:
                                H2TSimRunControlCommand simRunControlCommand = (H2TSimRunControlCommand)packet;
                                print("Data Recieve " + simRunControlCommand.packetType.ToString());
                                print("controlCommand " + simRunControlCommand.controlCommand.ToString());

                                switch (simRunControlCommand.controlCommand)
                                {
                                    case CONTROL_COMMAND.TRAINING_START: //훈련시작      
                                        break;
                                    case CONTROL_COMMAND.TRAINING_PAUSE: //일시정지
                                        break;
                                    case CONTROL_COMMAND.TRAINING_END: //종로
                                        break;
                                    case CONTROL_COMMAND.TRAINING_RECOVERY: //재시작
                                        break;
                                    case CONTROL_COMMAND.MISSION_START: break;
                                }

                                break;
                            case PACKET_TYPE.H2T_MOVING_OBJECT:
                                H2TMovingObject ownshipInfo = (H2TMovingObject)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            case PACKET_TYPE.H2T_WEAPON_FIRE:
                                H2TWeaponFireCommand weaponFireCommand = (H2TWeaponFireCommand)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            case PACKET_TYPE.H2T_OWNSHIP_FIRE_IMPACT:
                                H2TOwnshipFireImpact ownshipFireImpact = (H2TOwnshipFireImpact)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            case PACKET_TYPE.H2T_ENVIRONMENT_STATUS_CHANGE:
                                H2TEnvironmentStatusChange environmentStatusChange = (H2TEnvironmentStatusChange)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            case PACKET_TYPE.H2T_MISSION_COMPLETE:
                                H2TMissionComplete missionComplete = (H2TMissionComplete)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            case PACKET_TYPE.H2T_OWNSHIP_STATUS_CHANGE:
                                H2TOwnshipStatusChange ownershipStatusChange = (H2TOwnshipStatusChange)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                break;
                            #endregion

                            #region 체계모의 영역
                            case PACKET_TYPE.FIND_ENEMY:

                                FIND_ENEMY findEnemyPacket = (FIND_ENEMY)packet;
                                print("Data Recieve " + packet.packetType.ToString());                                
                                //전문 수신시 적 위치 표시        
                                if (findEnemyPacket.targetPosition != "")
                                {
                                    GameObject Symbolpref = Instantiate(uiManager.GetComponent<ContentsItemManager>().overlayIconPrefab, uiManager.nonMsgPanel.symbolContainer.transform);//아이콘 생성
                                    Transform objectTransform = Symbolpref.GetComponent<Transform>(); //트랜스폼을 참조
                                    RecordCoord = findEnemyPacket.targetPosition; //경위도 좌표를 받음
                                    float lat_f = float.Parse(RecordCoord.Trim().Substring(0, 9));
                                    float lon_f = float.Parse(RecordCoord.Trim().Substring(10));
                                    Vector3 gps = VtasMapManager.Instance.GPStoUCS(new Vector2(lat_f,lon_f));//위경도를 유니티 좌표로
                                    objectTransform.position = gps; // vector3좌표로 바꾼 후 
                                    Symbolpref.GetComponent<Image>().sprite = uiManager.rightPanel.overlayIcon.enemySymbol;
                                    Symbolpref.GetComponent<Image>().color = Color.red;
                                    Symbolpref.transform.position = uiManager.rightPanel.overlayIcon.GetScreenPosition(objectTransform.position); //3d에서 2d로 좌표로 변환
                                    Symbolpref.GetComponent<IconInfo>().myPosition = uiManager.rightPanel.overlayIcon.GetWorldPosition(Symbolpref.transform.position); //ui좌표로 변환
                                    Symbolpref.GetComponent<IconInfo>().index = messageManager.messageIndex;
                                    symbol.msgSymbolList.Add(Symbolpref); // 일단은 별도의 리스트를 만들어서 투명도와 따로 관리함,
                                }
                                networkManager.PacketToData(findEnemyPacket);
                                break;
                            case PACKET_TYPE.TRANSFER:
                                TRANSFER transferPacket = (TRANSFER)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(transferPacket);
                                break;
                            case PACKET_TYPE.CBRN_FIRST:
                                CBRN_FIRST cbrnFirstPacket = (CBRN_FIRST)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(cbrnFirstPacket);                         
                                break;
                            case PACKET_TYPE.CBRN_SCOUT:
                                CBRN_SCOUT cbrnScoutPacket = (CBRN_SCOUT)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(cbrnScoutPacket);

                                break;
                            case PACKET_TYPE.MY_STATE:
                                MY_STATE myStatePacket = (MY_STATE)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(myStatePacket);
                                break;
                            case PACKET_TYPE.OBSTACLE:
                                OBSTACLE obstaclePacket = (OBSTACLE)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                
                                if (obstaclePacket.obtaclePosition != "")
                                {
                                    GameObject Symbolpref = Instantiate(uiManager.GetComponent<ContentsItemManager>().overlayIconPrefab, uiManager.nonMsgPanel.symbolContainer.transform);//아이콘 생성
                                    Transform objectTransform = Symbolpref.GetComponent<Transform>(); //트랜스폼을 참조
                                    RecordCoord = obstaclePacket.obtaclePosition; //좌표를 받음
                                    lat = RecordCoord.Trim().Substring(0, 9);
                                    lon = RecordCoord.Trim().Substring(11);
                                    float lat_f = float.Parse(lat);
                                    float lon_f = float.Parse(lon);
                                    Vector3 gps = VtasMapManager.Instance.GPStoUCS(new Vector2(lat_f, lon_f));//위경도를 유니티 좌표로
                                    objectTransform.position = gps; // vector3좌표로 바꾼 후 
                                    Symbolpref.GetComponent<Image>().sprite = uiManager.rightPanel.overlayIcon.obstacleSymbol; //아이콘 심볼 교체
                                    Symbolpref.GetComponent<Image>().color = Color.green;                    //색 넣어줌
                                    Symbolpref.transform.position = uiManager.rightPanel.overlayIcon.GetScreenPosition(objectTransform.position); //3d에서 2d로 좌표로 변환
                                    Symbolpref.GetComponent<IconInfo>().myPosition = uiManager.rightPanel.overlayIcon.GetWorldPosition(Symbolpref.transform.position); //ui좌표로 변환
                                    Symbolpref.GetComponent<IconInfo>().index = messageManager.messageIndex;// 전문과 같은 인덱스 부여 
                                    symbol.msgSymbolList.Add(Symbolpref); // 일단은 별도의 리스트를 만들어서 투명도와 따로 관리함,                       
                                }
                                networkManager.PacketToData(obstaclePacket);
                                //장애물 위치 표시                      
                                break;
                            case PACKET_TYPE.TARGET_DAMAGE:
                                TARGET_DAMAGE TargetDamagePacket = (TARGET_DAMAGE)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(TargetDamagePacket);
                                break;
                            case PACKET_TYPE.NO_FORMAT:
                                NO_FORMAT noFormatPacket = (NO_FORMAT)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(noFormatPacket);
                                break;
                            case PACKET_TYPE.FIRE_SUPPORT:
                                FIRE_SUPPORT fireSupportPacket = (FIRE_SUPPORT)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(fireSupportPacket);
                                break;
                            case PACKET_TYPE.COMMAND:
                                COMMAND commandPacket = (COMMAND)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(commandPacket);
                                break;
                            //case PACKET_TYPE.OVERLAY:
                            //    OVERLAY overlayPacket = (OVERLAY)packet;
                            //    print("Data Recieve " + packet.packetType.ToString()); // <= 투명도는 좌표와 그 좌표에 속해 있는 정보를 보내야함 최대 40개
                            //    networkManager.PacketToData(overlayPacket);
                            //    break;
                            case PACKET_TYPE.MARGINAL_NOTE: //난외주기 -> 투명도 필수
                                MARGINAL_NOTE marginalNotePacket = (MARGINAL_NOTE)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.PacketToData(marginalNotePacket);
                                break;
                           //조종수가 서버의 역할을 할 일이 없으므로 이동로는 받지 않음
                                #endregion
                        }
                        uiManager.nonMsgPanel.alarmPanel.ReceiveReportCheck();
                        //수신 후 버튼 갱신처리
                        messageManager.messageIndex++;
                        messageManager.msgCount++;
                        buttonManager.ChangeButton();
                    }
                }
            }
        }
        //상위 체계-> 전차장 /// 소대장 -> 소대원 // 전차장 -> 조종수 
        public void SendData(Packet packet)
        {
            if (selectRole.setRole == SelectRole.SELECT_ROLE.TANK_CREW) //조종수일 경우 패킷데이터를 보내지 않음
            {
                return;
            }
            for (int i = 0; i < listBMS.Count; i++)
            {   //드롭다운의 인덱스를 받아 비주기 메시지 전달
                try
                {
                    Socket socket = listBMS[i];

                    byte[] SendPacket = new byte[NetworkManager.MAX_PACKET_SIZE];
                    //메세지 보냄                    

                    //alive신호는 있어야하는데 호스트가 이게없으면 다시 접속을 시도하는지는 모를일이다 
                    //if (packet is T2HSystemStatusInfo)
                    //{
                    //    T2HSystemStatusInfo systemStatusInfo = (T2HSystemStatusInfo)packet;
                    //    Packet.Serialize(systemStatusInfo).CopyTo(SendPacket, 0);
                    //}

                    //socket.Send(SendPacket, 0, SendPacket.Length, SocketFlags.None);
                    #region 체계모의 영역
                    if (packet is FIND_ENEMY)
                    {
                        FIND_ENEMY enemySighting = (FIND_ENEMY)packet;
                        Packet.Serialize(enemySighting).CopyTo(SendPacket, 0);
                    }
                    else if (packet is TRANSFER)
                    {
                        TRANSFER transfer = (TRANSFER)packet;
                        Packet.Serialize(transfer).CopyTo(SendPacket, 0);
                    }
                    else if (packet is CBRN_FIRST)
                    {
                        CBRN_FIRST cbrnFirst = (CBRN_FIRST)packet;
                        Packet.Serialize(cbrnFirst).CopyTo(SendPacket, 0);
                    }
                    else if (packet is CBRN_SCOUT)
                    {
                        CBRN_SCOUT cbrnScout = (CBRN_SCOUT)packet;
                        Packet.Serialize(cbrnScout).CopyTo(SendPacket, 0);
                    }
                    else if (packet is MY_STATE)
                    {
                        MY_STATE myState = (MY_STATE)packet;
                        Packet.Serialize(myState).CopyTo(SendPacket, 0);
                    }
                    else if (packet is OBSTACLE)
                    {
                        OBSTACLE obstacle = (OBSTACLE)packet;
                        Packet.Serialize(obstacle).CopyTo(SendPacket, 0);
                    }
                    else if (packet is TARGET_DAMAGE)
                    {
                        TARGET_DAMAGE damagedTarget = (TARGET_DAMAGE)packet;
                        Packet.Serialize(damagedTarget).CopyTo(SendPacket, 0);
                    }
                    else if (packet is NO_FORMAT)
                    {
                        NO_FORMAT noForm = (NO_FORMAT)packet;
                        Packet.Serialize(noForm).CopyTo(SendPacket, 0);
                    }
                    else if (packet is FIRE_SUPPORT)
                    {
                        FIRE_SUPPORT fireSupport = (FIRE_SUPPORT)packet;
                        Packet.Serialize(fireSupport).CopyTo(SendPacket, 0);
                    }
                    else if (packet is COMMAND)
                    {
                        COMMAND command = (COMMAND)packet;
                        Packet.Serialize(command).CopyTo(SendPacket, 0);
                    }
                    //else if (packet is OVERLAY)
                    //{
                    //    OVERLAY overlay = (OVERLAY)packet;
                    //    Packet.Serialize(overlay).CopyTo(SendPacket, 0);
                    //}
                    else if (packet is MARGINAL_NOTE)
                    {
                        MARGINAL_NOTE marginalNote = (MARGINAL_NOTE)packet;
                        Packet.Serialize(marginalNote).CopyTo(SendPacket, 0);
                    }
                    else if (packet is WAY_POINT) //이동로 => 전차장이 조종수에게 보낼 수 있는건 이것뿐
                    {
                        WAY_POINT wayPoint = (WAY_POINT)packet;
                        Packet.Serialize(wayPoint).CopyTo(SendPacket, 0);
                    }              
                    #endregion
                    socket.Send(SendPacket, 0, SendPacket.Length, SocketFlags.None);

                    IPEndPoint localEp = (IPEndPoint)socket.LocalEndPoint;
                    print("send alive ip : " + localEp.Address.ToString() + " port : " + localEp.Port);

                }
                catch (Exception e)
                {
                    Debug.Log(e.Message);
                    return;
                }
            }
        }

        //각 메시지의 주기에 따라 일정한 시간마다 주기메시지를 보내는 코루틴
        //연결에 성공하면 주기적으로 호출됨
        IEnumerator SendAliveMessage(float _cycle)
        {
            while (true)
            {
                yield return new WaitForSeconds(_cycle);

                //var alivePacket = new T2HSystemStatusInfo();
                //alivePacket.eStatusInfo = STATUS_INFO.HEARTBIT;
                //SendData(alivePacket);
            }
        }
    }
}
