using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

namespace Vtas
{
    public class TCPClient : MonoBehaviour
    {
        //소켓        
        //전차장일경우 상위체계모의로 접속한다
        //사수 조종수 일 경우 전차장에게 접속한다.
        //상위체계모의일 경우는 열 필요가 없다.
        public Socket clientTCPSocket; //호스트들을 접속시킬 소켓

        public string serverIP;
        public int tcpPort;
        SelectRole selectRole;
        //
        public IPEndPoint serverIPEndPoint;
        public EndPoint remoteEndPoint;

        private Thread connectThread; //클라 연결 쓰레드

        public bool connected = false;
        ButtonManager buttonManager;
        UIManager uiManager;
        NetworkManager networkManager;
        MessageManager messageManager;

        string RecordCoord, lon, lat;//좌표를 기록하기 위한 임시 변수, 적발견보고, 장애물보고의 좌표값이 string으로 들어오기때문에
                                     //string으로 받고 유니티 좌표로 변환한 이후에, 지도상에 띄워야한다.

        private void Awake()
        {
            selectRole = FindObjectOfType<SelectRole>();
          
            buttonManager = FindObjectOfType<ButtonManager>();
            uiManager = FindObjectOfType<UIManager>();
            networkManager = FindObjectOfType<NetworkManager>();
            messageManager = FindObjectOfType<MessageManager>();
        }
        // Start is called before the first frame update
        void Start()
        {

            if (File.Exists(INIParser.NetSessionPath) == false)
            {
                //파일이없는 경우
                Debug.Log("Load NetSetting file failed : " + INIParser.NetSessionPath);
            }
            else
            {
                serverIP = INIParser.Read(INIParser.NetSessionPath, "TCPCLIENT", "IP");
                string strPort = INIParser.Read(INIParser.NetSessionPath, "TCPCLIENT", "PORT");
                tcpPort = int.Parse(strPort);
            }

            clientTCPSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            serverIPEndPoint = new IPEndPoint(IPAddress.Parse(serverIP), tcpPort);

            connectThread = new Thread(TryConnectClient);
            connectThread.Start();
            
        }

        // Update is called once per frame
        void Update()
        {           
            if (connected)
            {
               if (clientTCPSocket.Available != 0) //socket.Available => Receive전에 데이터를 읽기 위해 대기 중 여부를 확인하는 방법. 없으면 많이 느려짐.
                {
                    ReceiveData();
                }
              
            }          
        }

        void OnApplicationQuit()
        {
            if (connectThread != null)
            {
                connectThread.Abort();
            }

            DisConnect();
        }

        void TryConnectClient()
        {
            while (connected == false)
            {
                string str = $"IP: {serverIP}, Port: {tcpPort} Attempting to connect to TCP server..";
                print(str);

                var result = clientTCPSocket.BeginConnect(serverIPEndPoint, null, null);

                bool success = result.AsyncWaitHandle.WaitOne(3000, true);
                if (success)
                {
                    clientTCPSocket.EndConnect(result);

                    str = $"IP: {serverIP}, Port: {tcpPort} connected TCP server";
                    print(str);

                    connected = true;
                }
                else
                {
                    clientTCPSocket.Close();
                    clientTCPSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                }

                //Thread.Sleep(3000);
            }
        }

        public void DisConnect()
        {
            if(connected)
            {
                clientTCPSocket.Shutdown(SocketShutdown.Both);
                clientTCPSocket.Close();

                string str = $"IP: {serverIPEndPoint.Address}, Port: {serverIPEndPoint.Port} 서버 연결 해제됨";
                print(str);

                connected = false;
            }
        }
        //사수는 전문을 받을 일이 없으므로 제외한다. 조종수는 이동로 하나만 포함한다.  
        public void ReceiveData()
        {
            byte[] packetData = new byte[NetworkManager.MAX_PACKET_SIZE];          
            {   //데이터 수신
                int ReceiveData = clientTCPSocket.Receive(packetData);
                //서버로부터 데이터를 받았다
                if (ReceiveData > 0)
                {
                    Packet packet = (Packet)Packet.Deserialize(packetData);
                    var symbol = uiManager.nonMsgPanel.targetAssignmentPanel;
                    if (packet == null) return;

                    //메인쓰레드에서 돌고잇으므로 리스트로 담는 구조로 변경 요망
                    switch (packet.packetType)
                    {
                        //case PACKET_TYPE.SYSTEM_STATUS_INFO:
                        //    PacketSystemStatusInfo systemStatusInfo = (PacketSystemStatusInfo)packet;

                        //    string str = "Alive Data Receive " + systemStatusInfo.eStatusInfo;
                        //    print(str);
                        //    break;
                        #region 체계모의 영역
                        case PACKET_TYPE.FIND_ENEMY:
                            FIND_ENEMY findEnemyPacket = (FIND_ENEMY)packet;
                            print("Data Recieve " + packet.packetType.ToString());                       
                            ////표적할당을 받았을때 적 위치 표시
                            //if (findEnemyPacket.targetPosition != "")
                            //{
                            //    GameObject Symbolpref = Instantiate(uiManager.GetComponent<ContentsItemManager>().overlayIconPrefab, uiManager.nonMsgPanel.symbolContainer.transform);//아이콘 생성
                            //    Transform objectTransform = Symbolpref.GetComponent<Transform>(); //트랜스폼을 참조
                            //    RecordCoord = findEnemyPacket.targetPosition; //경위도 좌표를 받음
                            //    float lat_f = float.Parse(RecordCoord.Trim().Substring(0, 9));
                            //    float lon_f = float.Parse(RecordCoord.Trim().Substring(11));
                            //    Vector3 gps = VtasMapManager.Instance.GPStoUCS(new Vector2(lat_f, lon_f));//위경도를 유니티 좌표로
                            //    objectTransform.position = gps; // vector3좌표로 바꾼 후 
                            //    Symbolpref.GetComponent<Image>().sprite = uiManager.rightPanel.overlayIcon.enemySymbol;
                            //    Symbolpref.GetComponent<Image>().color = Color.red;
                            //    Symbolpref.transform.position = uiManager.rightPanel.overlayIcon.GetScreenPosition(objectTransform.position); //3d에서 2d로 좌표로 변환
                            //    Symbolpref.GetComponent<IconInfo>().myPosition = uiManager.rightPanel.overlayIcon.GetWorldPosition(Symbolpref.transform.position); //ui좌표로 변환
                            //    //Symbolpref.GetComponent<IconInfo>().targetSymbol = true;
                            //    Symbolpref.GetComponent<IconInfo>().index = messageManager.messageIndex;
                            //    symbol.msgSymbolList.Add(Symbolpref); // 일단은 별도의 리스트를 만들어서 투명도와 따로 관리함,
                            //    Debug.Log("Created Symbol");
                            //}
                            networkManager.PacketToData(findEnemyPacket); //패킷 데이터를 메세지 데이터로
                            break;
                        case PACKET_TYPE.TRANSFER:
                            TRANSFER transferPacket = (TRANSFER)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(transferPacket);
                            break;
                        case PACKET_TYPE.CBRN_FIRST:
                            CBRN_FIRST cbrnFirstPacket = (CBRN_FIRST)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(cbrnFirstPacket);
                            break;
                        case PACKET_TYPE.CBRN_SCOUT:
                            CBRN_SCOUT cbrnScoutPacket = (CBRN_SCOUT)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(cbrnScoutPacket);                            
                            break;
                        case PACKET_TYPE.MY_STATE:
                            MY_STATE myStatePacket = (MY_STATE)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(myStatePacket);
                            break;
                        case PACKET_TYPE.OBSTACLE:
                            OBSTACLE obstaclePacket = (OBSTACLE)packet;
                            print("Data Recieve " + packet.packetType.ToString());

                            ////표적할당을 받았을때 장애물 위치 표시
                            //if (obstaclePacket.obtaclePosition != "")
                            //{
                            //    GameObject Symbolpref = Instantiate(uiManager.GetComponent<ContentsItemManager>().overlayIconPrefab, uiManager.nonMsgPanel.symbolContainer.transform);//아이콘 생성
                            //    Transform objectTransform = Symbolpref.GetComponent<Transform>(); //트랜스폼을 참조
                            //    RecordCoord = obstaclePacket.obtaclePosition; //좌표를 받음
                            //    lat = RecordCoord.Trim().Substring(0, 9);
                            //    lon = RecordCoord.Trim().Substring(11);
                            //    float lat_f = float.Parse(lat);
                            //    float lon_f = float.Parse(lon);
                            //    Vector3 gps = VtasMapManager.Instance.GPStoUCS(new Vector2(lat_f, lon_f));//위경도를 유니티 좌표로
                            //    objectTransform.position = gps; // vector3좌표로 바꾼 후 
                            //    Symbolpref.GetComponent<Image>().sprite = uiManager.rightPanel.overlayIcon.obstacleSymbol; //아이콘 심볼 교체
                            //    Symbolpref.GetComponent<Image>().color = Color.green;                    //색 넣어줌
                            //    Symbolpref.transform.position = uiManager.rightPanel.overlayIcon.GetScreenPosition(objectTransform.position); //3d에서 2d로 좌표로 변환
                            //    Symbolpref.GetComponent<IconInfo>().myPosition = uiManager.rightPanel.overlayIcon.GetWorldPosition(Symbolpref.transform.position); //ui좌표로 변환
                            //    //Symbolpref.GetComponent<IconInfo>().targetSymbol = true;
                            //    Symbolpref.GetComponent<IconInfo>().index = messageManager.messageIndex;// 전문과 같은 인덱스 부여 
                            //    symbol.msgSymbolList.Add(Symbolpref); // 일단은 별도의 리스트를 만들어서 투명도와 따로 관리함,
                            //}
                            networkManager.PacketToData(obstaclePacket);
                            break;
                        case PACKET_TYPE.TARGET_DAMAGE:        //표적 피해 패킷 데이터를 받으면
                            TARGET_DAMAGE TargetDamagePacket = (TARGET_DAMAGE)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(TargetDamagePacket);
                            break;
                        case PACKET_TYPE.NO_FORMAT:
                            NO_FORMAT noFormatPacket = (NO_FORMAT)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(noFormatPacket);
                            break;
                        case PACKET_TYPE.FIRE_SUPPORT:
                            FIRE_SUPPORT fireSupportPacket = (FIRE_SUPPORT)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(fireSupportPacket);
                            break;
                        case PACKET_TYPE.COMMAND:
                            COMMAND commandPacket = (COMMAND)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(commandPacket);
                            break;
                        case PACKET_TYPE.OVERLAY:
                            OVERLAY overlayPacket = (OVERLAY)packet;
                            //go.GetComponent<ReportPanelItem>().reportPriority = ReportPanelItem.Priority.FOURTH;//3순위
                            print("Data Recieve " + packet.packetType.ToString()); // <= 투명도는 좌표와 그 좌표에 속해 있는 정보를 보내야함 최대 40개
                            networkManager.PacketToData(overlayPacket);
                            break;
                        case PACKET_TYPE.MARGINAL_NOTE: //난외주기 -> 투명도 필수
                            MARGINAL_NOTE marginalNotePacket = (MARGINAL_NOTE)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            networkManager.PacketToData(marginalNotePacket);
                            break;
                        case PACKET_TYPE.TARGET_ASSIGNMENT://상위로부터 받음
                            TARGET_ASSIGNMENT target_AssignmentPacket = (TARGET_ASSIGNMENT)packet;
                            print("Data Recieve " + packet.packetType.ToString());
                            break;
                        #endregion
                    }
                    uiManager.nonMsgPanel.alarmPanel.ReceiveReportCheck();
                    //수신 후 버튼 갱신처리
                    messageManager.messageIndex++;
                    messageManager.msgCount++;
                    buttonManager.ChangeButton();
                    
                //조종수일 경우 이동로만 받는다.
                if (selectRole.setRole == SelectRole.SELECT_ROLE.TANK_CREW)
                {
                    switch (packet.packetType)
                        {
                            case PACKET_TYPE.WAY_POINT: ///조종수는 전차장으로부터 이동로만 받는다
                                WAY_POINT wayPoint = (WAY_POINT)packet;
                                print("Data Recieve " + packet.packetType.ToString());
                                networkManager.ReceiveWayPointData(packet);
                                break;
                        }
                    }
                }
            }
        }
        // 전차장일 경우 상위체계로 향하는 전문을 쓴다.   
        public bool SendData(Packet packet)
        {
            if (clientTCPSocket == null)
            {
                print("can not connect to server..");
                return false;
            }
            if (!clientTCPSocket.Connected)
            {
                print("can not connect to server..");
                return false;
            }
            //호스트에게 전달받은 메세지를 그대로 바이패스 시킨다 => 체계모의 끼리 주고 받을패킷은 따로 빼야하는가?
            try
            {
                byte[] SendPacket = new byte[NetworkManager.MAX_PACKET_SIZE];
                //메세지 보냄                    

                if (packet is H2TInstructorMissionCommand)
                {
                    H2TInstructorMissionCommand instructorMissionCommand = (H2TInstructorMissionCommand)packet;
                    Packet.Serialize(instructorMissionCommand).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TLevelSetCommand)
                {
                    H2TLevelSetCommand levelSetCommand = (H2TLevelSetCommand)packet;
                    Packet.Serialize(levelSetCommand).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TScenarioLoading)
                {
                    H2TScenarioLoading scenarioLoading = (H2TScenarioLoading)packet;
                    Packet.Serialize(scenarioLoading).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TSimRunControlCommand)
                {
                    H2TSimRunControlCommand simRunControlCommand = (H2TSimRunControlCommand)packet;
                    Packet.Serialize(simRunControlCommand).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TMovingObject)
                {
                    H2TMovingObject ownshipInfo = (H2TMovingObject)packet;
                    Packet.Serialize(ownshipInfo).CopyTo(SendPacket, 0);               
                }
                else if (packet is H2TWeaponFireCommand)
                {
                    H2TWeaponFireCommand weaponFireCommand = (H2TWeaponFireCommand)packet;
                    Packet.Serialize(weaponFireCommand).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TOwnshipFireImpact)
                {
                    H2TOwnshipFireImpact ownshipFireImpact = (H2TOwnshipFireImpact)packet;
                    Packet.Serialize(ownshipFireImpact).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TOwnshipStatusChange)
                {
                    H2TOwnshipStatusChange ownshipStatusChange = (H2TOwnshipStatusChange)packet;
                    Packet.Serialize(ownshipStatusChange).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TEnvironmentStatusChange)
                {
                    H2TEnvironmentStatusChange environmentStatusChange = (H2TEnvironmentStatusChange)packet;
                    Packet.Serialize(environmentStatusChange).CopyTo(SendPacket, 0);
                }
                else if (packet is H2TMissionComplete)
                {
                    H2TMissionComplete missionComplete = (H2TMissionComplete)packet;
                    Packet.Serialize(missionComplete).CopyTo(SendPacket, 0);
                }
                #region 체계모의 영역
                else if (packet is FIND_ENEMY)
                {
                    FIND_ENEMY enemySighting = (FIND_ENEMY)packet;
                    Packet.Serialize(enemySighting).CopyTo(SendPacket, 0);
                }
                else if (packet is TRANSFER)
                {
                    TRANSFER transfer = (TRANSFER)packet;
                    Packet.Serialize(transfer).CopyTo(SendPacket, 0);
                }
                else if (packet is CBRN_FIRST)
                {
                    CBRN_FIRST cbrnFirst = (CBRN_FIRST)packet;
                    Packet.Serialize(cbrnFirst).CopyTo(SendPacket, 0);
                }
                else if (packet is CBRN_SCOUT)
                {
                    CBRN_SCOUT cbrnScout = (CBRN_SCOUT)packet;
                    Packet.Serialize(cbrnScout).CopyTo(SendPacket, 0);
                }
                else if (packet is MY_STATE)
                {
                    MY_STATE myState = (MY_STATE)packet;
                    Packet.Serialize(myState).CopyTo(SendPacket, 0);
                }
                else if (packet is OBSTACLE)
                {
                    OBSTACLE obstacle = (OBSTACLE)packet;
                    Packet.Serialize(obstacle).CopyTo(SendPacket, 0);
                }
                else if (packet is TARGET_DAMAGE)
                {
                    TARGET_DAMAGE damagedTarget = (TARGET_DAMAGE)packet;
                    Packet.Serialize(damagedTarget).CopyTo(SendPacket, 0);
                }
                else if (packet is NO_FORMAT)
                {
                    NO_FORMAT noForm = (NO_FORMAT)packet;
                    Packet.Serialize(noForm).CopyTo(SendPacket, 0);
                }
                else if (packet is FIRE_SUPPORT)
                {
                    FIRE_SUPPORT fireSupport = (FIRE_SUPPORT)packet;
                    Packet.Serialize(fireSupport).CopyTo(SendPacket, 0);
                }
                else if (packet is COMMAND)
                {
                    COMMAND command = (COMMAND)packet;

                    Packet.Serialize(command).CopyTo(SendPacket, 0);
                }
                //else if (packet is OVERLAY)
                //{
                //    OVERLAY overlay = (OVERLAY)packet;
                //    Packet.Serialize(overlay).CopyTo(SendPacket, 0);
                //}
                else if (packet is MARGINAL_NOTE)
                {
                    MARGINAL_NOTE marginalNote = (MARGINAL_NOTE)packet;
                    Packet.Serialize(marginalNote).CopyTo(SendPacket, 0);
                }
                else if (packet is WAY_POINT) //이동로 => 전차장이 조종수에게 보낼 수 있는건 이것뿐
                {
                    WAY_POINT movingRoute = (WAY_POINT)packet;
                    Packet.Serialize(movingRoute).CopyTo(SendPacket, 0);
                }
                #endregion
                clientTCPSocket.Send(SendPacket, 0, SendPacket.Length, SocketFlags.None);

                IPEndPoint localEp = (IPEndPoint)clientTCPSocket.LocalEndPoint;
                string str = "send packet ip : " + localEp.Address.ToString() + " port : " + localEp.Port;
                print(str);
                
                return true;
            }
            catch (Exception e)
            {
                Debug.Log(e.Message); 
                return false;
            }
        }
    }
}
