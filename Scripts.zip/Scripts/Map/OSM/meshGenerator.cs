using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class meshGenerator : MonoBehaviour
{
	public static MeshData GenerateTerrainMesh(float x_start_pos, float z_start_pos,int x_size, int z_size, float [,] _Data)
	{		
		float grid_size = 0.01f; //30����

		MeshData meshData = new MeshData(x_start_pos, z_start_pos, x_size + 1, z_size + 1);
		int vertexIndex = 0;

		for (int z = 0; z < z_size; z++)
		{
			for (int x = 0; x < x_size; x++)
			{
				float height = _Data[x, (z_size - 1) - z] * grid_size * 1f/30f;
				meshData.vertices[vertexIndex] = new Vector3(
					x_start_pos + (x * grid_size),
					height,
					z_start_pos - (z * grid_size)
					);

				meshData.uvs[vertexIndex] = new Vector2(x / (float)x_size, -z / (float)z_size);

				if (x < x_size - 1 && z < z_size - 1)
				{					
					meshData.AddTriangle(vertexIndex + x_size + 1, vertexIndex + 1, vertexIndex);
					meshData.AddTriangle(vertexIndex + x_size, vertexIndex + x_size + 1, vertexIndex);
				}

				//���� ������
				if(meshData.minHeight > height) meshData.minHeight = height;
				if(meshData.maxHeight < height) meshData.maxHeight = height;

				vertexIndex++;
			}
		}

		return meshData;

	}

	//������ġ(����Ƽ ��ǥ����), ��ũ��(����Ƽ ��ǥ���� ), �׸��������(����ũ��), ����������
	public static MeshData GenerateTerrainMesh(Vector2 start_pos, Vector2 world_size, Vector2Int grid_size,  float[,] _Data)
	{
		
		MeshData meshData = new MeshData(start_pos.x, start_pos.y, grid_size.x + 1, grid_size.y + 1);
		int vertexIndex = 0;

		//���� �ʻ���� ����Ѵ�.
		float tile_factor_x = world_size.x / (grid_size.x - 1);
		float tile_factor_y = world_size.y / (grid_size.y - 1);

		for (int z = 0; z < grid_size.y; z++)
		{
			for (int x = 0; x < grid_size.x; x++)
			{
				float height = _Data[x, (grid_size.y - 1) - z] * 1/GlobalDefine.WORLD_SCALE * 1f / 30f;

				meshData.vertices[vertexIndex] = new Vector3(
					start_pos.x + x * tile_factor_x,
					height,
					start_pos.y - z * tile_factor_y
					);

				meshData.uvs[vertexIndex] = new Vector2(x / (float)(grid_size.x - 1), -z / (float)(grid_size.y - 1));

				if (x < grid_size.x - 1 && z < grid_size.y - 1)
				{
					meshData.AddTriangle(vertexIndex + grid_size.x + 1, vertexIndex + 1, vertexIndex);
					meshData.AddTriangle(vertexIndex + grid_size.x, vertexIndex + grid_size.x + 1, vertexIndex);
				}

				//���� ������
				if (meshData.minHeight > height) meshData.minHeight = height;
				if (meshData.maxHeight < height) meshData.maxHeight = height;

				vertexIndex++;
			}
		}

		return meshData;

	}

}

public class MeshData
{
	public float start_x = 0;
	public float start_z = 0;

	public float minHeight = 9999;
	public float maxHeight = -9999;

	public Vector3[] vertices;
	public int[] triangles;
	public Vector2[] uvs;

	int triangleIndex;

	public MeshData(float x, float z, int size_x, int size_z)
	{
		start_x = x;
		start_z = z;

		vertices = new Vector3[size_x * size_z];
		uvs = new Vector2[size_x * size_z];
		triangles = new int[(size_x - 1) * (size_z - 1) * 6];

	}

	

	public void AddTriangle(int a, int b, int c)
	{
		if(triangleIndex >= 0 && triangleIndex < triangles.Length)
        {
			triangles[triangleIndex] = a;
			triangles[triangleIndex + 1] = c;
			triangles[triangleIndex + 2] = b;
			triangleIndex += 3;
		}
	}

	Vector3[] CalculateNormals()
    {
		Vector3[] vertexNormals = new Vector3[vertices.Length];
		int triangleCount = triangles.Length / 3;
		for(int i = 0; i < triangleCount; i++)
        {
			int normalTriangleIndex = i * 3;
			int vertexIndexA = triangles[normalTriangleIndex];
			int vertexIndexB = triangles[normalTriangleIndex + 1];
			int vertexIndexC = triangles[normalTriangleIndex + 2];

			Vector3 triangleNormal = SurfaceNormalFromIndices(vertexIndexA, vertexIndexB, vertexIndexC);
			vertexNormals[vertexIndexA] += triangleNormal;
			vertexNormals[vertexIndexB] += triangleNormal;
			vertexNormals[vertexIndexC] += triangleNormal;
		}

		for (int i = 0; i < vertexNormals.Length; i++)
        {
			vertexNormals[i].Normalize();
        }

		return vertexNormals;
    }

	Vector3 SurfaceNormalFromIndices(int indexA, int indexB, int indexC)
    {
		Vector3 pointA = vertices[indexA];
		Vector3 pointB = vertices[indexB];
		Vector3 pointC = vertices[indexC];

		Vector3 sideAB = pointB - pointA;
		Vector3 sideAC = pointC - pointA;
		return Vector3.Cross(sideAB, sideAC).normalized;
    }

	public Mesh CreateMesh()
	{
		Mesh mesh = new Mesh();
		mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32; //ū�������� �޽�����
		mesh.vertices = vertices;
		mesh.triangles = triangles;
		mesh.uv = uvs;
		mesh.normals = CalculateNormals();
		//mesh.RecalculateNormals();

		return mesh;
	}

}
