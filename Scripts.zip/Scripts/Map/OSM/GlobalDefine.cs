using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using UnityEngine;

public class DMS
{
    public int degree;
    public int minutes;
    public float seconds;

    public static double[] DMStoDegree(DMS[] dms)
    {
        double [] degree = new double[2];
        
        degree[0] = dms[0].degree + (double)dms[0].minutes / 60 + (double)dms[0].seconds / 3600;
        degree[1] = dms[1].degree + (double)dms[1].minutes / 60 + (double)dms[1].seconds / 3600;

        return degree;
    }

    public static DMS[] DegreetoDMS(double lon, double lat)
    {
        DMS[] dms = new DMS[2];

        dms[0] = new DMS();
        dms[0].degree = (int)lon;
        dms[0].minutes = (int)((lon - dms[0].degree) *60);
        dms[0].seconds = (float)(((lon - dms[0].degree) *60 - dms[0].minutes) * 60);

        dms[1] = new DMS();
        dms[1].degree = (int)lat;
        dms[1].minutes = (int)((lat - dms[1].degree) * 60);
        dms[1].seconds = (float)(((lat - dms[1].degree) * 60 - dms[1].minutes) * 60);

        return dms;
    }

    //�� ��ǥ�� �Ÿ��� �ʷ� ��ȯ 
    public static int DistanceToSecond(double dist)
    {       
        return (int)(dist*3600);
    }
}

public static class GlobalDefine
{
    public static float WORLD_SCALE = 100.0f;
    public static float WORLD_FACTOR_X = 1f;
    public static float WORLD_FACTOR_Y = 1f;

    public static Vector2 WorldToTilePos(double lon, double lat, int zoom)
    {
        Vector2 p = new Vector2();
        p.x = (float)((lon + 180.0) / 360.0 * (1 << zoom));
        p.y = (float)((1.0 - Math.Log(Math.Tan(lat * Math.PI / 180.0) +
            1.0 / Math.Cos(lat * Math.PI / 180.0)) / Math.PI) / 2.0 * (1 << zoom));

        return p;
    }

    public static Vector2 TileToWorldPos(double tile_x, double tile_y, int zoom)
    {
        Vector2 p = new Vector2();
        double n = Math.PI - ((2.0 * Math.PI * tile_y) / Math.Pow(2.0, zoom));

        p.x = (float)((tile_x / Math.Pow(2.0, zoom) * 360.0) - 180.0);
        p.y = (float)(180.0 / Math.PI * Math.Atan(Math.Sinh(n)));

        return p;
    }

    public static Vector3 WorldPosToUnityPos(double lon, double lat)
    {
        //����Ƽ��ǥ�迡�� 1���� 3600���ε� �������� �����Ƿ� 1���� 36�̴�
        Vector3 newPos = Vector3.zero;
        newPos.x = (float)(lon * 3600f * WORLD_FACTOR_X) / WORLD_SCALE;
        newPos.y = 0;
        newPos.z = (float)(lat * 3600f * WORLD_FACTOR_Y) / WORLD_SCALE;

        return newPos;
    }

    public static Vector2 UnityPosToWorldPos(Vector3 pos)
    {
        Vector2 newPos = Vector2.zero;
        newPos.x = (pos.x / 3600) * WORLD_SCALE;
        newPos.y = (pos.z / 3600) * WORLD_SCALE;

        return newPos;
    }

    //Ÿ�ϻ���� �ʷ� ��ȯ
    //0,0 �� 1,1�� Ÿ���� ��ǥ���� �̿��ؼ� ���� ��������  
    public static Vector2 GetTileSizeToSecond(int x, int y, int zoom)
    {
        Vector2 size = Vector2.zero;

        if (zoom == 0)
        {
            float max_world_size = 360 * 3600; //360���� �ʷ� ��ȯ 

            size.x = max_world_size * WORLD_FACTOR_X / WORLD_SCALE;
            size.y = max_world_size * WORLD_FACTOR_Y / WORLD_SCALE;
        }
        else
        {
            int max_size = (int)Math.Pow(2.0, zoom);
            if (x >= max_size) return size;
            if (y >= max_size) return size;

            //�κ����� ���̸� ������ ����Ѵ�
            Vector2 posA = TileToWorldPos(x,y,zoom);
            Vector3 posA_result = WorldPosToUnityPos(posA.x, posA.y);

            Vector2 posB = TileToWorldPos(x + 1,y + 1,zoom);
            Vector3 posB_result = WorldPosToUnityPos(posB.x, posB.y);

            size = posA_result - posB_result;

            size.x = Math.Abs(posA_result.x - posB_result.x);
            size.y = Math.Abs(posA_result.z - posB_result.z);
        }

        return size;
    }
}
