using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public static class MapCoordinate
{
    public static Vector3 worldPoint;
    public static float latitude, longtitude;
    public static float lat_d, lat_m, lat_s,lon_d, lon_m, lon_s;
       
    public static void UpdateCoord(Vector3 mousePos)
    {
        worldPoint = Camera.main.ScreenToWorldPoint(new Vector3(mousePos.x, mousePos.y, -1f));           
        Vector2 gps = VtasMapManager.Instance.UCStoGPS(worldPoint);
            
        //������ ���
        latitude = gps.x;
        longtitude = gps.y;

        lat_d = (int)latitude;
        lat_m = (latitude - lat_d) * 60;
        lat_s = ((latitude - (int)latitude) * 60 - (int)lat_m) * 60;

        lon_d = (int)longtitude;
        lon_m = (longtitude - lon_d) * 60;
        lon_s = ((longtitude - (int)longtitude) * 60 - (int)lon_m) * 60;
    }
}
