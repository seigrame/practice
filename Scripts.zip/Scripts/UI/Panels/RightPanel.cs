using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine;

public class RightPanel : MonoBehaviour
{
    public OverlayIcon overlayIcon;
    public OverlayToolBoxUI overlayTool;
    public GameObject OverlayContainer;

    public Sprite openImage, closeImage;
    public void FoldAndUnFoldUI(GameObject go)
    {
        if (go.activeSelf == true) { go.SetActive(false);}
        else { go.SetActive(true); }
    }
    public void ChangeImage(Image btnImg)
    {
        if (btnImg.sprite == closeImage) { btnImg.sprite = openImage;}
        else { btnImg.sprite = closeImage; }
    }
}
