using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CenterPanel : MonoBehaviour
{
    ButtonManager buttonManager;
    public MessageBoxPanelUI messageBoxPanel;
    public newMessageUI newMessagePanel;
    public ToggleGroup msgTypeSelectToggle;
    //�� ���� ���
    public FindEnemyUI findEnemyPanel;
    public TransferUI transferPanel;
    public CBRNFirstUI cbrnFirstPanel;
    public CBRNScoutUI cbrnScoutPanel;
    public myStateUI myStatePanel;
    public ObstacleUI obstaclePanel;
    public TargetDamageUI targetDamagePanel;
    public WeatherUI weatherPanel;
    public noformUI noformPanel;
    public FireSupportUI fireSupportPanel;
    public CommandPanelUI commandPanel;
    public MarginalNoteUI marginalNotePanel;

    private void Start()
    {
        buttonManager = FindObjectOfType<ButtonManager>();
    }
    public void MsgToggleSelect()
    {
        newMessagePanel.toggles[0].isOn = true;
        newMessagePanel.GetComponentInChildren<ToggleGroup>().GetFirstActiveToggle().Select();
    }
    //������ �г� Ȱ��ȭ
    public void newMessagePanelActive()
    {
        if (messageBoxPanel.gameObject.activeSelf == true)
        {
            messageBoxPanel.gameObject.SetActive(false);
        }
        buttonManager.CreateReport();
        if (newMessagePanel.gameObject.activeSelf == false)
        {
            newMessagePanel.gameObject.SetActive(true);
        }
    }

}
