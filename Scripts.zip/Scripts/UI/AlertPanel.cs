using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlertPanel : MonoBehaviour
{

    // Start is called before the first frame update
    private void OnEnable()
    {
        StartCoroutine(AlertPanelActiveRoutine());
    }

    IEnumerator AlertPanelActiveRoutine()
    {
        yield return new WaitForSeconds(2.0f);
        this.gameObject.SetActive(false);
    }
}
