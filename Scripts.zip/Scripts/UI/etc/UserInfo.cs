using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UserInfo : MonoBehaviour
{
    public int index;
    public string affiliatedUnit; //�ҼӺδ�
    public string userName;
}
