using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.EventSystems;

public class InputCoordUI : MonoBehaviour
{
    public string clickCoord;
    public Vector3 ClickPoint;
    //MGRS  
    public TMP_InputField regionNum_MGRS, areaChar_MGRS, grid_MGRS, east_MGRS, north_MGRS;
    //UTM   
    public TMP_InputField regionNum_UTM, areaChar_UTM, east_UTM, north_UTM;
    //������
    public TMP_InputField lon_do, lon_min, lon_sec, lat_do, lat_min, lat_sec;
    WayPointManager wayPointManager;
    ButtonManager buttonManager;
    UIManager uiManager;

    public void Start()
    {
        wayPointManager = FindObjectOfType<WayPointManager>();
        buttonManager = FindObjectOfType<ButtonManager>();
        uiManager = FindObjectOfType<UIManager>();
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            MapCoordinate.UpdateCoord(Input.mousePosition);
            clickCoord = MapCoordinate.latitude.ToString("F6") + " " + MapCoordinate.longtitude.ToString("F6");
            lon_do.text = MapCoordinate.lon_d.ToString();
            lon_min.text = MapCoordinate.lon_m.ToString("F0");
            lon_sec.text = MapCoordinate.lon_s.ToString("F0");
            lat_do.text = MapCoordinate.lat_d.ToString();
            lat_min.text = MapCoordinate.lat_m.ToString("F0");
            lat_sec.text = MapCoordinate.lat_s.ToString("F0");
            ClickPoint = MapCoordinate.worldPoint;
            if (buttonManager.prevButtonState == BottomButtonState.WRITE_WAY_POINT)
            {
                wayPointManager.DrawWayPoint();
            }
            else if ((buttonManager.prevButtonState == BottomButtonState.FIND_ENEMY)
                || (buttonManager.prevButtonState == BottomButtonState.OBSTACLE))
            {
                uiManager.PrintSymbolRoutine();
            }
        } 
    }
}
