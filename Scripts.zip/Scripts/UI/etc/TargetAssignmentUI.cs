using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class TargetAssignmentUI : MonoBehaviour
{
    public TMP_InputField targetPosition;
    public Toggle[] toggles;
    public Transform contentsTr;
    public List<GameObject> ConnectingUserList = new List<GameObject>();

    MessageManager messageManager;
    public List<GameObject> msgSymbolList = new List<GameObject>();
    private void Start()
    {
        toggles = this.transform.Find("Contents").transform.Find("SelectBoxArea").GetComponentsInChildren<Toggle>();
        messageManager = FindObjectOfType<MessageManager>();
        this.gameObject.SetActive(false);
    }
    private void OnEnable()
    {
         StartCoroutine(toggleValueChange());
    }
    private void OnDisable()
    {
        StopCoroutine(toggleValueChange());
    }
    IEnumerator toggleValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                switch (obj.name)
                {
                    case "Toggle_1":                  
                        toggles[0].isOn = true;
                        break;
                    case "Toggle_2":
                        toggles[1].isOn = true;
                        break;
                    case "Toggle_3":
                        toggles[2].isOn = true;
                        break;
                    case "Toggle_4":
                        toggles[3].isOn = true;
                        break;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
    public void ShowConnectingUserList() //����Ʈ�� �߰��� ��ü��ŭ �����������
    {
        Transform route = contentsTr;
        if (route.transform.childCount <= 0) //�������� ��ü�� ������ ����
        {
            return;
        }
        else // ������ ������ ���� �迭�� ����
        {
            Button[] itemButtons = route.GetComponentsInChildren<Button>();

            for (int i = 0; i < itemButtons.Length; i++)
            {
                itemButtons[i].GetComponent<RectTransform>().sizeDelta = new Vector2(itemButtons[i].GetComponent<RectTransform>().sizeDelta.x, 45f);//Container���� Content�� ������ rect��ǥ�� �̻������� ������ ������Ų ��
                itemButtons[i].GetComponent<RectTransform>().localPosition = new Vector3(itemButtons[i].GetComponent<RectTransform>().localPosition.x, itemButtons[i].GetComponent<RectTransform>().localPosition.y, 0);
            }           
            itemButtons[0].Select();
        }       
    }

    public void ClearSymbol()
    {
        for (int i = 0; i < msgSymbolList.Count; i++)
        {
            if (msgSymbolList[i] == null)
            {
                msgSymbolList.Remove(msgSymbolList[i]);
            }
            for (int j = 0; j < messageManager.msgList.Count; j++)
            {
                if (messageManager.msgList[j] == null)
                {
                    messageManager.msgList.Remove(messageManager.msgList[j]);
                }
                if (msgSymbolList[i].GetComponent<IconInfo>().index == messageManager.msgList[j].index)
                {
                    messageManager.msgList.Remove(messageManager.msgList[j]); //���� ����
                }
            }
            Destroy(msgSymbolList[i].gameObject);        //������ ����
        }
        msgSymbolList.Clear(); //������ ����Ʈ �ʱ�ȭ
    }

    public void ChangeSymbolColor(GameObject go)
    {
        if (go.GetComponent<Image>().color == Color.red)
        {
            go.GetComponent<Image>().color = new Color(255f / 255f, 150f / 255f, 150f / 255f, 255 / 255f);
        }
        else if (go.GetComponent<Image>().color == Color.green)
        {
            go.GetComponent<Image>().color = new Color(150f / 255f, 255f / 255f, 150f / 255f, 255 / 255f);
        }
    }
}
