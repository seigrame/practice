using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class MessageAlarm : MonoBehaviour
{
    TextMeshProUGUI myText;
    Image myImage;
    // Start is called before the first frame update
    void Start()
    {
        myImage = GetComponent<Image>();
        myText = GetComponentInChildren<TextMeshProUGUI>();
        myText.text = "0";

        StartCoroutine(ChangeColor());
    }
    //�ϴ� �ڷ�ƾ���� ����. �ڵ尡 �þ ���ŷӰ�����, ������ ���������� �Լ��� üũ�ϴ°� �� ȿ�����ϰ� 
    IEnumerator ChangeColor()
    {
        WaitForSeconds wfs = new WaitForSeconds(.2f);
        while (true)
        {
            if (myText.text != "0")
            {
                myImage.color = Color.red;
                myText.color = Color.white;
            }
            else
            {
                myImage.color = new Vector4(225 / 255f, 245 / 255f, 245 / 255f, 255 / 255f);
                myText.color = Color.black;
            }
            yield return wfs;
        }
    }
}
