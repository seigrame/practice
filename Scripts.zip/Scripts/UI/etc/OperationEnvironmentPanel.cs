using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class OperationEnvironmentPanel : MonoBehaviour
{
    //���ȯ�濡�� ����� ���������� ���� ��/���� ��Ŷ�� �ڵ����Ե� �� �ֵ��� ó���ؾ��Ѵ�.

    public ButtonManager buttonManager;
    public GameObject setting, pos, reg, clear, ver; //5���� �г�
    private void OnEnable()
    {
        ClearDropdownList();
        AddDropdownList();
        StartCoroutine(StateValueChange());
        StartCoroutine(MinimapValueChange());
        StartCoroutine(RankValueChange());
        StartCoroutine(SendValueChange()); 

    }
    private void OnDisable()
    {
        StopCoroutine(StateValueChange());
        StopCoroutine(MinimapValueChange());
        StopCoroutine(RankValueChange());
        StopCoroutine(SendValueChange());
    }
    #region �� �̵� ���� 
    //�ν����Ϳ��� ��ư �̺�Ʈ�� ���� ����
    public void UserSettingButtonClick()
    { 
        buttonManager.currentButtonState = BottomButtonState.OPERATION_ENVIRONMENT_SETTINGS;
        buttonManager.ChangeButton();
    }

    public void SendPositionInfoButtonClick()
    {
        buttonManager.currentButtonState = BottomButtonState.OPERATION_ENVIRONMENT_POSITION_REPORT;
        buttonManager.ChangeButton();
    }
    public void UserInfoButtonClick()
    {
        buttonManager.currentButtonState = BottomButtonState.OPERATION_ENVIRONMENT_USER_REGISTRATION;
        buttonManager.ChangeButton();
    }
    public void EmergencyClearanceButtonClick()
    {
        buttonManager.currentButtonState = BottomButtonState.OPERATION_ENVIRONMENT_EMERGENCY_CLEARANCE;
        buttonManager.ChangeButton();
    }
    public void VersionButtonClick()
    {
        buttonManager.currentButtonState = BottomButtonState.OPERATION_ENVIRONMENT_VERSION;
        buttonManager.ChangeButton();
    }
    #endregion

    #region ��������
    public Toggle StateDisplayToggle, StateHideToggle, MinimapDisplayToggle, MinimapHideToggle;
    public TMP_InputField year, month, day, hour, min, sec;
    IEnumerator StateValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                switch (obj.name)
                {
                    case "Display_c":
                        StateDisplayToggle.isOn = true;
                        break;
                    case "Hide_c":
                        StateHideToggle.isOn = true;
                        break;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
    IEnumerator MinimapValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                switch (obj.name)
                {
                    case "Display_m":
                        StateDisplayToggle.isOn = true;
                        break;
                    case "Hide_m":
                        StateHideToggle.isOn = true;
                        break;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
    #endregion

    #region ��ġ���� ����
    public TMP_InputField timeText, distanceText, validTimeText;
    public ToggleGroup rankToggle, SendStateToggle;
    public Toggle battalionToggle, companyToggle, platoonLeaderToggle, platoonMemberToggle , CycleSendToggle, CycleEndToggle;
    IEnumerator RankValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                switch (obj.name)
                {
                    case "battalionCommander":
                        battalionToggle.isOn = true;
                        break;
                    case "companyCommander":
                        companyToggle.isOn = true;
                        break;
                    case "platoonLeader":
                        platoonLeaderToggle.isOn = true;
                        break;
                    case "platoonMember":
                        platoonMemberToggle.isOn = true;
                        break;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
    IEnumerator SendValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                switch (obj.name)
                {
                    case "CycleSend":
                        CycleSendToggle.isOn = true;
                        break;
                    case "CycleEnd":
                        CycleEndToggle.isOn = true;
                        break;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
    #endregion

    #region ����ڵ�� ����
    public TMP_Dropdown jobPosDD;
    public TMP_InputField affiliatedSquad, affiliatedPlatoon, affiliatedCompany, affiliatedBattalion, userName, UpperNet1, UpperNet2, UpperNet3, UpperNet4, SubNet1, SubNet2, SubNet3, SubNet4;
  
    //��й�ȣ�»������ �����Ƿ� ��ǲ�ʵ带 �������� �ʾ���. 

    List<string> jobPosList = new List<string> { "�����", "�ߴ���", "�Ҵ���", "�Ҵ��" };

    private void ClearDropdownList()
    {
        jobPosDD.ClearOptions();
    }
    private void AddDropdownList()
    {
        jobPosDD.AddOptions(jobPosList);
    }
    #endregion

    #region ���Ұ� ����
    public Toggle EmergencyClearToggle;
    public void ClearanceButtonClick()
    {
        EmergencyClearToggle.isOn = true;
    }
#endregion
}
