using System;
using System.Collections;
using UnityEngine;
using TMPro;

//��¥ �ð� �ʱⰪ 
public class DateSettrings : MonoBehaviour
{
    public TextMeshProUGUI day,time;
    DateTime date = DateTime.Now;
    // Start is called before the first frame update
    void Start()
    {
        day.text = date.Year.ToString("D4") + "-" + date.Month.ToString("D2") + "-" + date.Day.ToString("D2");
        StartCoroutine(startClock());
    }

    IEnumerator startClock()
    {
        WaitForSeconds wfs = new WaitForSeconds(.5f);
        while (true)
        {
            date = DateTime.Now;
            time.text = date.Hour.ToString("D2") + ":" + date.Minute.ToString("D2") + ":" + date.Second.ToString("D2");
           
            yield return wfs;
        }
    }
}
