using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI.Extensions;

public class BMSGrid : MonoBehaviour
{
    public GameObject grid;
    public GameObject subGrid;
    
    // Update is called once per frame
    void Update()
    {
        GridUpdate();
    }

    void GridUpdate()
    {
        if (VtasMapManager.Instance.gridState == MAP_GRID.NONE) return;

        //������� �� ��ǥ�� ���ؼ� ��ũ�� ��ǥ�� ������ 
        Vector3 minPoint = Camera.main.WorldToScreenPoint(new Vector3(0, 0, 0));
        Vector3 maxPoint = Camera.main.WorldToScreenPoint(new Vector3(1000, 0, 1000));

        //�׸��带 �ʿ� ���� �ǽð����� �׸���
        RectTransform gridRectTransform = grid.GetComponent<RectTransform>();
        gridRectTransform.position = minPoint;
        gridRectTransform.sizeDelta = maxPoint - minPoint;

        RectTransform subGridRectTransform = subGrid.GetComponent<RectTransform>();
        subGridRectTransform.position = minPoint;
        subGridRectTransform.sizeDelta = maxPoint - minPoint;

        //1000���� ������ ���ΰ����� ���ϱ����ؼ� �� ��ǥ�� �����Ÿ��� �ľ��ؾ��Ѵ�.

        //���� wgs84��ǥ�� ���Ͱ��� ���� 
        Vector2 minGps = new Vector2((float)VtasMapManager.Instance.minLatitude, (float)VtasMapManager.Instance.minLongtitude);
        Vector2 maxGps = new Vector2((float)VtasMapManager.Instance.maxLatitude, (float)VtasMapManager.Instance.maxLongtitude);

        GPSEncoder.SetLocalOrigin(minGps);
        Vector3 minMeter = GPSEncoder.GPSToUCS(minGps);
        Vector3 maxMeter = GPSEncoder.GPSToUCS(maxGps);

        float gridx = Mathf.Abs(maxMeter.x - minMeter.x);
        float gridy = Mathf.Abs(maxMeter.z - minMeter.z);


        UIGridRenderer gridRenderer = grid.GetComponent<UIGridRenderer>();
        UIGridRenderer subGridRenderer = subGrid.GetComponent<UIGridRenderer>();

        //�׸��� ����
        if (VtasMapManager.Instance.gridState == MAP_GRID.M1000)
        {
            gridRenderer.GridColumns = (int)(gridx / 1000);
            gridRenderer.GridRows = (int)(gridy / 1000);

            //����׸��� ����
            if (VtasMapManager.Instance.subGridState == MAP_SUBGRID.D2)
            {
                subGridRenderer.GridColumns = (int)(gridx / 500);
                subGridRenderer.GridRows = (int)(gridy / 500);
            }
            else if(VtasMapManager.Instance.subGridState == MAP_SUBGRID.D5)
            {
                subGridRenderer.GridColumns = (int)(gridx / 200);
                subGridRenderer.GridRows = (int)(gridy / 200);
            }
            else if (VtasMapManager.Instance.subGridState == MAP_SUBGRID.D10)
            {
                subGridRenderer.GridColumns = (int)(gridx / 100);
                subGridRenderer.GridRows = (int)(gridy / 100);
            }
        }
        else if (VtasMapManager.Instance.gridState == MAP_GRID.M10000)
        {
            gridRenderer.GridColumns = (int)(gridx / 10000);
            gridRenderer.GridRows = (int)(gridy / 10000);

            //����׸��� ����
            if (VtasMapManager.Instance.subGridState == MAP_SUBGRID.D2)
            {
                subGridRenderer.GridColumns = (int)(gridx / 5000);
                subGridRenderer.GridRows = (int)(gridy / 5000);
            }
            else if (VtasMapManager.Instance.subGridState == MAP_SUBGRID.D5)
            {
                subGridRenderer.GridColumns = (int)(gridx / 2000);
                subGridRenderer.GridRows = (int)(gridy / 2000);
            }
            else if (VtasMapManager.Instance.subGridState == MAP_SUBGRID.D10)
            {
                subGridRenderer.GridColumns = (int)(gridx / 1000);
                subGridRenderer.GridRows = (int)(gridy / 1000);
            }
        }
    }
}
