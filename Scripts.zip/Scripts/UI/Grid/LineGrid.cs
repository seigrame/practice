using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineGrid : MonoBehaviour
{
    LineRenderer linerenderer;
    public float startRow, startCol;
    public int rowCount, colCount;
    public float gridSize;

    bool isGridActive = false;

    void initLineRenderder(LineRenderer lr)
    {
        lr.startWidth = lr.endWidth = 0.01f;
        lr.material.color = Color.black;
    }

    void MakeGrid(LineRenderer lr, float sr, float sc, int rowCount, int colCount)
    {
        List<Vector3> gridPos = new List<Vector3>();

        float endCol = sc + colCount * gridSize;

        gridPos.Add(new Vector3(sr, this.transform.position.y + 1.1f, sc));
        gridPos.Add(new Vector3(sr, this.transform.position.y + 1.1f, endCol));

        int toggle = -1;
        Vector3 currentPos = new Vector3(sr, this.transform.position.y + 1.1f, endCol);
        for (int i = 0; i < rowCount; i++)
        {
            Vector3 nextPos = currentPos;

            nextPos.x += gridSize;
            gridPos.Add(nextPos);

            nextPos.z += (colCount * toggle * gridSize);
            gridPos.Add(nextPos);

            currentPos = nextPos;
            toggle *= -1;
        }

        currentPos.x = sr;
        gridPos.Add(currentPos);

        int colToggle = toggle = 1;
        if (currentPos.z == endCol) colToggle = -1;
        
        for (int i = 0; i < colCount; i++)
        {
            Vector3 nextPos = currentPos;

            nextPos.z += (colToggle * gridSize);
            gridPos.Add(nextPos);

            nextPos.x += (rowCount * toggle * gridSize);
            gridPos.Add(nextPos);

            currentPos = nextPos;
            toggle *= -1;
        }
        lr.positionCount = gridPos.Count;
        lr.SetPositions(gridPos.ToArray());
    }
    // Start is called before the first frame update
    void Start()
    {
        linerenderer = this.GetComponent<LineRenderer>();
        initLineRenderder(linerenderer);

        MakeGrid(linerenderer, startRow, startCol, rowCount, colCount);
    }
    private void Update()
    {
        //�׽�Ʈ�� �����ϸ� ��ô�� ���� ���ڸ� �׷������ 
        if (rowCount + colCount > 0)
        {
            MakeGrid(linerenderer, startRow, startCol, rowCount, colCount);
        }
    }

    public void GridActive()
    {
        isGridActive = !isGridActive;
        if (isGridActive == true)
        {
            this.gameObject.SetActive(true);
            if (rowCount + colCount > 0)
            {
                MakeGrid(linerenderer, startRow, startCol, rowCount, colCount);
            }
        }
        else
        {
            this.gameObject.SetActive(false);
        }
    }
}
