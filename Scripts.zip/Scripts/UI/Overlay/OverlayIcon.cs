using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class OverlayIcon : MonoBehaviour
{
    Vector3 pos;
    Vector2 point = Vector2.zero;
    //���õ� ������ ������ �ҷ�����
    public WayPointManager wayPointManager;
    public UIManager uiManager;
    public ContentsItemManager itemManager;
    public ButtonManager buttonManager;
    public bool isDrawButtonActive = false;
    public Sprite peer, enemy, neutral, unknown, enemySymbol, obstacleSymbol;



    private void Update()
    {    
        if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject() && isDrawButtonActive == true)
        {
            pos = GetWorldPosition(Input.mousePosition);
            CreateIcon(pos);
        }  
        if (Input.GetMouseButton(1))
        {
            UpdateObjectInfo();
            UpdateWayPointInfo();
        }
    }
    public Vector2 GetScreenPosition(Vector3 worldPos)
    {
        point = Camera.main.WorldToScreenPoint(worldPos);
        return point;
    }
    public Vector3 GetWorldPosition(Vector2 uiPos)
    {
        Vector3 worldPos = Vector3.zero;
        //3d���� ��ġ�� ���Ѵ�.
        Ray ray = Camera.main.ScreenPointToRay(uiPos); 
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, Mathf.Infinity))
        {
            worldPos = hit.point;
        }
        return worldPos;
    }
    //�������� ��ġ ���� �ڵ�
    public void UpdateObjectInfo()
    {
        for (int i = 0; i < uiManager.overlayIconManager.iconList.Count; i++)
        {
            GameObject obj = uiManager.overlayIconManager.iconList[i];
            IconInfo objInfo = uiManager.overlayIconManager.iconList[i].GetComponentInChildren<IconInfo>();
            if (objInfo != null)
            {
                obj.transform.position = Camera.main.WorldToScreenPoint(objInfo.myPosition);//������ ���ڰ� ���� ��ǥ�� x,y,z��ǥ�� ���;��� //z���� �������ش�
                obj.transform.position = new Vector3(obj.transform.position.x, obj.transform.position.y, 0); //ui�� ������ ��ü�� ��ġ
            }
        }
    }
    //��������Ʈ ��ġ ����
    public void UpdateWayPointInfo()
    {
        for (int i = 0; i < wayPointManager.wayPointList.Count; i++)
        {
            GameObject obj = wayPointManager.wayPointList[i].gameObject;
            WayPointObjectInfo objInfo = wayPointManager.wayPointList[i].GetComponentInChildren<WayPointObjectInfo>();
            if (objInfo != null)
            {
                obj.transform.position = Camera.main.WorldToScreenPoint(objInfo.myPosition);//������ ���ڰ� ���� ��ǥ�� x,y,z��ǥ�� ���;���
                obj.transform.position = new Vector3(obj.transform.position.x, obj.transform.position.y, 0); //ui�� ������ ��ü�� ��ġ  
            }
        }
    }

    public void SaveOverlayIcons()
    {
        for (int i = 0; i < uiManager.overlayIconManager.iconList.Count; i++)
        {
            uiManager.overlayIconManager.saveIconList.Add(uiManager.overlayIconManager.iconList[i]);
        }//�������� �������� ���� 
        SaveOverayIconData();//�������� ���� ������ ����
    }

    public List<OverlayIconData> iconItemDataList = new List<OverlayIconData>();
    public void SaveOverayIconData()
    {
        iconItemDataList.Clear();//���� �ʱ�ȭ
        for (int i = 0; i < uiManager.overlayIconManager.iconList.Count; i++)
        {
            IconInfo icon = uiManager.overlayIconManager.iconList[i].GetComponent<IconInfo>();
            OverlayIconData PacketData = new OverlayIconData();  //������ ������ ������ ��ü�� ��´�.
            PacketData.iconIndex = icon.myIcon;
            PacketData.identity = icon.myIdentity;
            PacketData.PosX = icon.myPosition.x;
            PacketData.PosY = icon.myPosition.y;
            PacketData.PosZ = icon.myPosition.z;
            PacketData.RotX = icon.myRotation.x;
            PacketData.RotY = icon.myRotation.y;
            PacketData.RotZ = icon.myRotation.z;
            PacketData.ScaleX = icon.myScale.x;
            PacketData.ScaleY = icon.myScale.y;
            PacketData.ScaleZ = icon.myScale.z;
            if (iconItemDataList.Count < 40) iconItemDataList.Add(PacketData);//40������ ����Ʈ�� �߰�
            else return;
        }
    }
    public void CreateIcon(Vector3 pos)
    {
        GameObject go = Instantiate(itemManager.overlayIconPrefab, this.transform);
        go.GetComponent<Image>().sprite = uiManager.nonMsgPanel.overlayPanel.image_BG.sprite;
        go.GetComponent<Image>().color = uiManager.nonMsgPanel.overlayPanel.image_BG.color;
        isDrawButtonActive = false;
        buttonManager.currentButtonState = BottomButtonState.OVERLAY;
        go.transform.position = GetScreenPosition(pos);
        go.GetComponent<IconInfo>().myPosition = GetWorldPosition(go.transform.position);
        go.GetComponent<IconInfo>().myIcon = uiManager.rightPanel.overlayTool.iconIndex;
        go.GetComponent<IconInfo>().myIdentity = uiManager.nonMsgPanel.overlayPanel.identity;
        uiManager.overlayIconManager.iconList.Add(go);
    }
}
