using System.Collections.Generic;
using UnityEngine;
using Vtas;
using TMPro;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;

//�޼��� �Ŵ���, ������ �����͸� ���� ��´�. network�Ŵ����� ���⼭ �����͸� �޾Ƽ� �ְ� �޴´�.
public class MessageManager : MonoBehaviour
{
    ButtonManager buttonManager;
    UIManager uiManager;
    NetworkManager networkManager;
    public SelectRole selectRole;

    public string messageDataPath;

    public int msgCount = 0;//�� �޼����� ����
    public int messageIndex;//

    //���� �����͸� ������ ����Ʈ <- �ν����Ϳ��� ������ ������ �����ϰ� �ִ°���Ȯ��
    public List<MsgData> msgList = new List<MsgData>();
    public static int messageCount;
    public MsgData SaveMsgData;
    private void Start()
    {
        buttonManager = FindObjectOfType<ButtonManager>();
        uiManager = FindObjectOfType<UIManager>();
        networkManager = FindObjectOfType<NetworkManager>();
        selectRole = FindObjectOfType<SelectRole>();

        messageDataPath = Application.dataPath + "\\..\\Config\\DataFile.dat";
        LoadFile(); //���� �ε�

        if (msgList.Count > 0)
        {
            msgCount = msgList.Count;
            for (int i = 0; i < msgList.Count; i++)
            {
                msgList[i].index = messageIndex;
                messageIndex++;
            }
        }
    }

    //������ ������ �޼��� �����Ϳ� ����
    public MsgData SaveMessage()
    {      
        switch (buttonManager.currentButtonState)
        {
            #region �Ϲ� ���� ����
            case BottomButtonState.FIND_ENEMY:
                FindEnemyData findEnemyInfo = new FindEnemyData();
                var findEnemyUI = uiManager.centerPanel.findEnemyPanel; //ui���� �߰�
                findEnemyInfo.day = UInt16.Parse(findEnemyUI.day.text);
                findEnemyInfo.hour = UInt16.Parse(findEnemyUI.hour.text);
                findEnemyInfo.min = UInt16.Parse(findEnemyUI.min.text);
                findEnemyInfo.myPosition = findEnemyUI.myPos.text;
                findEnemyInfo.targetPosition = findEnemyUI.targetPos.text;
                findEnemyInfo.targetType1 = (TargetType)findEnemyUI.target1DD.value;
                findEnemyInfo.target1Count = UInt16.Parse(findEnemyUI.target1Count.text);
                findEnemyInfo.targetType2 = (TargetType)findEnemyUI.target2DD.value;
                findEnemyInfo.target2Count = UInt16.Parse(findEnemyUI.target2Count.text);
                findEnemyInfo.targetType3 = (TargetType)findEnemyUI.target3DD.value;
                findEnemyInfo.target3Count = UInt16.Parse(findEnemyUI.target3Count.text);
                findEnemyInfo.targetPosture = (TargetPosture)findEnemyUI.postrueDD.value;
                findEnemyInfo.targetDirection = (TargetDirection)findEnemyUI.directionDD.value;
                findEnemyInfo.note = findEnemyUI.note.text;
                findEnemyInfo.messageType = MessageType.FIND_ENEMY;
                findEnemyInfo.index = messageIndex;
                findEnemyInfo.messageCategoryTxt = "���߰�";
                findEnemyInfo.messageTitle = findEnemyInfo.note;
                findEnemyInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                if (buttonManager.prevButtonState != BottomButtonState.WHEN_CLICKED_EDIT_MESSAGE) //������ư�� ������ ���°� �ƴ϶�� ������.
                {
                    msgList.Add(findEnemyInfo);//ui�κ��� ������ �Է¹޾� ����
                }
               
                SaveMsgData = findEnemyInfo;
                buttonManager.prevButtonState = BottomButtonState.FIND_ENEMY_SAVE;//����
                break;
            case BottomButtonState.TRANSFER:
                TransferData transferInfo = new TransferData();
                var transferUI = uiManager.centerPanel.transferPanel;
                transferInfo.rescuePosition = transferUI.position.text;
                transferInfo.patient = UInt16.Parse(transferUI.patient.text);
                transferInfo.stretcher = UInt16.Parse(transferUI.stretcher.text);
                transferInfo.transferPriority = (TransferPriority)transferUI.priorityDD.value;
                transferInfo.mark = (AreaMark)transferUI.markDD.value;
                transferInfo.pollution = (Pollution)transferUI.pollutionDD.value;
                transferInfo.markColor = (MarkColor)transferUI.colorDD.value;
                transferInfo.areaSafetyLevel = (AreaSafetyLevel)transferUI.safetyDD.value;
                transferInfo.national = (National)transferUI.nationalDD.value;
                transferInfo.note = transferUI.note.text;
                transferInfo.messageType = MessageType.TRANSFER;
                transferInfo.index = messageIndex;
                transferInfo.messageCategoryTxt = "�ļ�";
                transferInfo.messageTitle = transferInfo.note;
                transferInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                msgList.Add(transferInfo);
                SaveMsgData = transferInfo;
                buttonManager.prevButtonState = BottomButtonState.TRANSFER_SAVE;
                break;
            case BottomButtonState.CBRN_FIRST:
                CBRN_FirstData cbrnFirstInfo = new CBRN_FirstData();   //��Ŷ ��ü ����
                var cbrnFirstUI = uiManager.centerPanel.cbrnFirstPanel; //ui���� �߰�
                cbrnFirstInfo.cbrnType = (CBRNType)cbrnFirstUI.CBRNTypeDD.value;
                cbrnFirstInfo.myPosition = cbrnFirstUI.myPosition.text;
                cbrnFirstInfo.myRotation_do = int.Parse(cbrnFirstUI.Pos_do.text);
                cbrnFirstInfo.myRotation_mil = int.Parse(cbrnFirstUI.Pos_Mil.text);
                cbrnFirstInfo.atkStartD = UInt16.Parse(cbrnFirstUI.atkStartDay.text);
                cbrnFirstInfo.atkStartH = UInt16.Parse(cbrnFirstUI.atkStartHour.text);
                cbrnFirstInfo.atkStartM = UInt16.Parse(cbrnFirstUI.atkStartMin.text);
                cbrnFirstInfo.atkEndD = UInt16.Parse(cbrnFirstUI.atkEndDay.text);
                cbrnFirstInfo.atkEndH = UInt16.Parse(cbrnFirstUI.atkEndHour.text);
                cbrnFirstInfo.atkEndM = UInt16.Parse(cbrnFirstUI.atkEndMin.text);
                cbrnFirstInfo.attackedPosition = cbrnFirstUI.attackedPos.text;
                cbrnFirstInfo.situation = (Situation)cbrnFirstUI.posSituationDD.value;
                cbrnFirstInfo.classifications = (Classifications)cbrnFirstUI.classificationsDD.value;
                cbrnFirstInfo.property = (Property)cbrnFirstUI.propertyDD.value;
                cbrnFirstInfo.kinds = (Kinds)cbrnFirstUI.kindsDD.value;
                cbrnFirstInfo.explosionShape = (ExplosionShape)cbrnFirstUI.explosionShapeDD.value;
                cbrnFirstInfo.fireMethod = (FireMethod)cbrnFirstUI.fireMethodDD.value;
                cbrnFirstInfo.NumberOfAmmunition = int.Parse(cbrnFirstUI.ammo.text);
                cbrnFirstInfo.NumberOfAircraft = int.Parse(cbrnFirstUI.aircraft.text);
                cbrnFirstInfo.note = cbrnFirstUI.note.text;
                cbrnFirstInfo.messageType = MessageType.CBRN_FIRST;
                cbrnFirstInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();               
                cbrnFirstInfo.index = messageIndex;
                cbrnFirstInfo.messageCategoryTxt = "ȭ��������";
                cbrnFirstInfo.messageTitle = cbrnFirstInfo.note;
                msgList.Add(cbrnFirstInfo);
                SaveMsgData = cbrnFirstInfo;
                buttonManager.prevButtonState = BottomButtonState.CBRN_FIRST_SAVE;
                break;
            case BottomButtonState.CBRN_SCOUT:
                CBRN_ScoutData cbrnScoutInfo = new CBRN_ScoutData();   //������ ��ü ����
                var cbrnScoutUI = uiManager.centerPanel.cbrnScoutPanel; //ui���� �߰�
                cbrnScoutInfo.startDay = UInt16.Parse(cbrnScoutUI.startDay.text);
                cbrnScoutInfo.startHour = UInt16.Parse(cbrnScoutUI.startHour.text);
                cbrnScoutInfo.startMin = UInt16.Parse(cbrnScoutUI.startMin.text); //�ð�
                cbrnScoutInfo.classifications = (Classifications)cbrnScoutUI.classificationsDD.value;
                cbrnScoutInfo.property = (Property)cbrnScoutUI.propertyDD.value;
                cbrnScoutInfo.kinds = (Kinds)cbrnScoutUI.kindsDD.value;
                cbrnScoutInfo.explosionShape = (ExplosionShape)cbrnScoutUI.explosionShapeDD.value;
                cbrnScoutInfo.radiationRate = float.Parse(cbrnScoutUI.radiationRate.text);  //�ۿ��� ����
                cbrnScoutUI.SpecimenArray = cbrnScoutUI.SpecimenList.ToArray();
                //�ۿ��� ���
                for (int i = 0; i < cbrnScoutUI.SpecimenArray.Length; i++)
                {
                    cbrnScoutInfo.scoutItems[i] = new CBRNScoutItemData();
                    cbrnScoutInfo.scoutItems[i].myPos = cbrnScoutUI.SpecimenArray[i].myPos;
                    cbrnScoutInfo.scoutItems[i].classifications = cbrnScoutUI.SpecimenArray[i].classifications;
                    cbrnScoutInfo.scoutItems[i].property = cbrnScoutUI.SpecimenArray[i].property;
                    cbrnScoutInfo.scoutItems[i].kinds = cbrnScoutUI.SpecimenArray[i].kinds;
                    cbrnScoutInfo.scoutItems[i].explosionShape = cbrnScoutUI.SpecimenArray[i].explosionShape;
                    cbrnScoutInfo.scoutItems[i].radiationRate = cbrnScoutUI.SpecimenArray[i].radiationRate;
                    cbrnScoutInfo.scoutItems[i].note = cbrnScoutUI.SpecimenArray[i].note;
                }
                cbrnScoutInfo.note = cbrnScoutUI.note.text;
                cbrnScoutInfo.messageType = MessageType.CBRN_SCOUT;
                cbrnScoutInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                cbrnScoutInfo.index = messageIndex;
                cbrnScoutInfo.messageCategoryTxt = "ȭ��������";
                cbrnScoutInfo.messageTitle = cbrnScoutInfo.note;
                msgList.Add(cbrnScoutInfo);
                SaveMsgData = cbrnScoutInfo;
                buttonManager.prevButtonState = BottomButtonState.CBRN_SCOUT_SAVE;
                break;
            case BottomButtonState.MY_STATE:
                MyStateData myStateInfo = new MyStateData();
                var myStateUI = uiManager.centerPanel.myStatePanel; //ui���� �߰�
                myStateInfo.year = UInt16.Parse(myStateUI.year.text);
                myStateInfo.month = UInt16.Parse(myStateUI.month.text);
                myStateInfo.day = UInt16.Parse(myStateUI.day.text);
                myStateInfo.hour = UInt16.Parse(myStateUI.hour.text);
                myStateInfo.minute = UInt16.Parse(myStateUI.minute.text);
                myStateInfo.title = myStateUI.title.text;
                myStateInfo.enemyPosture = (EnemyPosture)myStateUI.EnemyPostureDD.value;
                myStateInfo.myPosition = myStateUI.myPos.text;
                myStateInfo.enemyPostureLevel = (EnemyPostureLevel)myStateUI.EnemyPostureLevelDD.value;
                myStateInfo.lastOrder = (LastOrder)myStateUI.LastOrderDD.value;
                myStateInfo.LeftCoord = myStateUI.leftCoord.text;
                myStateInfo.RightCoord = myStateUI.rightCoord.text;
                myStateInfo.combat = byte.Parse(myStateUI.combat_p.text);
                myStateInfo.death = byte.Parse(myStateUI.death_p.text);
                myStateInfo.injury = byte.Parse(myStateUI.injury_p.text);
                myStateInfo.ammo_h = byte.Parse(myStateUI.ammo_h.text);
                myStateInfo.ammo_a = byte.Parse(myStateUI.ammo_a.text);
                myStateInfo.ammo_c = byte.Parse(myStateUI.ammo_c.text);
                myStateInfo.ammo_s = byte.Parse(myStateUI.ammo_s.text);
                myStateInfo.ammo_m = byte.Parse(myStateUI.ammo_m.text);
                myStateInfo.note = myStateUI.note.text;
                myStateInfo.messageType = MessageType.MY_STATE;
                myStateInfo.messageCategoryTxt = "������Ȳ";
                myStateInfo.messageTitle = myStateInfo.title;
                myStateInfo.index = messageIndex;
                myStateInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                msgList.Add(myStateInfo);
                SaveMsgData = myStateInfo;
                buttonManager.prevButtonState = BottomButtonState.MY_STATE_SAVE;
                break;
            case BottomButtonState.OBSTACLE:
                ObstacleData obstacleInfo = new ObstacleData();
                var obstacleUI = uiManager.centerPanel.obstaclePanel; //ui���� �߰�
                obstacleInfo.year = UInt16.Parse(obstacleUI.year.text);
                obstacleInfo.month = byte.Parse(obstacleUI.month.text);
                obstacleInfo.day = byte.Parse(obstacleUI.day.text);
                obstacleInfo.hour = byte.Parse(obstacleUI.hour.text);
                obstacleInfo.minute = byte.Parse(obstacleUI.min.text);
                obstacleInfo.obtaclePosition = obstacleUI.obstaclePos.text;
                obstacleInfo.classifyEnemies = (ClassifyEnemies)obstacleUI.classifyEnemyDD.value;
                obstacleInfo.numberOfObstacle = obstacleUI.numberOfObstacles.text;
                obstacleInfo.controlNumber = obstacleUI.controlNum.text;
                obstacleInfo.installUnit = obstacleUI.installUnit.text;
                obstacleInfo.obstacleShape = (ObstacleShape)obstacleUI.shapeDD.value;
                switch (obstacleInfo.obstacleShape)
                {
                    case ObstacleShape.WIRE: obstacleInfo.obstacleBarbedWireType = (ObstacleBarbedWireType)obstacleUI.typeDD.value; break;
                    case ObstacleShape.MINE: obstacleInfo.obstacleMineType = (ObstacleMineType)obstacleUI.typeDD.value; break;
                    case ObstacleShape.WALL: obstacleInfo.obstacleWallType = (ObstacleWallType)obstacleUI.typeDD.value; break;
                    case ObstacleShape.OBSTACLE_CATEGORY: obstacleInfo.obstacleCategory = (ObstacleCategory)obstacleUI.typeDD.value; break;
                }
                obstacleInfo.width = float.Parse(obstacleUI.width.text);
                obstacleInfo.length = float.Parse(obstacleUI.length.text);
                obstacleInfo.note = obstacleUI.note.text;
                obstacleInfo.messageType = MessageType.OBSTACLE;
                obstacleInfo.messageCategoryTxt = "��ֹ�";
                obstacleInfo.messageTitle = obstacleInfo.note;
                obstacleInfo.index = messageIndex;
                obstacleInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                msgList.Add(obstacleInfo);
                SaveMsgData = obstacleInfo;
                buttonManager.prevButtonState = BottomButtonState.OBSTACLE_SAVE;
                break;
            case BottomButtonState.TARGET_DAMAGE:
                TargetDamageData targetDamageInfo = new TargetDamageData();   //��Ŷ ��ü ����
                var targetDamageUI = uiManager.centerPanel.targetDamagePanel; //ui���� �߰�
                targetDamageInfo.targetType = (TargetType)targetDamageUI.targetDD.value;
                targetDamageInfo.targetScale = targetDamageUI.scale.text;
                targetDamageInfo.targetPos = targetDamageUI.position.text;
                targetDamageInfo.measnsOfAttack = (MeasnsOfAttack)targetDamageUI.meansDD.value;
                targetDamageInfo.note = targetDamageUI.result.text;
                targetDamageInfo.messageType = MessageType.TARGET_DAMAGE;
                targetDamageInfo.messageCategoryTxt = "ǥ������";
                targetDamageInfo.messageTitle = targetDamageInfo.note;
                targetDamageInfo.index = messageIndex;
                targetDamageInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                msgList.Add(targetDamageInfo);
                SaveMsgData = targetDamageInfo;
                break;
            case BottomButtonState.NO_FORMAT:
                NoFormatData noFormatInfo = new NoFormatData();   //��Ŷ ��ü ����
                var noFormatUI = uiManager.centerPanel.noformPanel; //ui���� �߰�
                noFormatInfo.year = UInt16.Parse(noFormatUI.year.text);
                noFormatInfo.month = byte.Parse(noFormatUI.month.text);
                noFormatInfo.day = byte.Parse(noFormatUI.day.text);
                noFormatInfo.hour = byte.Parse(noFormatUI.hour.text);
                noFormatInfo.minute = byte.Parse(noFormatUI.min.text);
                noFormatInfo.title = noFormatUI.title.text;
                noFormatInfo.messageType = MessageType.NO_FORMAT;

                for (int i = 0; i < noFormatUI.elements.Length; i++)
                {
                    noFormatInfo.lines[i] = noFormatUI.elements[i].text;
                }
                noFormatInfo.messageCategoryTxt = "����";
                noFormatInfo.messageTitle = noFormatInfo.title;
                noFormatInfo.index = messageIndex;
                noFormatInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                msgList.Add(noFormatInfo);
                SaveMsgData = noFormatInfo;
                buttonManager.prevButtonState = BottomButtonState.NO_FORMAT_SAVE;
                break;
            case BottomButtonState.FIRE_SUPPORT:
                FireSupportData fireSupportInfo = new FireSupportData();   //��Ŷ ��ü ����
                var fireSupportUI = uiManager.centerPanel.fireSupportPanel; //ui���� �߰�
                fireSupportInfo.missionType = (MissionType)fireSupportUI.missionTypeDD.value;
                fireSupportInfo.squadSize = (SupportSquadSize)fireSupportUI.SquadSizeDD.value;
                fireSupportInfo.targetPos = fireSupportUI.targetPos.text;
                fireSupportInfo.plannedTarget = fireSupportUI.plannedTarget.text;
                fireSupportInfo.targetType = (TargetType)fireSupportUI.targetTypeDD.value;
                fireSupportInfo.targetActiveState = (PostureType)fireSupportUI.targetStateDD.value;
                fireSupportInfo.numberOfScale = int.Parse(fireSupportUI.ScaleSize.text);
                fireSupportInfo.targetScale = (UnitScale)fireSupportUI.TargetScaleDD.value;
                fireSupportInfo.mixedTargetType = (TargetType)fireSupportUI.mixedTargetFormDD.value;
                fireSupportInfo.shape = (TargetShape)fireSupportUI.ShapeDD.value;
                fireSupportInfo.size1 = UInt16.Parse(fireSupportUI.size1.text);
                fireSupportInfo.size2 = UInt16.Parse(fireSupportUI.size2.text);
                fireSupportInfo.rad = float.Parse(fireSupportUI.rad.text);
                fireSupportInfo.note = fireSupportUI.note.text;
                fireSupportInfo.atkMethod = fireSupportUI.atkMethod.text;
                fireSupportInfo.ctrlMethod = fireSupportUI.ctrlMethod.text;
                fireSupportInfo.messageType = MessageType.FIRE_SUPPORT;            
                fireSupportInfo.messageCategoryTxt = "ȭ������";
                fireSupportInfo.messageTitle = fireSupportInfo.note;
                fireSupportInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString(); 
                fireSupportInfo.index = messageIndex;
                msgList.Add(fireSupportInfo);
                SaveMsgData = fireSupportInfo;
                buttonManager.prevButtonState = BottomButtonState.FIRE_SUPPORT_SAVE;
                break;
            #endregion
            case BottomButtonState.COMMAND:
                CommandData commandInfo = new CommandData();   //��Ŷ ��ü ����
                var commandUI = uiManager.centerPanel.commandPanel;
                commandInfo.title = commandUI.title.text;
                for (int i = 0; i < commandUI.textList.Count; i++)
                {
                    commandInfo.lines[i] = commandUI.textList[i].text;
                }
                //commandPacket.releavantOverlay ���� �������� ������ �� �ִ� â�� �ʿ���
                commandInfo.job_Position = (Job_Position)commandUI.Job_PositionDD.value;
                commandInfo.rank = (Rank)commandUI.RankDD.value;
                commandInfo.userName = commandUI.userName.text;
                commandInfo.messageType = MessageType.COMMAND;
                commandInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                commandInfo.messageCategoryTxt = "����";
                commandInfo.messageTitle = commandInfo.title;
                commandInfo.index = messageIndex;
                msgList.Add(commandInfo);
                SaveMsgData = commandInfo;
                buttonManager.prevButtonState = BottomButtonState.COMMAND_SAVE;
                if (networkManager.checkData != null)
                {
                    commandInfo.marginalNoteInfo = networkManager.checkData;
                }             
                //������ ���� ��ü
                //CreateRelavantOverlayItem(commandInfo);
                break;
            case BottomButtonState.TARGET_ASSIGNMENT:
                TargetAssignmentData targetAssignmentInfo = new TargetAssignmentData();
                var targetAssignmentUI = uiManager.nonMsgPanel.targetAssignmentPanel;
                targetAssignmentInfo.targetPosition = targetAssignmentUI.targetPosition.text;
                SaveMsgData = targetAssignmentInfo;
                break;
            case BottomButtonState.OVERLAY_MARGINAL_NOTE:
                MarginalNoteData marginalNoteInfo = new MarginalNoteData();   //��Ŷ ��ü ����
                var marginalNoteUI = uiManager.centerPanel.marginalNotePanel;
                MsgData msgData = uiManager.nonMsgPanel.overlayRelatedMsgPanel.currentSelectedData;//���� ���õ� �������� ��ü�� �޼��� ������
                marginalNoteInfo.secretLevel = marginalNoteUI.SecretLvl; // ��۰��� ��� �� ���� �Ʒ� �����ͺ���
                marginalNoteInfo.missionName = marginalNoteUI.operationName.text;
                marginalNoteInfo.missionTarget = marginalNoteUI.operationObject.text;
                marginalNoteInfo.jobPosition = marginalNoteUI.jobPosition.text;
                marginalNoteInfo.platoonText = marginalNoteUI.platoon.text;
                marginalNoteInfo.companyText = marginalNoteUI.company.text;
                marginalNoteInfo.battalionText = marginalNoteUI.battalion.text;
                marginalNoteInfo.date = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + " " + DateTime.Now.Hour.ToString() + " : " + DateTime.Now.Minute.ToString();
                marginalNoteInfo.note = marginalNoteUI.note.text;
                marginalNoteInfo.relevantReport = marginalNoteUI.relevantReport.text;
                for (int i = 0; i < uiManager.rightPanel.overlayIcon.iconItemDataList.Count; i++)
                {
                    marginalNoteInfo.overlayIconArr[i] = uiManager.rightPanel.overlayIcon.iconItemDataList[i];
                }//40���� ������ ������ ��Ŷ�����Ϳ� ����
                marginalNoteInfo.messageType = MessageType.OVERLAY;
                marginalNoteInfo.messageTitle = marginalNoteUI.operationName.text;
                //marginalNoteInfo.relatedMsgName = marginalNoteInfo.commandData.messageTitle;
                marginalNoteInfo.userName = marginalNoteUI.userName.text;             
                marginalNoteInfo.index = messageIndex;//���� �ε����� �ָ� �ȵɰ� ������, ������ �ٸ��� �� �ε����� �ο�����,
                msgData.isLink = true;//���õ� ��ü�� ��������� ������ 
                buttonManager.prevButtonState = BottomButtonState.OVERLAY_MARGINAL_NOTE_SAVE;
                msgList.Add(marginalNoteInfo);
                uiManager.nonMsgPanel.overlayManagementPanel.marginalNoteDataList.Add(marginalNoteInfo);//������ ���� �гο� ���� �߰� 
                SaveMsgData = marginalNoteInfo;//�޼��� ������ �ӽ� ����
                break;
        }
        msgCount++;
        SaveMsgData.messageState = MessageState.IDLE;
        messageIndex++;
        uiManager.CloseButton();
        //������ �ѹ� ���Ͽ� �����Ѵ�
        SaveFile();
        return SaveMsgData;
    }

    //����� ������ �����Ҷ�
    public void SaveMsgEdit()
    {
        switch (buttonManager.prevButtonState)
        {
            #region ��������
            case BottomButtonState.FIND_ENEMY:
                FindEnemyData findEnemyInfo = new FindEnemyData();
                var findEnemyUI = uiManager.centerPanel.findEnemyPanel; //ui���� �߰�
                findEnemyInfo.day = UInt16.Parse(findEnemyUI.day.text);
                findEnemyInfo.hour = UInt16.Parse(findEnemyUI.hour.text);
                findEnemyInfo.min = UInt16.Parse(findEnemyUI.min.text);
                findEnemyInfo.myPosition = findEnemyUI.myPos.text;
                findEnemyInfo.targetPosition = findEnemyUI.targetPos.text;
                findEnemyInfo.targetType1 = (TargetType)findEnemyUI.target1DD.value;
                findEnemyInfo.target1Count = UInt16.Parse(findEnemyUI.target1Count.text);
                findEnemyInfo.targetType2 = (TargetType)findEnemyUI.target2DD.value;
                findEnemyInfo.target2Count = UInt16.Parse(findEnemyUI.target2Count.text);
                findEnemyInfo.targetType3 = (TargetType)findEnemyUI.target3DD.value;
                findEnemyInfo.target3Count = UInt16.Parse(findEnemyUI.target3Count.text);
                findEnemyInfo.targetPosture = (TargetPosture)findEnemyUI.postrueDD.value;
                findEnemyInfo.targetDirection = (TargetDirection)findEnemyUI.directionDD.value;
                findEnemyInfo.note = findEnemyUI.note.text;
                findEnemyInfo.messageType = MessageType.FIND_ENEMY;
                findEnemyInfo.messageCategoryTxt = "���߰�";
                findEnemyInfo.messageTitle = findEnemyInfo.note;
                SaveMsgData = findEnemyInfo;
                buttonManager.prevButtonState = BottomButtonState.FIND_ENEMY_SAVE;//����
                break;
            case BottomButtonState.TRANSFER:
                TransferData transferInfo = new TransferData();
                var transferUI = uiManager.centerPanel.transferPanel;
                transferInfo.rescuePosition = transferUI.position.text;
                transferInfo.patient = UInt16.Parse(transferUI.patient.text);
                transferInfo.stretcher = UInt16.Parse(transferUI.stretcher.text);
                transferInfo.transferPriority = (TransferPriority)transferUI.priorityDD.value;
                transferInfo.mark = (AreaMark)transferUI.markDD.value;
                transferInfo.pollution = (Pollution)transferUI.pollutionDD.value;
                transferInfo.markColor = (MarkColor)transferUI.colorDD.value;
                transferInfo.areaSafetyLevel = (AreaSafetyLevel)transferUI.safetyDD.value;
                transferInfo.national = (National)transferUI.nationalDD.value;
                transferInfo.note = transferUI.note.text;
                transferInfo.messageType = MessageType.TRANSFER;
                transferInfo.messageCategoryTxt = "�ļ�";
                transferInfo.messageTitle = transferInfo.note;
                SaveMsgData = transferInfo;
                buttonManager.prevButtonState = BottomButtonState.TRANSFER_SAVE;
                break;
            case BottomButtonState.CBRN_FIRST:
                CBRN_FirstData cbrnFirstInfo = new CBRN_FirstData();   //��Ŷ ��ü ����
                var cbrnFirstUI = uiManager.centerPanel.cbrnFirstPanel; //ui���� �߰�
                cbrnFirstInfo.cbrnType = (CBRNType)cbrnFirstUI.CBRNTypeDD.value;
                cbrnFirstInfo.myPosition = cbrnFirstUI.myPosition.text;
                cbrnFirstInfo.myRotation_do = int.Parse(cbrnFirstUI.Pos_do.text);
                cbrnFirstInfo.myRotation_mil = int.Parse(cbrnFirstUI.Pos_Mil.text);
                cbrnFirstInfo.atkStartD = UInt16.Parse(cbrnFirstUI.atkStartDay.text);
                cbrnFirstInfo.atkStartH = UInt16.Parse(cbrnFirstUI.atkStartHour.text);
                cbrnFirstInfo.atkStartM = UInt16.Parse(cbrnFirstUI.atkStartMin.text);
                cbrnFirstInfo.atkEndD = UInt16.Parse(cbrnFirstUI.atkEndDay.text);
                cbrnFirstInfo.atkEndH = UInt16.Parse(cbrnFirstUI.atkEndHour.text);
                cbrnFirstInfo.atkEndM = UInt16.Parse(cbrnFirstUI.atkEndMin.text);
                cbrnFirstInfo.attackedPosition = cbrnFirstUI.attackedPos.text;
                cbrnFirstInfo.situation = (Situation)cbrnFirstUI.posSituationDD.value;
                cbrnFirstInfo.classifications = (Classifications)cbrnFirstUI.classificationsDD.value;
                cbrnFirstInfo.property = (Property)cbrnFirstUI.propertyDD.value;
                cbrnFirstInfo.kinds = (Kinds)cbrnFirstUI.kindsDD.value;
                cbrnFirstInfo.explosionShape = (ExplosionShape)cbrnFirstUI.explosionShapeDD.value;
                cbrnFirstInfo.fireMethod = (FireMethod)cbrnFirstUI.fireMethodDD.value;
                cbrnFirstInfo.NumberOfAmmunition = int.Parse(cbrnFirstUI.ammo.text);
                cbrnFirstInfo.NumberOfAircraft = int.Parse(cbrnFirstUI.aircraft.text);
                cbrnFirstInfo.note = cbrnFirstUI.note.text;
                cbrnFirstInfo.messageType = MessageType.CBRN_FIRST;
                cbrnFirstInfo.messageCategoryTxt = "ȭ��������";
                cbrnFirstInfo.messageTitle = cbrnFirstInfo.note;
                SaveMsgData = cbrnFirstInfo;
                buttonManager.prevButtonState = BottomButtonState.CBRN_FIRST_SAVE;
                break;
            case BottomButtonState.CBRN_SCOUT:
                CBRN_ScoutData cbrnScoutInfo = new CBRN_ScoutData();   //������ ��ü ����
                var cbrnScoutUI = uiManager.centerPanel.cbrnScoutPanel; //ui���� �߰�
                cbrnScoutInfo.startDay = UInt16.Parse(cbrnScoutUI.startDay.text);
                cbrnScoutInfo.startHour = UInt16.Parse(cbrnScoutUI.startHour.text);
                cbrnScoutInfo.startMin = UInt16.Parse(cbrnScoutUI.startMin.text); //�ð�
                cbrnScoutInfo.classifications = (Classifications)cbrnScoutUI.classificationsDD.value;
                cbrnScoutInfo.property = (Property)cbrnScoutUI.propertyDD.value;
                cbrnScoutInfo.kinds = (Kinds)cbrnScoutUI.kindsDD.value;
                cbrnScoutInfo.explosionShape = (ExplosionShape)cbrnScoutUI.explosionShapeDD.value;
                cbrnScoutInfo.radiationRate = float.Parse(cbrnScoutUI.radiationRate.text);  //�ۿ��� ����
                cbrnScoutUI.SpecimenArray = cbrnScoutUI.SpecimenList.ToArray();
                //�ۿ��� ���
                for (int i = 0; i < cbrnScoutUI.SpecimenArray.Length; i++)
                {
                    cbrnScoutInfo.scoutItems[i] = new CBRNScoutItemData();
                    cbrnScoutInfo.scoutItems[i].myPos = cbrnScoutUI.SpecimenArray[i].myPos;
                    cbrnScoutInfo.scoutItems[i].classifications = cbrnScoutUI.SpecimenArray[i].classifications;
                    cbrnScoutInfo.scoutItems[i].property = cbrnScoutUI.SpecimenArray[i].property;
                    cbrnScoutInfo.scoutItems[i].kinds = cbrnScoutUI.SpecimenArray[i].kinds;
                    cbrnScoutInfo.scoutItems[i].explosionShape = cbrnScoutUI.SpecimenArray[i].explosionShape;
                    cbrnScoutInfo.scoutItems[i].radiationRate = cbrnScoutUI.SpecimenArray[i].radiationRate;
                    cbrnScoutInfo.scoutItems[i].note = cbrnScoutUI.SpecimenArray[i].note;
                }
                cbrnScoutInfo.note = cbrnScoutUI.note.text;
                cbrnScoutInfo.messageType = MessageType.CBRN_SCOUT;
                cbrnScoutInfo.messageCategoryTxt = "ȭ��������";
                cbrnScoutInfo.messageTitle = cbrnScoutInfo.note;
                SaveMsgData = cbrnScoutInfo;
                buttonManager.prevButtonState = BottomButtonState.CBRN_SCOUT_SAVE;
                break;
            case BottomButtonState.MY_STATE:
                MyStateData myStateInfo = new MyStateData();
                var myStateUI = uiManager.centerPanel.myStatePanel; //ui���� �߰�
                myStateInfo.year = UInt16.Parse(myStateUI.year.text);
                myStateInfo.month = UInt16.Parse(myStateUI.month.text);
                myStateInfo.day = UInt16.Parse(myStateUI.day.text);
                myStateInfo.hour = UInt16.Parse(myStateUI.hour.text);
                myStateInfo.minute = UInt16.Parse(myStateUI.minute.text);
                myStateInfo.title = myStateUI.title.text;
                myStateInfo.enemyPosture = (EnemyPosture)myStateUI.EnemyPostureDD.value;
                myStateInfo.myPosition = myStateUI.myPos.text;
                myStateInfo.enemyPostureLevel = (EnemyPostureLevel)myStateUI.EnemyPostureLevelDD.value;
                myStateInfo.lastOrder = (LastOrder)myStateUI.LastOrderDD.value;
                myStateInfo.LeftCoord = myStateUI.leftCoord.text;
                myStateInfo.RightCoord = myStateUI.rightCoord.text;
                myStateInfo.combat = byte.Parse(myStateUI.combat_p.text);
                myStateInfo.death = byte.Parse(myStateUI.death_p.text);
                myStateInfo.injury = byte.Parse(myStateUI.injury_p.text);
                myStateInfo.ammo_h = byte.Parse(myStateUI.ammo_h.text);
                myStateInfo.ammo_a = byte.Parse(myStateUI.ammo_a.text);
                myStateInfo.ammo_c = byte.Parse(myStateUI.ammo_c.text);
                myStateInfo.ammo_s = byte.Parse(myStateUI.ammo_s.text);
                myStateInfo.ammo_m = byte.Parse(myStateUI.ammo_m.text);
                myStateInfo.note = myStateUI.note.text;
                myStateInfo.messageType = MessageType.MY_STATE;
                myStateInfo.messageCategoryTxt = "������Ȳ";
                myStateInfo.messageTitle = myStateInfo.title;
                SaveMsgData = myStateInfo;
                buttonManager.prevButtonState = BottomButtonState.MY_STATE_SAVE;
                break;
            case BottomButtonState.OBSTACLE:
                ObstacleData obstacleInfo = new ObstacleData();
                var obstacleUI = uiManager.centerPanel.obstaclePanel; //ui���� �߰�
                obstacleInfo.year = UInt16.Parse(obstacleUI.year.text);
                obstacleInfo.month = byte.Parse(obstacleUI.month.text);
                obstacleInfo.day = byte.Parse(obstacleUI.day.text);
                obstacleInfo.hour = byte.Parse(obstacleUI.hour.text);
                obstacleInfo.minute = byte.Parse(obstacleUI.min.text);
                obstacleInfo.obtaclePosition = obstacleUI.obstaclePos.text;
                obstacleInfo.classifyEnemies = (ClassifyEnemies)obstacleUI.classifyEnemyDD.value;
                obstacleInfo.numberOfObstacle = obstacleUI.numberOfObstacles.text;
                obstacleInfo.controlNumber = obstacleUI.controlNum.text;
                obstacleInfo.installUnit = obstacleUI.installUnit.text;
                obstacleInfo.obstacleShape = (ObstacleShape)obstacleUI.shapeDD.value;
                switch (obstacleInfo.obstacleShape)
                {
                    case ObstacleShape.WIRE: obstacleInfo.obstacleBarbedWireType = (ObstacleBarbedWireType)obstacleUI.typeDD.value; break;
                    case ObstacleShape.MINE: obstacleInfo.obstacleMineType = (ObstacleMineType)obstacleUI.typeDD.value; break;
                    case ObstacleShape.WALL: obstacleInfo.obstacleWallType = (ObstacleWallType)obstacleUI.typeDD.value; break;
                    case ObstacleShape.OBSTACLE_CATEGORY: obstacleInfo.obstacleCategory = (ObstacleCategory)obstacleUI.typeDD.value; break;
                }
                obstacleInfo.width = float.Parse(obstacleUI.width.text);
                obstacleInfo.length = float.Parse(obstacleUI.length.text);
                obstacleInfo.note = obstacleUI.note.text;
                obstacleInfo.messageType = MessageType.OBSTACLE;
                obstacleInfo.messageCategoryTxt = "��ֹ�";
                obstacleInfo.messageTitle = obstacleInfo.note;
                SaveMsgData = obstacleInfo;
                buttonManager.prevButtonState = BottomButtonState.OBSTACLE_SAVE;
                break;
            case BottomButtonState.TARGET_DAMAGE:
                TargetDamageData targetDamageInfo = new TargetDamageData();   //��Ŷ ��ü ����
                var targetDamageUI = uiManager.centerPanel.targetDamagePanel; //ui���� �߰�
                targetDamageInfo.targetType = (TargetType)targetDamageUI.targetDD.value;
                targetDamageInfo.targetScale = targetDamageUI.scale.text;
                targetDamageInfo.targetPos = targetDamageUI.position.text;
                targetDamageInfo.measnsOfAttack = (MeasnsOfAttack)targetDamageUI.meansDD.value;
                targetDamageInfo.note = targetDamageUI.result.text;
                targetDamageInfo.messageType = MessageType.TARGET_DAMAGE;
                targetDamageInfo.messageCategoryTxt = "ǥ������";
                targetDamageInfo.messageTitle = targetDamageInfo.note;
                SaveMsgData = targetDamageInfo;
                break;
            case BottomButtonState.NO_FORMAT:
                NoFormatData noFormatInfo = new NoFormatData();   //��Ŷ ��ü ����
                var noFormatUI = uiManager.centerPanel.noformPanel; //ui���� �߰�
                noFormatInfo.year = UInt16.Parse(noFormatUI.year.text);
                noFormatInfo.month = byte.Parse(noFormatUI.month.text);
                noFormatInfo.day = byte.Parse(noFormatUI.day.text);
                noFormatInfo.hour = byte.Parse(noFormatUI.hour.text);
                noFormatInfo.minute = byte.Parse(noFormatUI.min.text);
                noFormatInfo.title = noFormatUI.title.text;
                noFormatInfo.messageType = MessageType.NO_FORMAT;

                for (int i = 0; i < noFormatUI.elements.Length; i++)
                {
                    noFormatInfo.lines[i] = noFormatUI.elements[i].text;
                }
                noFormatInfo.messageCategoryTxt = "����";
                noFormatInfo.messageTitle = noFormatInfo.title;
                SaveMsgData = noFormatInfo;
                buttonManager.prevButtonState = BottomButtonState.NO_FORMAT_SAVE;
                break;
            case BottomButtonState.FIRE_SUPPORT:
                FireSupportData fireSupportInfo = new FireSupportData();   //��Ŷ ��ü ����
                var fireSupportUI = uiManager.centerPanel.fireSupportPanel; //ui���� �߰�
                fireSupportInfo.missionType = (MissionType)fireSupportUI.missionTypeDD.value;
                fireSupportInfo.squadSize = (SupportSquadSize)fireSupportUI.SquadSizeDD.value;
                fireSupportInfo.targetPos = fireSupportUI.targetPos.text;
                fireSupportInfo.plannedTarget = fireSupportUI.plannedTarget.text;
                fireSupportInfo.targetType = (TargetType)fireSupportUI.targetTypeDD.value;
                fireSupportInfo.targetActiveState = (PostureType)fireSupportUI.targetStateDD.value;
                fireSupportInfo.numberOfScale = int.Parse(fireSupportUI.ScaleSize.text);
                fireSupportInfo.targetScale = (UnitScale)fireSupportUI.TargetScaleDD.value;
                fireSupportInfo.mixedTargetType = (TargetType)fireSupportUI.mixedTargetFormDD.value;
                fireSupportInfo.shape = (TargetShape)fireSupportUI.ShapeDD.value;
                fireSupportInfo.size1 = UInt16.Parse(fireSupportUI.size1.text);
                fireSupportInfo.size2 = UInt16.Parse(fireSupportUI.size2.text);
                fireSupportInfo.rad = float.Parse(fireSupportUI.rad.text);
                fireSupportInfo.note = fireSupportUI.note.text;
                fireSupportInfo.atkMethod = fireSupportUI.atkMethod.text;
                fireSupportInfo.ctrlMethod = fireSupportUI.ctrlMethod.text;
                fireSupportInfo.messageType = MessageType.FIRE_SUPPORT;
                fireSupportInfo.messageCategoryTxt = "ȭ������";
                fireSupportInfo.messageTitle = fireSupportInfo.note;
                SaveMsgData = fireSupportInfo;
                buttonManager.prevButtonState = BottomButtonState.FIRE_SUPPORT_SAVE;
                break;
            #endregion
            case BottomButtonState.COMMAND:
                CommandData commandInfo = new CommandData();   //��Ŷ ��ü ����
                var commandUI = uiManager.centerPanel.commandPanel;
                commandInfo.title = commandUI.title.text;
                for (int i = 0; i < commandUI.textList.Count; i++)
                {
                    commandInfo.lines[i] = commandUI.textList[i].text;
                }
                //commandPacket.releavantOverlay ���� �������� ��� �������� ������
                commandInfo.job_Position = (Job_Position)commandUI.Job_PositionDD.value;
                commandInfo.rank = (Rank)commandUI.RankDD.value;
                commandInfo.userName = commandUI.userName.text;
                commandInfo.messageType = MessageType.COMMAND;
                commandInfo.messageCategoryTxt = "����";
                commandInfo.messageTitle = commandInfo.title;
                SaveMsgData = commandInfo;
                buttonManager.prevButtonState = BottomButtonState.COMMAND_SAVE;
                break;
            case BottomButtonState.OVERLAY_MARGINAL_NOTE:
                MarginalNoteData marginalNoteInfo = new MarginalNoteData();   //��Ŷ ��ü ����
                var marginalNoteUI = uiManager.centerPanel.marginalNotePanel;
                marginalNoteInfo.secretLevel = marginalNoteUI.SecretLvl; // ��۰��� ��� �� ���� �Ʒ� �����ͺ���
                marginalNoteInfo.missionName = marginalNoteUI.operationName.text;
                marginalNoteInfo.missionTarget = marginalNoteUI.operationObject.text;
                marginalNoteInfo.jobPosition = marginalNoteUI.jobPosition.text;
                marginalNoteInfo.platoonText = marginalNoteUI.platoon.text;
                marginalNoteInfo.companyText = marginalNoteUI.company.text;
                marginalNoteInfo.battalionText = marginalNoteUI.battalion.text;
                marginalNoteInfo.date = marginalNoteUI.date.text;
                marginalNoteInfo.note = marginalNoteUI.note.text;
                marginalNoteInfo.relevantReport = marginalNoteUI.relevantReport.text;
                //marginalNoteInfo.commandData.marginalNoteInfo = marginalNoteInfo;//=> ����� ���ɹ��� ���� 
                buttonManager.prevButtonState = BottomButtonState.OVERLAY_MARGINAL_NOTE_SAVE;
                break;
        }
        uiManager.CloseButton();
        //������ �ѹ� ���Ͽ� �����Ѵ�
        SaveFile();
        for (int i = 0; i < msgList.Count; i++)
        {
            if (buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().index == msgList[i].index)
                msgList[i] = SaveMsgData;
        }  
    }
    //��������Ʈ�� ������ ���Ϸ� ����
    public void SaveFile()
    {       
        FileStream fs = new FileStream(messageDataPath, FileMode.Create);

        BinaryFormatter formatter = new BinaryFormatter();
        try
        {
            formatter.Serialize(fs, msgList);
        }
        catch
        {
            Console.WriteLine("����!!!!");
            throw;
        }
        finally
        {
            fs.Close();
        }
    }

    //��������Ʈ�� ���Ͽ��� �ε�
    public void LoadFile()
    {
        //��������Ʈ�� Ŭ�����ϰ� ���� �޾ƿ��Ƿ� �� �Լ��� ���ʿ� �ѹ��� �����ؾ��Ѵ�
        msgList.Clear();

        if(File.Exists(messageDataPath))
        {
            FileStream fs = new FileStream(messageDataPath, FileMode.Open);
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                msgList = (List<MsgData>)formatter.Deserialize(fs);
            }
            catch
            {
                Console.WriteLine("����!!!!!!!����");
                throw;
            }
            finally
            {
                fs.Close();
            }

            //���Ȯ�ο�
            for (int i = 0; i < msgList.Count; i++)
            {
                Debug.Log($"{msgList[i].messageType} {msgList[i].messageTitle}");
            }
        }
    }

    public void CopyAndSaveMsgButton()
    {
        var currentMessageType = buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().messageType;
        if (buttonManager.currentSelectedMessageObject == null) return;

        for (int i = 0; i < msgList.Count; i++)//�޼��� ����Ʈ����
        {

            if (msgList[i].index == buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().index) // ���� Ŭ���� ������ ��ġ�ϴ� ���ӿ�����Ʈ�� ã��
            {
                if (currentMessageType == MessageType.FIND_ENEMY)
                {
                    FindEnemyData newData = new FindEnemyData();//�� ��ü�� ����
                    FindEnemyData oldData = (FindEnemyData)msgList[i]; //�������¸� �����ϸ� �ȵǹǷ� old�� new�� ������
                    // newData = oldData���ϸ� oldData�� �ε����� ���� �ٲ�¹���������,  newData = oldData; ���Ŀ� newData.index�� ���������൵ oldData�� ���� ���� �ٲ�
                    newData.day = oldData.day;
                    newData.hour = oldData.hour;
                    newData.min = oldData.min;
                    newData.myPosition = oldData.myPosition;
                    newData.targetPosition = oldData.targetPosition;
                    newData.targetType1 = oldData.targetType1;
                    newData.target1Count = oldData.target1Count;
                    newData.targetType2 = oldData.targetType2;
                    newData.target2Count = oldData.target2Count;
                    newData.targetType3 = oldData.targetType3;
                    newData.target3Count = oldData.target3Count;
                    newData.targetPosture = oldData.targetPosture;
                    newData.targetDirection = oldData.targetDirection;
                    newData.note = oldData.note;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = newData.note;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.TRANSFER)
                {
                    TransferData newData = new TransferData();//�� ��ü�� ����
                    TransferData oldData = (TransferData)msgList[i];
                    newData.rescuePosition = oldData.rescuePosition;
                    newData.patient = oldData.patient;
                    newData.stretcher = oldData.stretcher;
                    newData.transferPriority = oldData.transferPriority;
                    newData.mark = oldData.mark;
                    newData.pollution = oldData.pollution;
                    newData.markColor = oldData.markColor;
                    newData.areaSafetyLevel = oldData.areaSafetyLevel;
                    newData.national = oldData.national;
                    newData.note = oldData.note;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.CBRN_FIRST)
                {
                    CBRN_FirstData newData = new CBRN_FirstData();
                    CBRN_FirstData oldData = (CBRN_FirstData)msgList[i];
                    newData.cbrnType = oldData.cbrnType;
                    newData.myPosition = oldData.myPosition;
                    newData.myRotation_do = oldData.myRotation_do;
                    newData.myRotation_mil = oldData.myRotation_mil;
                    newData.atkStartD = oldData.atkStartD;
                    newData.atkStartH = oldData.atkStartH;
                    newData.atkStartM = oldData.atkStartM;
                    newData.atkEndD = oldData.atkEndD;
                    newData.atkEndH = oldData.atkEndH;
                    newData.atkEndM = oldData.atkEndM;
                    newData.attackedPosition = oldData.attackedPosition;
                    newData.situation = oldData.situation;
                    newData.classifications = oldData.classifications;
                    newData.property = oldData.property;
                    newData.kinds = oldData.kinds;
                    newData.explosionShape = oldData.explosionShape;
                    newData.fireMethod = oldData.fireMethod;
                    newData.NumberOfAmmunition = oldData.NumberOfAmmunition;
                    newData.NumberOfAircraft = oldData.NumberOfAircraft;
                    newData.note = oldData.note;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.CBRN_SCOUT)
                {
                    CBRN_ScoutData newData = new CBRN_ScoutData();
                    CBRN_ScoutData oldData = (CBRN_ScoutData)msgList[i];
                    newData.startDay = oldData.startDay;
                    newData.startHour = oldData.startHour;
                    newData.startMin = oldData.startMin;
                    newData.classifications = oldData.classifications;
                    newData.property = oldData.property;
                    newData.kinds = oldData.kinds;
                    newData.explosionShape = oldData.explosionShape;
                    newData.radiationRate = oldData.radiationRate;
                    //����Ʈ �ѱ�
                    for (int j = 0; j < oldData.scoutItems.Length; j++)
                    {
                        newData.scoutItems[j] = oldData.scoutItems[j];
                    }
                    newData.note = oldData.note;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;
                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.MY_STATE)
                {
                    MyStateData newData = new MyStateData();
                    MyStateData oldData = (MyStateData)msgList[i];
                    newData.year = oldData.year;
                    newData.month = oldData.month;
                    newData.day = oldData.day;
                    newData.hour = oldData.hour;
                    newData.minute = oldData.minute;
                    newData.title = oldData.title;
                    newData.enemyPosture = oldData.enemyPosture;
                    newData.myPosition = oldData.myPosition;
                    newData.enemyPostureLevel = oldData.enemyPostureLevel;
                    newData.lastOrder = oldData.lastOrder;
                    newData.LeftCoord = oldData.LeftCoord;
                    newData.RightCoord = oldData.RightCoord;
                    newData.combat = oldData.combat;
                    newData.injury = oldData.injury;
                    newData.ammo_h = oldData.ammo_h;
                    newData.ammo_a = oldData.ammo_a;
                    newData.ammo_c = oldData.ammo_c;
                    newData.ammo_s = oldData.ammo_s;
                    newData.ammo_m = oldData.ammo_m;
                    newData.note = oldData.note;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.OBSTACLE)
                {
                    ObstacleData newData = new ObstacleData();
                    ObstacleData oldData = (ObstacleData)msgList[i]; //ui���� �߰�
                    newData.year = oldData.year;
                    newData.month = oldData.month;
                    newData.day = oldData.day;
                    newData.hour = oldData.hour;
                    newData.minute = oldData.minute;
                    newData.obtaclePosition = oldData.obtaclePosition;
                    newData.classifyEnemies = oldData.classifyEnemies;
                    newData.obstacleShape = oldData.obstacleShape;
                    newData.numberOfObstacle = oldData.numberOfObstacle;
                    newData.controlNumber = oldData.controlNumber;
                    newData.installUnit = oldData.installUnit;
                    newData.obstacleShape = oldData.obstacleShape;
                    switch (newData.obstacleShape)
                    {
                        case ObstacleShape.WIRE:
                            newData.obstacleBarbedWireType = oldData.obstacleBarbedWireType;
                            break;
                        case ObstacleShape.MINE:
                            newData.obstacleMineType = oldData.obstacleMineType;
                            break;
                        case ObstacleShape.WALL:
                            newData.obstacleWallType = oldData.obstacleWallType;
                            break;
                        case ObstacleShape.OBSTACLE_CATEGORY:
                            newData.obstacleCategory = oldData.obstacleCategory;
                            break;
                    }
                    newData.width = oldData.width;
                    newData.length = oldData.length;
                    newData.note = oldData.note;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.TARGET_DAMAGE)
                {
                    TargetDamageData newData = new TargetDamageData();   //��Ŷ ��ü ����
                    TargetDamageData oldData = (TargetDamageData)msgList[i]; //ui���� �߰�
                    newData.targetType = oldData.targetType;
                    newData.targetScale = oldData.targetScale;
                    newData.targetPos = oldData.targetPos;
                    newData.measnsOfAttack = oldData.measnsOfAttack;
                    newData.note = oldData.note;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.NO_FORMAT)
                {
                    NoFormatData newData = new NoFormatData();
                    NoFormatData oldData = (NoFormatData)msgList[i];
                    newData.year = oldData.year;
                    newData.month = oldData.month;
                    newData.day = oldData.day;
                    newData.hour = oldData.hour;
                    newData.minute = oldData.minute;
                    newData.title = oldData.title;
                    newData.messageType = oldData.messageType;

                    for (int j = 0; j < oldData.lines.Length; j++)
                    {
                        newData.lines[j] = oldData.lines[j];
                    }
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.FIRE_SUPPORT)
                {
                    FireSupportData newData = new FireSupportData();   //��Ŷ ��ü ����
                    FireSupportData oldData = (FireSupportData)msgList[i]; //ui���� �߰�
                    newData.missionType = oldData.missionType;
                    newData.squadSize = oldData.squadSize;
                    newData.targetPos = oldData.targetPos;
                    newData.plannedTarget = oldData.plannedTarget;
                    newData.targetType = oldData.targetType;
                    newData.targetActiveState = oldData.targetActiveState;
                    newData.numberOfScale = oldData.numberOfScale;
                    newData.targetScale = oldData.targetScale;
                    newData.mixedTargetType = oldData.mixedTargetType;
                    newData.shape = oldData.shape;
                    newData.size1 = oldData.size1;
                    newData.size2 = oldData.size2;
                    newData.rad = oldData.rad;
                    newData.note = oldData.note;
                    newData.atkMethod = oldData.atkMethod;
                    newData.ctrlMethod = oldData.ctrlMethod;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                else if (currentMessageType == MessageType.COMMAND)
                {
                    CommandData newData = new CommandData();   //��Ŷ ��ü ����
                    CommandData oldData = (CommandData)msgList[i];
                    newData.title = oldData.title;
                    for (int j = 0; j < oldData.lines.Length; j++)
                    {
                        newData.lines[j] = oldData.lines[j];
                    }
                    //commandPacket.releavantOverlay ���� �������� ��� �������� ������
                    newData.job_Position = oldData.job_Position;
                    newData.rank = oldData.rank;
                    newData.userName = oldData.userName;
                    newData.messageType = oldData.messageType;
                    newData.messageCategoryTxt = oldData.messageCategoryTxt;
                    newData.messageTitle = oldData.messageTitle;

                    newData.index = messageIndex++;
                    SaveMsgData = newData;
                }
                msgCount++;
                SaveMsgData.messageState = MessageState.IDLE;
                msgList.Add(SaveMsgData);
                break;//�ڰ������� �ϸ鼭 ���ѷ����� �����°��� ����

            }   
        }
    }


    //���� ����
    public void EditMsgButton()
    {
        if (buttonManager.currentSelectedMessageObject == null) return; //���õ� ��ü�� ������ ���� 
        else
        {
            for (int i = 0; i < msgList.Count; i++)
            {
                if (msgList[i].index == buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().index)
                {
                    SaveMsgData = msgList[i];
                }
            }            
            buttonManager.SelectedItemOpen();//uiâ�� ���� ���� ����
            GameObject tempPanel = null;
            //�ش� ui ������ ������ ������� 
            MessageType messageType = buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().messageType;
            switch(messageType)
            {
                case MessageType.FIND_ENEMY: tempPanel = uiManager.centerPanel.findEnemyPanel.gameObject;  buttonManager.prevButtonState = BottomButtonState.FIND_ENEMY;    break;
                case MessageType.TRANSFER: tempPanel = uiManager.centerPanel.transferPanel.gameObject; buttonManager.prevButtonState = BottomButtonState.TRANSFER; break;
                case MessageType.CBRN_FIRST: tempPanel = uiManager.centerPanel.cbrnFirstPanel.gameObject; buttonManager.prevButtonState = BottomButtonState.CBRN_FIRST; break;
                case MessageType.CBRN_SCOUT: tempPanel = uiManager.centerPanel.cbrnScoutPanel.gameObject; buttonManager.prevButtonState = BottomButtonState.CBRN_SCOUT; break;
                case MessageType.MY_STATE: tempPanel = uiManager.centerPanel.myStatePanel.gameObject; buttonManager.prevButtonState = BottomButtonState.MY_STATE; break;
                case MessageType.OBSTACLE: tempPanel = uiManager.centerPanel.obstaclePanel.gameObject; buttonManager.prevButtonState = BottomButtonState.OBSTACLE; break;
                case MessageType.TARGET_DAMAGE: tempPanel = uiManager.centerPanel.targetDamagePanel.gameObject; buttonManager.prevButtonState = BottomButtonState.TARGET_DAMAGE; break;
                case MessageType.NO_FORMAT: tempPanel = uiManager.centerPanel.noformPanel.gameObject; buttonManager.prevButtonState = BottomButtonState.NO_FORMAT; break;
                case MessageType.FIRE_SUPPORT: tempPanel = uiManager.centerPanel.fireSupportPanel.gameObject; buttonManager.prevButtonState = BottomButtonState.FIRE_SUPPORT; break;
                case MessageType.COMMAND: tempPanel = uiManager.centerPanel.commandPanel.gameObject; buttonManager.prevButtonState = BottomButtonState.COMMAND; break;
                case MessageType.OVERLAY: tempPanel = uiManager.centerPanel.marginalNotePanel.gameObject; buttonManager.prevButtonState = BottomButtonState.OVERLAY; break;
            }
            UIManager.InteractableUI(tempPanel);

            buttonManager.currentButtonState = BottomButtonState.WHEN_CLICKED_EDIT_MESSAGE;
          
            buttonManager.ChangeButton();
        }
    }

    public List<WayPointData> wayPointDatas = new List<WayPointData>();
    //ui�����͸� �޼��� �����ͷ� 
    public void SaveWayPoint()
    {
        wayPointDatas.Clear();
        WayPointData data = new WayPointData();//�޼��� ������;
        WayPointManager info = FindObjectOfType<WayPointManager>();//����� ui ������

        for (int i = 0; i < info.saveWayPointList.Count; i++)//save����Ʈ�� ������ data�� ����
        {   //������ �Է�
            data = new WayPointData();
            data.index = info.saveWayPointList[i].index; //objInfo -> data 
            data.myPosition = info.saveWayPointList[i].lonLatText;
            data.pointType = info.saveWayPointList[i].wayPointType;
            data.startMonth = info.saveWayPointList[i].startMonth;
            data.startDay = info.saveWayPointList[i].startDay;
            data.startHour = info.saveWayPointList[i].startHour;
            data.startMinute = info.saveWayPointList[i].startMinute;
            data.endMonth = info.saveWayPointList[i].endMonth;
            data.endDay = info.saveWayPointList[i].endDay;
            data.endHour = info.saveWayPointList[i].endHour;
            data.endMinute = info.saveWayPointList[i].endMinute;
            data.speed = info.saveWayPointList[i].speed;
            wayPointDatas.Add(data);
        }
        //�޼��� ����Ʈ�� �߰�������, �̵��δ� �޼��������ͷ�������� �����Ƿ� ���� 
        //�̵��� ������ ���Ž� ������ ������ ����� �� ������ �Է¹޴� ������ �� �� ���� �ε����� �ʿ����� ���������� �����
    }


    #region ���� ����
    public void DeleteSelectedMessage()
    {
        if (buttonManager.currentSelectedMessageObject == null)
        {
            return;
        }

        //�˶�â���� �޼����� �����Ҷ� 
        if (buttonManager.currentButtonState == BottomButtonState._1ST_PRIORITY_ALARM_DELETE || buttonManager.currentButtonState == BottomButtonState._2ND_PRIORITY_ALARM_DELETE ||
            buttonManager.currentButtonState == BottomButtonState._3RD_PRIORITY_ALARM_DELETE || buttonManager.currentButtonState == BottomButtonState._4TH_PRIORITY_ALARM_DELETE)
        {
            uiManager.nonMsgPanel.alarmPanel.gameObject.SetActive(false);
        }
        var symbol = uiManager.nonMsgPanel.targetAssignmentPanel; //���õ� ���� ��ü t�� ��Ŷ ������ �����ؾ��� 
        for (int i = msgList.Count - 1; i >= 0; i--)//�޼��� ����Ʈ Ž��
        {
            if (msgList[i] == null)//����Ʈ���� null�� ����
                msgList.Remove(msgList[i]);
            if (msgList[i].index == buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().index) //���� ������ �޼��� ��ü
            {
                if (msgList[i].messageType == MessageType.COMMAND)//���ɹ� �����Ҷ� ����ó��. ���������������� �Բ� �������ϰ�, ���������� ���ԵǾ��ִ� ������ �����ܵ� �����������
                {
                    msgList.Remove(msgList[i+50000]); //�����ֱ� ����
                    //������ â���� ���������� ���� �ε����� ���� ������ ��ü���� �����.
                }
                for (int j = symbol.msgSymbolList.Count - 1; j >= 0; j--)
                {
                    if (symbol.msgSymbolList[j] == null)//������ ����Ʈ���� null�� ����
                        symbol.msgSymbolList.Remove(symbol.msgSymbolList[j]);
                    if (msgList[i].index == symbol.msgSymbolList[j].GetComponent<IconInfo>().index) //�������� �ε����� msg�������� �ε����� ��ġ�ϸ�
                        Destroy(symbol.msgSymbolList[j].gameObject); //������ ���� 

                }
                Destroy(buttonManager.currentSelectedMessageObject.gameObject);
                msgList.Remove(msgList[i]);
            }
            for (int k = 0; k < uiManager.nonMsgPanel.overlayRelatedMsgPanel.relatedMsgList.Count; k++) //������ ���������� ������ ���� <=
            {
                if (msgList[i].index == uiManager.nonMsgPanel.overlayRelatedMsgPanel.relatedMsgList[i].GetComponent<MessageItem>().index)
                    uiManager.nonMsgPanel.overlayRelatedMsgPanel.relatedMsgList.Remove(uiManager.nonMsgPanel.overlayRelatedMsgPanel.relatedMsgList[i]);
            }
        }
        msgCount--;
        Destroy(buttonManager.currentSelectedMessageObject.gameObject);//������ü�� ����Ʈ���� ����
        uiManager.nonMsgPanel.alarmPanel.ReceiveReportCheck();
        uiManager.centerPanel.messageBoxPanel.ShowToggleValueChange();
        uiManager.CloseButton();
        SaveFile();
    }
    public List<MessageItem> currentPanelmsgList = new List<MessageItem>();
    //��� ���� ���������� �������� �Լ�.
    public void DeleteAllMessage()
    {
        if (buttonManager.currentButtonState == BottomButtonState._1ST_PRIORITY_ALARM_DELETE_ALL || buttonManager.currentButtonState == BottomButtonState._2ND_PRIORITY_ALARM_DELETE_ALL ||
            buttonManager.currentButtonState == BottomButtonState._3RD_PRIORITY_ALARM_DELETE_ALL || buttonManager.currentButtonState == BottomButtonState._4TH_PRIORITY_ALARM_DELETE_ALL)
        {
            uiManager.nonMsgPanel.alarmPanel.gameObject.SetActive(false);
        }
        uiManager.nonMsgPanel.deleteWarningPanel.SetActive(false);
        MessageItem[] msgs;
        if (buttonManager.prevButtonState == BottomButtonState._1ST_PRIORITY_ALARM || buttonManager.prevButtonState == BottomButtonState._2ND_PRIORITY_ALARM ||
            buttonManager.prevButtonState == BottomButtonState._3RD_PRIORITY_ALARM || buttonManager.prevButtonState == BottomButtonState._4TH_PRIORITY_ALARM)
        {
            msgs = uiManager.nonMsgPanel.alarmPanel.contents.GetComponentsInChildren<MessageItem>();
        }
        else
        {
            msgs = uiManager.centerPanel.messageBoxPanel.contents.GetComponentsInChildren<MessageItem>();//���翭�� �г��� ������
        }       
        var symbol = uiManager.nonMsgPanel.targetAssignmentPanel;
        currentPanelmsgList = msgs.ToList();
        #region //��ü ���� �ڵ�, �溸�� ���� ������ �����۸� ����ٰ� ���õǾ�������, �������� ��ü������ ��ü�����ϴ� �� �̿ܿ� ���õȰ� ����.
        //foreach (ReportPanelItem item in reports)
        //{
        //packetGameObjectList.Clear();
        //packetList.Clear();
        //Destroy(item.gameObject); 
        //}
        #endregion
        //�޼��� ����
        for (int i = msgList.Count - 1; i >= 0; i--) //������ ������ ��
        {
            for (int k = symbol.msgSymbolList.Count - 1; k >= 0; k--) //�����ܰ� ����Ʈ �� 
            {
                if (symbol.msgSymbolList[k] == null) symbol.msgSymbolList.Remove(symbol.msgSymbolList[k]);
                if (symbol.msgSymbolList[k].GetComponent<IconInfo>().index == msgList[i].index) //��ġ�ϸ� 
                    Destroy(symbol.msgSymbolList[k].gameObject); //������ ����              
            }
            symbol.msgSymbolList.Clear(); //������ ����Ʈ �ʱ�ȭ
            ////���� �������̶�� ���� ���� ��ü���� ���� ������ => ����� �������� ���� �������ұ�?
            if (msgList[i].messageType == MessageType.COMMAND)
            {
                uiManager.nonMsgPanel.overlayRelatedMsgPanel.relatedMsgList.Clear();
                for (int j = 0; j < uiManager.nonMsgPanel.overlayRelatedMsgPanel.relatedMsgList.Count; j++)
                    Destroy(uiManager.nonMsgPanel.overlayRelatedMsgPanel.myScrollviewContents.GetComponentInChildren<MessageItem>());
            }
        }

        for (int j = 0; j < currentPanelmsgList.Count; j++) //������ ȭ�鿡 ���̴� ��ü�� ���� ������ ��
        {
            for (int i = 0; i < msgList.Count; i++)
            {
                if (msgList[i].index == currentPanelmsgList[j].index)//id�� ��ġ�ϸ� �޼��� ����Ʈ����
                {
                    msgList.Remove(msgList[i]);
                    
                }
            }           
            msgCount--;
           
        }

        foreach (MessageItem item in msgs)
        {
            Destroy(item.gameObject);
        }

        SaveFile();
        if (msgList.Count == 0)
        {
            msgCount = 0;
            messageIndex = 0;
        }
        switch (buttonManager.currentButtonState)
        {
            case BottomButtonState._1ST_PRIORITY_ALARM_DELETE_ALL:
            case BottomButtonState._2ND_PRIORITY_ALARM_DELETE_ALL:
            case BottomButtonState._3RD_PRIORITY_ALARM_DELETE_ALL:
            case BottomButtonState._4TH_PRIORITY_ALARM_DELETE_ALL:
                uiManager.nonMsgPanel.alarmPanel.gameObject.SetActive(false);
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
        }
        if (buttonManager.prevButtonState  == BottomButtonState.MESSAGE_IDLE || buttonManager.prevButtonState == BottomButtonState.MESSAGE_RECV || buttonManager.prevButtonState == BottomButtonState.MESSAGE_SEND)
        {
            buttonManager.currentButtonState = buttonManager.prevButtonState; // ���� ���·� �ǵ��ư� 
            switch (buttonManager.currentButtonState)
            {
                case BottomButtonState.MESSAGE_IDLE: uiManager.centerPanel.messageBoxPanel.GetComponent<TabGroup>().selectedTab = uiManager.centerPanel.messageBoxPanel.GetComponent<TabGroup>().tabButtons[0]; break;
                case BottomButtonState.MESSAGE_RECV: uiManager.centerPanel.messageBoxPanel.GetComponent<TabGroup>().selectedTab = uiManager.centerPanel.messageBoxPanel.GetComponent<TabGroup>().tabButtons[1]; break;
                case BottomButtonState.MESSAGE_SEND: uiManager.centerPanel.messageBoxPanel.GetComponent<TabGroup>().selectedTab = uiManager.centerPanel.messageBoxPanel.GetComponent<TabGroup>().tabButtons[2]; break;
            }
        }
        uiManager.nonMsgPanel.alarmPanel.ReceiveReportCheck();
        buttonManager.ChangeButton();
    }
    #endregion
}


