using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Vtas;

//ui�� ������ ��ũ��Ʈ, ui�� ���� �����°͵� ���⼭ �����Ѵ�
public class UIManager : MonoBehaviour
{
    public TopPanel topPanel;
    public RightPanel rightPanel;
    public NonMsgPanel nonMsgPanel;
    public CenterPanel centerPanel;
    public OverlayIconManager overlayIconManager;
    public GameObject currentPanel;//���� ���� �г��� �����ϱ� ���� ����

    //���� ���õ� �������� ��ũ ->dragable���� Ŭ���� ���ʿ� ������ ����
    public GameObject currentSelectedOverlayMark;
    public ButtonManager buttonManager;
    public MessageManager messageManager;
    public WayPointManager wayPointManager;
    public ContentsItemManager itemManager;
    public SelectRole selectRole;
    public NetworkManager networkManager;

    public void AlertPanelOpen() //���� ���α׷����� ���±��, ���� ��ư�� �Ҵ����� �ʰ�, ��� â�� �߸� �����ð� �� ������� ��
    {
        nonMsgPanel.alertPanel.SetActive(true);
    }

    public void OverlayAlertPanelOpen()
    {
        buttonManager.prevButtonState = buttonManager.currentButtonState;
        buttonManager.currentButtonState = BottomButtonState.CAN_NOT_LINK_OVERLAY_AND_COMMAND_ALERT;
        buttonManager.ChangeButton();
        nonMsgPanel.overlayAlertPanel.SetActive(true);
        nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[0].text = "�������� �̿���";
        nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[1].text = "���� ������ �������� �ʾҽ��ϴ�.";
    }
    public void OverlayContinueDisplayPanelOpen()
    {
        buttonManager.currentButtonState = BottomButtonState.OVERLAY_WRITE_COMPLETE;
        buttonManager.ChangeButton();
        nonMsgPanel.overlayAlertPanel.SetActive(true);
        nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[0].text = "������ �ۼ� �Ϸ�";
        nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[1].text = "�ۼ��� �������� ��� ǥ���ϰڽ��ϱ�?";
    }

    public void MessageAlertPanel()
    {
        buttonManager.currentButtonState = BottomButtonState.OPERATION_ENVIRONMENT_VERSION;
        buttonManager.ChangeButton();
        nonMsgPanel.overlayAlertPanel.SetActive(true);
        nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[0].text = "��ǥ ���Է�";
        nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[1].text = "��ǥ�� �Է����ּ���.";
    }

    public void SelectedToggle()
    {
        IEnumerable<Toggle> toggles = centerPanel.msgTypeSelectToggle.ActiveToggles(); // ��� �׷쿡�� isOn�� ���� ����� ��ȯ

        foreach (Toggle item in toggles)
        {
            switch (item.name)
            {
                case "SpyReport": FindEnemyMsg(); break;
                case "TransferReport": TransferMsg(); break;
                case "FirstReport": CBRNFirstMsg(); break;
                case "ScoutReport": CBRNScoutMsg(); break;
                case "StateReport": MyStateMsg(); break;
                case "ObstacleReport": ObstacleMsg(); break;
                case "TargetDamageReport": TargetDamageMsg(); break;
                case "WeatherReport": WeatherMsg(); break;
                case "NoFormReport": NoFormatMsg(); break;
                case "FireSupportReport": FireSupportMsg(); break;
                case "CommandReport": CommandMsg(); break;
                case "OverlayReport": CreateOverlay(); break;
            }
        }
        buttonManager.ChangeButton();
        centerPanel.newMessagePanel.gameObject.SetActive(false);
    }

    private void CmdMsgWarning()
    {
        nonMsgPanel.cmdMsgCheck.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.CAN_NOT_DRAW_OVERLAY_ALERT;
        buttonManager.ChangeButton();
    }

    #region ���ȯ�� UI
    public void OperationEnvActive()
    {
        nonMsgPanel.operationEnvPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.OPERATION_ENVIRONMENT_SETTINGS;
        buttonManager.ChangeButton();
    }
    #endregion

    #region ��ǥ�Է� ��ư Ŭ��
    public void CoordInputButtonClick()
    {       
        buttonManager.prevButtonState = buttonManager.currentButtonState;
        buttonManager.currentButtonState = BottomButtonState.COORD_SELECT;
        switch (buttonManager.prevButtonState)
        {
            case BottomButtonState.FIND_ENEMY:      centerPanel.findEnemyPanel.gameObject.SetActive(false);    break;
            case BottomButtonState.TRANSFER:        centerPanel.transferPanel.gameObject.SetActive(false);     break;
            case BottomButtonState.CBRN_FIRST:      centerPanel.cbrnFirstPanel.gameObject.SetActive(false);    break;
            case BottomButtonState.CBRN_SCOUT:      centerPanel.cbrnScoutPanel.gameObject.SetActive(false);    break;
            case BottomButtonState.MY_STATE:        centerPanel.myStatePanel.gameObject.SetActive(false);      break;
            case BottomButtonState.OBSTACLE:        centerPanel.obstaclePanel.gameObject.SetActive(false);     break;
            case BottomButtonState.TARGET_DAMAGE:   centerPanel.targetDamagePanel.gameObject.SetActive(false); break;
            case BottomButtonState.FIRE_SUPPORT:    centerPanel.fireSupportPanel.gameObject.SetActive(false);  break;
            case BottomButtonState.WRITE_WAY_POINT: nonMsgPanel.wayPointPanel.gameObject.SetActive(false); break; //StartCoroutine(wayPointManager.DrawWayPoint());
            case BottomButtonState.WAY_POINT_INFO:  nonMsgPanel.wayPointInfoPanel.gameObject.SetActive(false); break;
            case BottomButtonState.SELECT_WAY_POINT_SYMBOL:break;
        }
        nonMsgPanel.inputCoordPanel.gameObject.SetActive(true);
        wayPointManager.CopyWayPoint();
        buttonManager.ChangeButton();
        if (currentSelectedOverlayMark != null)//���õ� �ɺ��� �ִٸ� 
        {
            currentSelectedOverlayMark.GetComponent<DragAndDrop>().startDragging = true; //�巡�� ����
            currentSelectedOverlayMark.gameObject.GetComponent<DragAndDrop>().changePos = true;
            if (currentSelectedOverlayMark.GetComponent<WayPointObjectInfo>() != null)//���� ���õ� ��ü�� �̵����̶�� 
            {
                buttonManager.prevButtonState = BottomButtonState.SELECT_WAY_POINT_SYMBOL_EDIT_COORD;//���� �������� ���¸� ���� ��ư���¿� ����
            }
        }
    }
    GameObject ScoutItem;
    public GameObject lastSymbol;
    //��ǥ �Է� :: Ȯ��
    public void ReturnPrevPanel()
    {
        string result = nonMsgPanel.inputCoordPanel.clickCoord;
        switch (buttonManager.prevButtonState)
        {
            case BottomButtonState.FIND_ENEMY:
                centerPanel.findEnemyPanel.gameObject.SetActive(true);
                centerPanel.findEnemyPanel.targetPos.text = result;
                buttonManager.currentButtonState = BottomButtonState.FIND_ENEMY;
                buttonManager.ChangeButton();
                break;
            case BottomButtonState.TRANSFER:
                centerPanel.transferPanel.gameObject.SetActive(true);
                centerPanel.transferPanel.position.text = result;
                buttonManager.currentButtonState = BottomButtonState.TRANSFER;
                buttonManager.ChangeButton();
                break;
            case BottomButtonState.CBRN_FIRST:
                centerPanel.cbrnFirstPanel.gameObject.SetActive(true);
                centerPanel.cbrnFirstPanel.attackedPos.text = result;
                buttonManager.currentButtonState = BottomButtonState.CBRN_FIRST;
                buttonManager.ChangeButton();
                break;
            case BottomButtonState.CBRN_SCOUT:
                centerPanel.cbrnScoutPanel.gameObject.SetActive(true);
                ScoutItem = Instantiate(centerPanel.cbrnScoutPanel.scoutPrefItem, centerPanel.cbrnScoutPanel.scoutItemParent); //��ǥ�� ���� ��ü�� ȭ�������������� �߰�
                ScoutItem.GetComponent<CBRNScoutItem>().myPos = ScoutItem.GetComponentsInChildren<TextMeshProUGUI>()[1].text = result; //��ǥ�� �Է�
                centerPanel.cbrnScoutPanel.SpecimenList.Add(ScoutItem.GetComponent<CBRNScoutItem>());//�����ؼ� ����Ʈ�� ����
                centerPanel.cbrnScoutPanel.ShowListItem();//�����ִ��ڵ�
                buttonManager.currentButtonState = BottomButtonState.CBRN_SCOUT;
                buttonManager.ChangeButton();
                break;
            case BottomButtonState.MY_STATE:
                centerPanel.myStatePanel.gameObject.SetActive(true);
                if (centerPanel.myStatePanel.toggles[0].isOn == true)
                {
                    centerPanel.myStatePanel.leftCoord.text = result;
                }
                else if (centerPanel.myStatePanel.toggles[1].isOn == true)
                {
                    centerPanel.myStatePanel.rightCoord.text = result;
                }
                buttonManager.currentButtonState = BottomButtonState.MY_STATE;
                buttonManager.ChangeButton();
               
                break;
            case BottomButtonState.OBSTACLE:
                centerPanel.obstaclePanel.gameObject.SetActive(true);
                centerPanel.obstaclePanel.obstaclePos.text = result;
                buttonManager.currentButtonState = BottomButtonState.OBSTACLE;
                buttonManager.ChangeButton();
                break;
            case BottomButtonState.TARGET_DAMAGE:
                centerPanel.targetDamagePanel.gameObject.SetActive(true);
                centerPanel.targetDamagePanel.position.text = result;
                buttonManager.currentButtonState = BottomButtonState.TARGET_DAMAGE;
                buttonManager.ChangeButton();
                break;
            case BottomButtonState.FIRE_SUPPORT:
                centerPanel.fireSupportPanel.gameObject.SetActive(true);
                centerPanel.fireSupportPanel.targetPos.text = result;
                buttonManager.currentButtonState = BottomButtonState.FIRE_SUPPORT;
                buttonManager.ChangeButton();

                break;
            case BottomButtonState.OVERLAY_SYMBOL_MOVE:
                break;
            case BottomButtonState.WRITE_WAY_POINT:
                nonMsgPanel.inputCoordPanel.gameObject.SetActive(false);//��ǥ�� �����ִ� â�� �ݴ´�.
                if (buttonManager.prevButtonState == BottomButtonState.SELECT_WAY_POINT_SYMBOL_EDIT_COORD)//�̵��� ��ǥ ������ ���� ���� ��쿡��
                {
                    buttonManager.currentButtonState = BottomButtonState.SELECT_TARGET_SYMBOL;
                    buttonManager.ChangeButton();
                }
                //�̵������� ���¿��� �ʿ� Ŭ���� �ϸ� �� ������ �� ��ü�� �����ϱ⶧���� �̵� �Ұ��� ���¿����� ���� �ﵵ�� ������ �ɾ��
                else if (currentSelectedOverlayMark != null)
                {
                    if (currentSelectedOverlayMark.gameObject.GetComponent<DragAndDrop>().changePos == false)
                    {
                        wayPointManager.DrawWayPoint();//StopCoroutine(wayPointManager.DrawWayPoint());
                        wayPointManager.InsertWayPointInfo();
                        buttonManager.currentButtonState = BottomButtonState.EDIT_WAY_POINT_CLOSE;
                        buttonManager.ChangeButton();
                    }
                }
                else //���õ� ��ü�� ���ٸ� ó������ �̵��θ� �ۼ����̹Ƿ� ���� ��� �׸��� �Լ��� �ٷ� �Ѿ 
                {
                    wayPointManager.DrawWayPoint();// StopCoroutine(wayPointManager.DrawWayPoint());
                    wayPointManager.InsertWayPointInfo();
                    buttonManager.currentButtonState = BottomButtonState.EDIT_WAY_POINT_CLOSE;
                    buttonManager.ChangeButton();
                }
                break;
            case BottomButtonState.EDIT_WAY_POINT_CLOSE:
                //��ġ�� �����ϰ� ����.
                buttonManager.currentButtonState = BottomButtonState.WAY_POINT;
                buttonManager.ChangeButton();
                break;
            case BottomButtonState.SELECT_WAY_POINT_SYMBOL:
                break;
            case BottomButtonState.TARGET_ASSIGNMENT:
                nonMsgPanel.targetAssignmentPanel.targetPosition.text = result; //��ǥ�Է� 
                buttonManager.currentButtonState = BottomButtonState.SELECT_TARGET_SYMBOL;
                buttonManager.ChangeButton();
                break;
        }
        //else if (UIOpenedJustBefore == marginalNotePanel) //���� �г��� �����ֱ��� ��� �����ֱ�� ���ư� 
        //{
        //    currentButtonState = BottomButtonState.MARGINAL_NOTE;
        //    ChangeButtonName();
        //}
        nonMsgPanel.inputCoordPanel.gameObject.SetActive(false);//����
    }
    #endregion

 
    #region �г� Ȱ��ȭ
    //���߰� ����
    public void FindEnemyMsg()
    {
        centerPanel.findEnemyPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.FIND_ENEMY;
    }
    //�ļ� ���� 
    public void TransferMsg()
    {
        centerPanel.transferPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.TRANSFER;
    }
    //ȭ���� ����
    public void CBRNFirstMsg()
    {
        centerPanel.cbrnFirstPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.CBRN_FIRST;
    }
    public void CBRNScoutMsg()
    {
        centerPanel.cbrnScoutPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.CBRN_SCOUT;
    }
    public void MyStateMsg()
    {
        centerPanel.myStatePanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.MY_STATE;
    }
    public void ObstacleMsg()
    {
        centerPanel.obstaclePanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.OBSTACLE;
    }
    public void TargetDamageMsg()
    {
        centerPanel.targetDamagePanel.gameObject.SetActive(true);

        foreach (TMP_InputField item in centerPanel.targetDamagePanel.GetComponentsInChildren<TMP_InputField>())
        {
            item.text = "";
        }
        buttonManager.currentButtonState = BottomButtonState.TARGET_DAMAGE;
    }
    //������� �������� ����
    public void NoFormatMsg()
    {
        centerPanel.noformPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.NO_FORMAT;
    }
    public void FireSupportMsg()
    {
        centerPanel.fireSupportPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.FIRE_SUPPORT;
    }
    public void CommandMsg()
    {
        centerPanel.commandPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.COMMAND;
    }

    public void wayPointPanelActive()
    {
        currentSelectedOverlayMark = null;
        if (wayPointManager.wayPointIndex < 7) //7�� ���ϸ�
        {
            for (int i = 0; i < wayPointManager.wayPointList.Count; i++)
            {
                wayPointManager.wayPointList[i].gameObject.SetActive(true);
            }
            if (wayPointManager.wayPointList.Count > 1)
            {
                wayPointManager.lineConnect.transforms = new RectTransform[wayPointManager.wayPointList.Count];
                for (int i = 0; i < wayPointManager.wayPointList.Count; i++)
                    wayPointManager.lineConnect.transforms[i] = wayPointManager.wayPointList[i].GetComponent<RectTransform>();
            }
            wayPointManager.lineConnect.UpdateLine();
            wayPointManager.uiLines.SetAllDirty();
            buttonManager.currentButtonState = BottomButtonState.WRITE_WAY_POINT;
            nonMsgPanel.wayPointPanel.gameObject.SetActive(true);
            buttonManager.ChangeButton();
        }
        else//7���� �Ѿ�� ����� ���
        {
            nonMsgPanel.overlayAlertPanel.SetActive(true);
            nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[0].text = "�̵��� ����";
            nonMsgPanel.overlayAlertPanel.GetComponentsInChildren<TextMeshProUGUI>()[1].text = "������� �ִ� 7��������\n�׸� �� �ֽ��ϴ�.";
            buttonManager.currentButtonState = BottomButtonState.WAY_POINT_EXCEED_ALERT;
            buttonManager.ChangeButton();
        }
    }
    public CommandData tempCommandData;
    //�����ֱ�
    public void OverlayRelatedPanelActive()
    {       
        buttonManager.prevButtonState = buttonManager.currentButtonState;
        if (nonMsgPanel.overlayRelatedMsgPanel.gameObject.activeSelf == true)//������ ���� ���� â�� ���������� 
        {
            nonMsgPanel.overlayRelatedMsgPanel.gameObject.SetActive(false); //�ݾ���
            nonMsgPanel.overlayRelatedMsgPanel.currentSelectedData.isLink = true;//���� ������ ��ü�� ����Ǿ����� �˷��� => ���������� ��ü�� ������ �־���Ѵ�.
            //�����ֱ� �������� �׸� ����� ���� ������ �̸��� �־���
            for (int i = 0; i < messageManager.msgList.Count; i++)
            {
                if (buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().index == messageManager.msgList[i].index)
                {
                    tempCommandData = (CommandData)messageManager.msgList[i];  //���������� ��ȣ������ ���� ����                  
                    centerPanel.marginalNotePanel.relevantReport.text = messageManager.msgList[i].messageTitle; //�����ֱ�â ������������ ����� ���������� ������ �־���
                }
            }     
        }
        centerPanel.marginalNotePanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.OVERLAY_MARGINAL_NOTE;
        buttonManager.ChangeButton();
        //�����ֱ� â�� �������� ��ư ������ �޶����� ���⿡ �߰�
    }

    public void AlarmPanelActive()
    {
        buttonManager.currentButtonState = BottomButtonState.ALARM;
        buttonManager.ChangeButton();
        centerPanel.messageBoxPanel.gameObject.SetActive(false);
        if (nonMsgPanel.alarmPanel.gameObject.activeSelf == false)
        {
            nonMsgPanel.alarmPanel.gameObject.SetActive(true);
            nonMsgPanel.alarmPanel.DisplayAlarmItem1();
        }
        buttonManager.ChangeButton();
    }
    public void MapSettingPanelActive()
    {
        buttonManager.currentButtonState = BottomButtonState.MAP;
        if (nonMsgPanel.mapSettingPanel.gameObject.activeSelf == false)
        {
            nonMsgPanel.mapSettingPanel.gameObject.SetActive(true);
        }
        buttonManager.ChangeButton();
    }

    public void DeleteMsgPanel()
    {
        nonMsgPanel.deleteWarningPanel.SetActive(true);
        nonMsgPanel.deleteWarningPanel.GetComponentsInChildren<TextMeshProUGUI>()[0].text = "���� ����";
        nonMsgPanel.deleteWarningPanel.GetComponentsInChildren<TextMeshProUGUI>()[1].text = "������ \n�����Ͻðڽ��ϱ�?";
        buttonManager.currentButtonState = BottomButtonState.DELETE_MESSAGE;
        buttonManager.ChangeButton();
    }
    public void DeleteAllMsgPanel()
    {
        nonMsgPanel.deleteWarningPanel.SetActive(true);     
        nonMsgPanel.deleteWarningPanel.GetComponentsInChildren<TextMeshProUGUI>()[0].text = "���� ��� ����";
        nonMsgPanel.deleteWarningPanel.GetComponentsInChildren<TextMeshProUGUI>()[1].text = "������ ���� \n �����Ͻðڽ��ϱ�?";
        buttonManager.currentButtonState = BottomButtonState.DELETE_ALL_MESSAGE;
        buttonManager.ChangeButton();
    }
    void WeatherMsg()
    {
        centerPanel.weatherPanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.WEATHER;
        buttonManager.ChangeButton();
    }
    MsgData tempMsgData;
    public void CreateOverlay()
    {
        buttonManager.prevButtonState = buttonManager.currentButtonState;
        buttonManager.currentButtonState = BottomButtonState.OVERLAY;
        

        if (buttonManager.currentButtonState == BottomButtonState.OVERLAY)//��ư�� ������ ������ �ۼ��� �� ��� ����޼����� ���� �ʾ� �� ������ �߰���
        {    //������ ������ 
            if (messageManager.msgList.Count > 0)
            {
                for (int i = 0; i < messageManager.msgList.Count; i++)//��ȯ�ϹǷ� ����ġ�ϰ�� ������� ����, ��ġ�ϸ� ������â�� ���⶧���� ���� ������ ����������.
                {   // ���� ������� �����̰�, ������ ���������� �ִ��� �˻�
                    if (messageManager.msgList[i].messageState == MessageState.IDLE && messageManager.msgList[i].messageType == Vtas.MessageType.COMMAND)
                        tempMsgData = messageManager.msgList[i];
                }
                //tempData�� ���� �� ������ ���ǹ��� ���鼭 ��� �޼����� ������ â�� ���� �߱⶧��, �� ���� ����� ã���� �ٲٵ��� ���� 
                if (tempMsgData != null)
                {   //���ǿ� ��ġ�ϴ� ��ü�� �ִٸ� ������ â�� ����
                    rightPanel.overlayTool.gameObject.SetActive(true);
                    buttonManager.currentButtonState = BottomButtonState.OVERLAY;
                    buttonManager.ChangeButton();
                }
                else
                    CmdMsgWarning();
            }
            else //������ �������������� ������� ���
                CmdMsgWarning();//��� �г� Ȱ��ȭ   ();
        }     
    }
    #endregion

    public void CloseButton()
    {
        switch (buttonManager.currentButtonState)
        {
            #region ��з����� ����ȭ������
            case BottomButtonState.MAP: //���� ������ ����
            case BottomButtonState.MAP_BACKGROUND:
            case BottomButtonState.MAP_COORD:
            case BottomButtonState.MAP_FEATURE:
            case BottomButtonState.MAP_MOVE:
                nonMsgPanel.mapSettingPanel.gameObject.SetActive(false);
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
            //�������� ����
            case BottomButtonState.MESSAGE_IDLE:
            case BottomButtonState.MESSAGE_RECV:    
            case BottomButtonState.MESSAGE_SEND:
                centerPanel.messageBoxPanel.gameObject.SetActive(false);
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
            //�溸���� ����
            case BottomButtonState.ALARM:
            case BottomButtonState._1ST_PRIORITY_ALARM:
            case BottomButtonState._2ND_PRIORITY_ALARM:
            case BottomButtonState._3RD_PRIORITY_ALARM:
            case BottomButtonState._4TH_PRIORITY_ALARM:
                nonMsgPanel.alarmPanel.gameObject.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
                //������ ������ ����
            case BottomButtonState.OVERLAP_MANAGEMENT:
            case BottomButtonState.INDIVIDUAL_MANAGEMENT:
                nonMsgPanel.overlayManagementPanel.GetComponent<TabGroup>().selectedTab = null;
                nonMsgPanel.overlayManagementPanel.GetComponent<TabGroup>().ResetTabs();
                nonMsgPanel.overlayManagementPanel.gameObject.SetActive(false);
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
            case BottomButtonState.WAY_POINT:
                nonMsgPanel.wayPointPanel.gameObject.SetActive(false);
                nonMsgPanel.wayPointInfoPanel.DeleteObj();
                wayPointManager.wayPointList.Clear();
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
            case BottomButtonState.OPERATION_ENVIRONMENT_SETTINGS:
            case BottomButtonState.OPERATION_ENVIRONMENT_USER_REGISTRATION:
            case BottomButtonState.OPERATION_ENVIRONMENT_POSITION_REPORT:
            case BottomButtonState.OPERATION_ENVIRONMENT_VERSION:
            case BottomButtonState.OPERATION_ENVIRONMENT_EMERGENCY_CLEARANCE:
                nonMsgPanel.operationEnvPanel.gameObject.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
            case BottomButtonState.TARGET_ASSIGNMENT:
                nonMsgPanel.targetAssignmentPanel.gameObject.SetActive(false);
                 buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
            #endregion
            case BottomButtonState.WRITE_NEW_MESSAGE:
                centerPanel.newMessagePanel.gameObject.SetActive(false);
                centerPanel.messageBoxPanel.gameObject.SetActive(true);
                buttonManager.currentButtonState = BottomButtonState.MESSAGE_IDLE;
                break;

            //���������� ���ư�����.
            case BottomButtonState.DELETE_MESSAGE:
                nonMsgPanel.deleteWarningPanel.SetActive(false);
                buttonManager.currentButtonState = buttonManager.prevButtonState;//���� �� �ݱ� ó���� �ؾ����������� ����
                break;
            case BottomButtonState.DELETE_ALL_MESSAGE:
                buttonManager.currentButtonState = buttonManager.prevButtonState;
                nonMsgPanel.deleteWarningPanel.SetActive(false);
                break;
            case BottomButtonState.CAN_NOT_DRAW_OVERLAY_ALERT:
                nonMsgPanel.cmdMsgCheck.SetActive(false);
                centerPanel.newMessagePanel.gameObject.SetActive(true);
                buttonManager.currentButtonState = BottomButtonState.WRITE_NEW_MESSAGE;
                break;
            case BottomButtonState.WHEN_CLICKED_EDIT_MESSAGE: //���� ��ư�� ���� �����϶�, � ������ ���ȴ��� �� �� �����Ƿ� ���� ���¸� üũ�Ѵ�.
                switch (buttonManager.prevButtonState)
                {
                    case BottomButtonState.FIND_ENEMY: centerPanel.findEnemyPanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.TRANSFER: centerPanel.transferPanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.CBRN_FIRST: centerPanel.cbrnFirstPanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.CBRN_SCOUT: centerPanel.cbrnScoutPanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.MY_STATE: centerPanel.myStatePanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.OBSTACLE: centerPanel.obstaclePanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.NO_FORMAT: centerPanel.noformPanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.TARGET_DAMAGE: centerPanel.targetDamagePanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.FIRE_SUPPORT: centerPanel.fireSupportPanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.COMMAND: centerPanel.commandPanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                    case BottomButtonState.OVERLAY: centerPanel.marginalNotePanel.gameObject.SetActive(false); ReturnToNewMessageState(); break;
                }
                break;
            #region �̵��� ���� ����
            case BottomButtonState.WRITE_WAY_POINT:
                nonMsgPanel.wayPointPanel.gameObject.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.WAY_POINT;
                break;
            case BottomButtonState.WAY_POINT_INFO:
                nonMsgPanel.wayPointInfoPanel.gameObject.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.WAY_POINT;
                break;
            case BottomButtonState.EDIT_WAY_POINT_CLOSE:
            case BottomButtonState.SELECT_WAY_POINT_SYMBOL:
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.WAY_POINT;
                break;
            case BottomButtonState.DELETE_ALL_WAYPOINT:
            case BottomButtonState.HIDE_WAYPOINT:
                nonMsgPanel.deleteWarningPanel.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.WAY_POINT;
                break;
            #endregion
            case BottomButtonState.COORD_SELECT://�̵��� ��ǥ���� ��ҽ� ���� ��ġ�� ������, Ȯ���� �����ٸ� ���� ����� ���� ��ǥ�� ���̺� �ؾ���
                nonMsgPanel.inputCoordPanel.gameObject.SetActive(false);
                switch (buttonManager.prevButtonState)
                {
                    case BottomButtonState.FIND_ENEMY:
                    case BottomButtonState.OBSTACLE:
                        DeleteOverlayMark();
                        centerPanel.newMessagePanel.gameObject.SetActive(true); buttonManager.currentButtonState = BottomButtonState.WRITE_NEW_MESSAGE;
                        break;
                    case BottomButtonState.TRANSFER: 
                    case BottomButtonState.CBRN_FIRST: 
                    case BottomButtonState.CBRN_SCOUT: 
                    case BottomButtonState.MY_STATE: 
                    case BottomButtonState.NO_FORMAT: 
                    case BottomButtonState.TARGET_DAMAGE:
                    case BottomButtonState.FIRE_SUPPORT:
                    case BottomButtonState.COMMAND: 
                    case BottomButtonState.OVERLAY_MARGINAL_NOTE:
                        centerPanel.newMessagePanel.gameObject.SetActive(true); buttonManager.currentButtonState = BottomButtonState.WRITE_NEW_MESSAGE;
                        break;
                    case BottomButtonState.SELECT_WAY_POINT_SYMBOL_EDIT_COORD:
                        //���� ���õ� ��ü�� �̵��Ұ����·� �����.
                        buttonManager.currentButtonState = BottomButtonState.WAY_POINT;
                        break;
                    case BottomButtonState.WRITE_WAY_POINT:
                        nonMsgPanel.wayPointPanel.gameObject.SetActive(true);
                        buttonManager.currentButtonState = BottomButtonState.WRITE_WAY_POINT;
                        break;
                }
                break;
            #region ���� ����
            case BottomButtonState.FIND_ENEMY:
                var symbol = nonMsgPanel.targetAssignmentPanel;
                if (buttonManager.prevButtonState != BottomButtonState.FIND_ENEMY_SAVE)//������ ���ļ� �� ���°� �ƴ϶��
                {
                    for (int i = 0; i < symbol.msgSymbolList.Count; i++)
                    {
                        if (symbol.msgSymbolList[i] == null)
                        {
                            symbol.msgSymbolList.Remove(symbol.msgSymbolList[i]);
                        }
                        symbol.msgSymbolList.RemoveAt(symbol.msgSymbolList.Count - 1);
                        Destroy(lastSymbol);
                    }//�ۼ� �� �ݱ⸦ ������ �������� �����Ǿ���Ѵ�.
                }
                centerPanel.findEnemyPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.TRANSFER:
                centerPanel.transferPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.CBRN_FIRST:
                centerPanel.cbrnFirstPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.CBRN_SCOUT:
                centerPanel.cbrnScoutPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.MY_STATE:
                centerPanel.myStatePanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.OBSTACLE:
                centerPanel.obstaclePanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.TARGET_DAMAGE:
                centerPanel.targetDamagePanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.WEATHER:
                centerPanel.weatherPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.NO_FORMAT:
                centerPanel.noformPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.FIRE_SUPPORT:
                centerPanel.fireSupportPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.COMMAND:
                centerPanel.commandPanel.gameObject.SetActive(false);
                ReturnToNewMessageState();
                break;
            case BottomButtonState.OVERLAY:
                if (buttonManager.prevButtonState == BottomButtonState.WRITE_NEW_MESSAGE)
                {

                }
                else
                {
                    nonMsgPanel.overlayPanel.gameObject.SetActive(false);
                    buttonManager.currentButtonState = BottomButtonState.NONE;
                }
                break;

            case BottomButtonState.OVERLAY_MARGINAL_NOTE:
                centerPanel.marginalNotePanel.gameObject.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.OVERLAY;              
                break;
            case BottomButtonState.CAN_NOT_LINK_OVERLAY_AND_COMMAND_ALERT:
                nonMsgPanel.overlayAlertPanel.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.WRITE_NEW_MESSAGE;
                centerPanel.newMessagePanel.gameObject.SetActive(true);
                break;
            case BottomButtonState.OVERLAY_WRITE_COMPLETE:
                nonMsgPanel.overlayAlertPanel.SetActive(false);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;
            case BottomButtonState.INDIVIDUAL_MANAGEMENT_CLOSE_OVERLAY:
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.INDIVIDUAL_MANAGEMENT;
                break;
            case BottomButtonState.OVERLAY_MARGINAL_NOTE_RELEVANT_MESSAGE:
                nonMsgPanel.overlayRelatedMsgPanel.gameObject.SetActive(false);
                centerPanel.marginalNotePanel.gameObject.SetActive(true);
                buttonManager.prevButtonState = buttonManager.currentButtonState;
                buttonManager.currentButtonState = BottomButtonState.OVERLAY_MARGINAL_NOTE;
                break;
            case BottomButtonState.MESSAGE_RECV_OPEN:
            case BottomButtonState.MESSAGE_SEND_OPEN:
                switch (buttonManager.currentSelectedMessageObject.GetComponent<MessageItem>().messageType)
                {
                    case Vtas.MessageType.FIND_ENEMY: centerPanel.findEnemyPanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.TRANSFER: centerPanel.transferPanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.CBRN_FIRST: centerPanel.cbrnFirstPanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.CBRN_SCOUT: centerPanel.cbrnScoutPanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.MY_STATE: centerPanel.myStatePanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.OBSTACLE: centerPanel.obstaclePanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.NO_FORMAT: centerPanel.noformPanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.TARGET_DAMAGE: centerPanel.targetDamagePanel.gameObject.SetActive(false); break;
                    case Vtas.MessageType.FIRE_SUPPORT: centerPanel.fireSupportPanel.gameObject.SetActive(false);  break;
                    case Vtas.MessageType.COMMAND: centerPanel.commandPanel.gameObject.SetActive(false); break;
                    case Vtas.MessageType.OVERLAY: centerPanel.marginalNotePanel.gameObject.SetActive(false);break;
                }
                buttonManager.currentButtonState = BottomButtonState.NONE;
                break;


                #endregion
        }
        currentSelectedOverlayMark = null;
        buttonManager.ChangeButton();
    }

    private void ReturnToNewMessageState()
    {
        ClearInputField();
        centerPanel.newMessagePanel.gameObject.SetActive(true);
        buttonManager.currentButtonState = BottomButtonState.WRITE_NEW_MESSAGE;
    }

    public void OverlayCancelButtonClick()
    {
        IconInfo[] icons = rightPanel.OverlayContainer.GetComponentsInChildren<IconInfo>();

        foreach (IconInfo item in icons)
        {
            Destroy(item.gameObject);
        }
        CloseButton();
    }
    public void WayPointCancelButtonClick()
    {
        IconInfo[] icons = wayPointManager.GetComponentsInChildren<IconInfo>();

        foreach (IconInfo item in icons)
        {
            Destroy(item.gameObject);
        }
        CloseButton();
    }
    public void BackToTheWayPointMainState()
    {
        wayPointManager.ButtonSelectCancel();//���õ� ��ư�� ���°� ��ҵǾ����
        CloseButton();
    }

    public void UnInteractableUI(GameObject currentPanel)
    {
        TMP_InputField[] tmpInputField = currentPanel.GetComponentsInChildren<TMP_InputField>();
        TMP_Dropdown[] tmpDropdowns = currentPanel.GetComponentsInChildren<TMP_Dropdown>();

        for (int i = 0; i < tmpInputField.Length; i++)
        {
            tmpInputField[i].interactable = false;
        }
        for (int i = 0; i < tmpDropdowns.Length; i++)
        {
            tmpDropdowns[i].interactable = false;
        }
    }
    //������ �Ұ����ϰ� �ߴ� ���� �ٽ� Ǯ����
    public static void InteractableUI(GameObject currentPanel)
    {
        TMP_InputField[] tmpInputField = currentPanel.GetComponentsInChildren<TMP_InputField>();
        TMP_Dropdown[] tmpDropdowns = currentPanel.GetComponentsInChildren<TMP_Dropdown>();

        for (int i = 0; i < tmpInputField.Length; i++)
        {
            tmpInputField[i].interactable = true;
        }
        for (int i = 0; i < tmpDropdowns.Length; i++)
        {
            tmpDropdowns[i].interactable = true;
        }
    }
    public void ClearInputField()
    {
        switch (buttonManager.currentButtonState)
        {
            case BottomButtonState.FIND_ENEMY: currentPanel = centerPanel.findEnemyPanel.gameObject; break;
            case BottomButtonState.TRANSFER: currentPanel = centerPanel.transferPanel.gameObject; break;
            case BottomButtonState.CBRN_FIRST: currentPanel = centerPanel.cbrnFirstPanel.gameObject; break;
            case BottomButtonState.CBRN_SCOUT: currentPanel = centerPanel.cbrnScoutPanel.gameObject; break;
            case BottomButtonState.MY_STATE: currentPanel = centerPanel.myStatePanel.gameObject; break;
            case BottomButtonState.OBSTACLE: currentPanel = centerPanel.obstaclePanel.gameObject; break;
            case BottomButtonState.WEATHER: currentPanel = centerPanel.weatherPanel.gameObject; break;
            case BottomButtonState.NO_FORMAT: currentPanel = centerPanel.noformPanel.gameObject; break;
            case BottomButtonState.TARGET_DAMAGE: currentPanel = centerPanel.targetDamagePanel.gameObject; break;
            case BottomButtonState.FIRE_SUPPORT: currentPanel = centerPanel.fireSupportPanel.gameObject; break;
            case BottomButtonState.COMMAND: currentPanel = centerPanel.commandPanel.gameObject; break;
            case BottomButtonState.WRITE_WAY_POINT: currentPanel = nonMsgPanel.wayPointPanel.gameObject; break; //StartCoroutine(wayPointManager.DrawWayPoint());
            case BottomButtonState.WAY_POINT_INFO: currentPanel = nonMsgPanel.wayPointInfoPanel.gameObject; break;
            case BottomButtonState.WHEN_CLICKED_EDIT_MESSAGE:
                switch (buttonManager.prevButtonState)
                {
                    case BottomButtonState.FIND_ENEMY: currentPanel = centerPanel.findEnemyPanel.gameObject; break;
                    case BottomButtonState.TRANSFER: currentPanel = centerPanel.transferPanel.gameObject; break;
                    case BottomButtonState.CBRN_FIRST: currentPanel = centerPanel.cbrnFirstPanel.gameObject; break;
                    case BottomButtonState.CBRN_SCOUT: currentPanel = centerPanel.cbrnScoutPanel.gameObject; break;
                    case BottomButtonState.MY_STATE: currentPanel = centerPanel.myStatePanel.gameObject; break;
                    case BottomButtonState.OBSTACLE: currentPanel = centerPanel.obstaclePanel.gameObject; break;
                    case BottomButtonState.NO_FORMAT: currentPanel = centerPanel.noformPanel.gameObject; break;
                    case BottomButtonState.TARGET_DAMAGE: currentPanel = centerPanel.targetDamagePanel.gameObject; break;
                    case BottomButtonState.WEATHER: currentPanel = centerPanel.weatherPanel.gameObject; break;
                    case BottomButtonState.FIRE_SUPPORT: currentPanel = centerPanel.fireSupportPanel.gameObject; break;
                    case BottomButtonState.COMMAND: currentPanel = centerPanel.commandPanel.gameObject; break;
                    case BottomButtonState.WRITE_WAY_POINT: currentPanel = nonMsgPanel.wayPointPanel.gameObject; break; //StartCoroutine(wayPointManager.DrawWayPoint());
                    case BottomButtonState.WAY_POINT_INFO: currentPanel = nonMsgPanel.wayPointInfoPanel.gameObject; break;
                    case BottomButtonState.OVERLAY: currentPanel = centerPanel.marginalNotePanel.gameObject;break;
                }
                break;
            case BottomButtonState.OVERLAY: currentPanel = centerPanel.marginalNotePanel.gameObject; break;
        }
        TMP_InputField[] tmpInputField = currentPanel.GetComponentsInChildren<TMP_InputField>();

        for (int i = 0; i < tmpInputField.Length; i++)
        {
            tmpInputField[i].text = "";
        }
    }

    //�̵��� �ۼ� ��ư Ŭ��
    public void OpenWayPointUI()
    {
        nonMsgPanel.wayPointInfoPanel.gameObject.SetActive(true);
        nonMsgPanel.wayPointInfoPanel.ShowWayPointObj();
        buttonManager.currentButtonState = BottomButtonState.WAY_POINT_INFO;
        buttonManager.ChangeButton();
    }

    public void PrintSymbolRoutine()
    {
        var symbol = nonMsgPanel.targetAssignmentPanel;
        if (buttonManager.prevButtonState == BottomButtonState.FIND_ENEMY)
        {
            if (currentSelectedOverlayMark == null)
            {
                GameObject Symbolpref = Instantiate(itemManager.overlayIconPrefab, nonMsgPanel.symbolContainer.transform);//������ ����
                Symbolpref.transform.position = nonMsgPanel.inputCoordPanel.ClickPoint;
                Symbolpref.GetComponent<Image>().sprite = rightPanel.overlayIcon.enemySymbol;
                Symbolpref.GetComponent<Image>().color = Color.red;
                Symbolpref.transform.position = rightPanel.overlayIcon.GetScreenPosition(Symbolpref.transform.position); //3d���� 2d�� ��ǥ�� ��ȯ
                Symbolpref.GetComponent<IconInfo>().myPosition = rightPanel.overlayIcon.GetWorldPosition(Symbolpref.transform.position); //ui��ǥ�� ��ȯ
                Symbolpref.GetComponent<IconInfo>().index = messageManager.messageIndex;
                symbol.msgSymbolList.Add(Symbolpref); // �ϴ��� ������ ����Ʈ�� ���� �������� ���� ������,
                lastSymbol = currentSelectedOverlayMark = Symbolpref;
            }
            else
            {
                GameObject go = currentSelectedOverlayMark;
                go.transform.position = nonMsgPanel.inputCoordPanel.ClickPoint;
                go.transform.position = rightPanel.overlayIcon.GetScreenPosition(go.transform.position); //3d���� 2d�� ��ǥ�� ��ȯ
                go.GetComponent<IconInfo>().myPosition = rightPanel.overlayIcon.GetWorldPosition(go.transform.position); //ui��ǥ�� ��ȯ
            }
        }
        else if (buttonManager.prevButtonState == BottomButtonState.OBSTACLE)
        {
            if (currentSelectedOverlayMark == null)
            {
                GameObject Symbolpref = Instantiate(itemManager.overlayIconPrefab, nonMsgPanel.symbolContainer.transform);//������ ����
                Symbolpref.transform.position =  nonMsgPanel.inputCoordPanel.ClickPoint;
                Symbolpref.GetComponent<Image>().sprite = rightPanel.overlayIcon.obstacleSymbol; //������ �ɺ� ��ü
                Symbolpref.GetComponent<Image>().color = Color.green;                    //�� �־���
                Symbolpref.transform.position = rightPanel.overlayIcon.GetScreenPosition(Symbolpref.transform.position); //3d���� 2d�� ��ǥ�� ��ȯ
                Symbolpref.GetComponent<IconInfo>().myPosition = rightPanel.overlayIcon.GetWorldPosition(Symbolpref.transform.position); //ui��ǥ�� ��ȯ
                Symbolpref.GetComponent<IconInfo>().index = messageManager.messageIndex;// ������ ���� �ε��� �ο� 
                symbol.msgSymbolList.Add(Symbolpref); // �ϴ��� ������ ����Ʈ�� ���� �������� ���� ������,
                currentSelectedOverlayMark = Symbolpref;
            }
            else
            {
                GameObject go = currentSelectedOverlayMark;
                go.transform.position =  nonMsgPanel.inputCoordPanel.ClickPoint;
                go.transform.position = rightPanel.overlayIcon.GetScreenPosition(go.transform.position); //3d���� 2d�� ��ǥ�� ��ȯ
                go.GetComponent<IconInfo>().myPosition = rightPanel.overlayIcon.GetWorldPosition(go.transform.position); //ui��ǥ�� ��ȯ
            }
        }             
    }

    //������Ʈ ����
    public void DeleteOverlayMark()
    {
        //����Ʈ���� �����ϰ�
        for (int i = overlayIconManager.iconList.Count - 1; i >= 0; i--)
        {
            if (overlayIconManager.iconList[i] == currentSelectedOverlayMark)
                overlayIconManager.iconList.Remove(overlayIconManager.iconList[i]);
        }    
        Destroy(currentSelectedOverlayMark);  //���ӿ�����Ʈ�� ��������
    }
    //���������� ��ư�� ��������
    public void ReleativeOverlayButtonClick()
    {
        //���� ���� �������� ����
        //���� ������ ����� ������ ������ ������ �־����.
        //���� ���̴� ��������â�� �����鼭 ���ο�â�� ��������.
        //���ο� â�� �켱 �������� ������ â���� ��ü
    }
}