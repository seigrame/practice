using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class WayPointListViewPanel : MonoBehaviour
{
    //�̵��� ������ ������ŭ ������ ��ü�� ���� ����Ʈ 
    public List<GameObject> wayPointObjList = new List<GameObject>();
    public GameObject Pref;
    public Transform contents;
    public WayPointManager wayPointManager;

    public void ShowWayPointObj()
    {
        wayPointObjList.Clear();
        for (int i = 0; i < wayPointManager.wayPointList.Count; i++)
        {
            GameObject go = Instantiate(Pref, contents);           
            go.GetComponentsInChildren<TextMeshProUGUI>()[1].text = wayPointManager.wayPointList[i].lonLatText.ToString();
            go.GetComponentsInChildren<TextMeshProUGUI>()[2].text = wayPointManager.wayPointList[i].endMonth.ToString() + " - " + wayPointManager.wayPointList[i].endDay.ToString() + "   " + wayPointManager.wayPointList[i].endHour.ToString() + " : " + wayPointManager.wayPointList[i].endMinute.ToString();
            go.GetComponentsInChildren<TextMeshProUGUI>()[3].text = wayPointManager.wayPointList[i].startMonth.ToString() + " - " + wayPointManager.wayPointList[i].startDay.ToString() + "   " + wayPointManager.wayPointList[i].startHour.ToString() + " : " + wayPointManager.wayPointList[i].startMinute.ToString();
            go.GetComponentsInChildren<TextMeshProUGUI>()[4].text = wayPointManager.wayPointList[i].speed.ToString();
            go.GetComponentsInChildren<TextMeshProUGUI>()[5].text = wayPointManager.wayPointList[i].wayPointType.ToString(); //enum���� ����� �ٲ޿� ���� Ÿ�Կ� ���� ���� ������ �־������.
            go.GetComponentsInChildren<TextMeshProUGUI>()[6].text = wayPointManager.wayPointList[i].isCheckPoint?  "Ȯ����" : "-" ;
            wayPointObjList.Add(go);
        }
        for (int i = 0; i < wayPointObjList.Count; i++)
        {
            wayPointObjList[i].GetComponent<RectTransform>().sizeDelta = new Vector2(wayPointObjList[i].GetComponent<RectTransform>().sizeDelta.x, 30f);//Container���� Content�� ������ rect��ǥ�� �̻������� ������ ������Ų ��
            wayPointObjList[i].GetComponent<RectTransform>().localPosition = new Vector3(wayPointObjList[i].GetComponent<RectTransform>().localPosition.x, wayPointObjList[i].GetComponent<RectTransform>().localPosition.y, 0);
            wayPointObjList[i].GetComponentsInChildren<TextMeshProUGUI>()[0].text = (i + 1).ToString();
        }
    }

    public void DeleteObj()
    {
        WayPointObjectInfo[] items = contents.GetComponentsInChildren<WayPointObjectInfo>();
        foreach (WayPointObjectInfo item in items)
        {
            Destroy(item.gameObject);
        }
    }
}
