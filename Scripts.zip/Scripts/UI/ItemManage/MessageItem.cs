using UnityEngine;
using TMPro;
using Vtas;
using System.Collections.Generic;
using System.Text;

public class MessageItem : MonoBehaviour
{
    public SelectRole selectRole;
    ButtonManager buttonManager;
    MessageManager messageManager;
    NetworkManager networkManager;
    UIManager UImanager;
    public ReportTypeTab CategoryTab;
    public Priority reportPriority;
    public int index;


    List<OverlayIconData> icondata;
    //public GameObject damagedTargetPanelPref;
    public void OnEnable()
    {
        if (selectRole == null)
        {
            selectRole = FindObjectOfType<SelectRole>();
        }
        if (buttonManager == null)
        {
            buttonManager = FindObjectOfType<ButtonManager>();
        }
        if (messageManager == null)
        {
            messageManager = FindObjectOfType<MessageManager>();
        }
        if (networkManager == null)
        {
            networkManager = FindObjectOfType<NetworkManager>();
        }
        if (UImanager == null)
        {
            UImanager = FindObjectOfType<UIManager>();
        }
      
    }
    public enum ReportTypeTab : int
    {
        REPORT,
        FIRE_SUPPORT,
        COMMAND,
        OVERLAY,
    }

    public MessageState messageState;

    public MessageType messageType;
    public bool isOpen = false;
    public void OnOpenUI(int idx)//
    {
        index = idx;
        UImanager.CloseButton();

        switch (messageType)
        {
            case MessageType.FIND_ENEMY:
                FindEnemyData enemyData = (FindEnemyData)messageManager.msgList[idx];
                FindEnemyUI enemyUI = UImanager.centerPanel.findEnemyPanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        enemyUI.day.text = enemyData.day.ToString();
                        enemyUI.hour.text = enemyData.hour.ToString();
                        enemyUI.min.text = enemyData.min.ToString();
                        enemyUI.myPos.text = enemyData.myPosition;
                        enemyUI.targetPos.text = enemyData.targetPosition;
                        enemyUI.target1DD.value = (int)enemyData.targetType1;
                        enemyUI.target1Count.text = enemyData.target1Count.ToString();
                        enemyUI.target2DD.value = (int)enemyData.targetType2;
                        enemyUI.target2Count.text = enemyData.target2Count.ToString();
                        enemyUI.target3DD.value = (int)enemyData.targetType3;
                        enemyUI.target3Count.text = enemyData.target3Count.ToString();
                        enemyUI.postrueDD.value = (int)enemyData.targetPosture;
                        enemyUI.directionDD.value = (int)enemyData.targetDirection;
                        enemyUI.note.text = enemyData.note;
                        enemyData.isOpen = true;
                        if (enemyData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        UImanager.UnInteractableUI(UImanager.centerPanel.findEnemyPanel.gameObject);
                        SelectCurrentMessageIcon(i);
                    }             
                }
                UImanager.centerPanel.findEnemyPanel.gameObject.SetActive(true);         
                break;

            case MessageType.TRANSFER:
                TransferData transferData = (TransferData)messageManager.msgList[idx];
                TransferUI transferUI = UImanager.centerPanel.transferPanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        transferUI.position.GetComponent<TMP_InputField>().text = transferData.rescuePosition;
                        transferUI.patient.text = transferData.patient.ToString();
                        transferUI.stretcher.text = transferData.stretcher.ToString();
                        transferUI.priorityDD.value = (int)transferData.transferPriority;
                        transferUI.markDD.value = (int)transferData.mark;
                        transferUI.pollutionDD.value = (int)transferData.pollution;
                        transferUI.colorDD.value = (int)transferData.markColor;
                        transferUI.safetyDD.value = (int)transferData.areaSafetyLevel;
                        transferUI.nationalDD.value = (int)transferData.national;
                        transferUI.note.text = transferData.note;
                        transferData.isOpen = true;
                        if (transferData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        UImanager.UnInteractableUI(UImanager.centerPanel.transferPanel.gameObject);
                        SelectCurrentMessageIcon(i);
                    }                 
                }
                UImanager.centerPanel.transferPanel.gameObject.SetActive(true);
                break;

            case MessageType.CBRN_FIRST:
                CBRN_FirstData cbrnfirstData  = (CBRN_FirstData)messageManager.msgList[idx];
                CBRNFirstUI firstUI = UImanager.centerPanel.cbrnFirstPanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        firstUI.CBRNTypeDD.value = (int)cbrnfirstData .cbrnType;
                        firstUI.myPosition.text=cbrnfirstData .myPosition;
                        firstUI.Pos_do.text = cbrnfirstData .myRotation_do.ToString();
                        firstUI.Pos_Mil.text = cbrnfirstData .myRotation_mil.ToString();
                        firstUI.atkStartDay.text = cbrnfirstData .atkStartD.ToString();
                        firstUI.atkStartHour.text = cbrnfirstData .atkStartH.ToString();
                        firstUI.atkStartMin.text = cbrnfirstData .atkStartM.ToString();
                        firstUI.atkEndDay.text= cbrnfirstData .atkEndD.ToString();
                        firstUI.atkEndHour.text = cbrnfirstData .atkEndH.ToString();
                        firstUI.atkEndMin.text = cbrnfirstData .atkEndM.ToString();
                        firstUI.attackedPos.text = cbrnfirstData .attackedPosition;
                        firstUI.posSituationDD.value = (int)cbrnfirstData .situation;
                        firstUI.classificationsDD.value = (int)cbrnfirstData .classifications;
                        firstUI.propertyDD.value =(int) cbrnfirstData .property;
                        firstUI.kindsDD.value= (int) cbrnfirstData .kinds;
                        firstUI.explosionShapeDD.value = (int) cbrnfirstData .explosionShape;
                        firstUI.fireMethodDD.value = (int) cbrnfirstData .fireMethod;
                        firstUI.ammo.text = cbrnfirstData .NumberOfAmmunition.ToString();
                        firstUI.aircraft.text =cbrnfirstData .NumberOfAircraft.ToString();
                        firstUI.note.text = cbrnfirstData .note;
                        cbrnfirstData.isOpen = true;
                        if (cbrnfirstData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.cbrnFirstPanel.gameObject);
                        SelectCurrentMessageIcon(i);
                    }              
                }
                UImanager.centerPanel.cbrnFirstPanel.gameObject.SetActive(true);
                break;

            case MessageType.CBRN_SCOUT:
                CBRN_ScoutData cbrnScoutData  = (CBRN_ScoutData)messageManager.msgList[idx];
                CBRNScoutUI scoutUI = UImanager.centerPanel.cbrnScoutPanel;

                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        scoutUI.startDay.text = cbrnScoutData .startDay.ToString();
                        scoutUI.startHour.text = cbrnScoutData .startHour.ToString();
                        scoutUI.startMin.text = cbrnScoutData .startMin.ToString();
                        //scoutUI.classificationsDD.value = (int)cbrnScoutPacket.classifications;
                        //scoutUI.propertyDD.value = (int)cbrnScoutPacket.property;                      <=��ǥ ��ü�� �Ѱ��� �ۿ��������� �����ٸ� ��� 
                        //scoutUI.kindsDD.value = (int)cbrnScoutPacket.kinds;
                        //scoutUI.explosionShapeDD.value = (int)cbrnScoutPacket.explosionShape;
                        //scoutUI.radiationRate.text = cbrnScoutPacket.radiationRate.ToString();
                        //��ũ�� �信 ���� ���� //��ü�� �ۿ��� ������ ���� ������ ���� 
                        scoutUI.SpecimenList.Clear();
                        for (int k = 0; k < cbrnScoutData .scoutItems.Length; k++) //SpecimenList�� 0�ι���, �ϴ� ���Ž� SpecimenList�� �÷�����Ѵ�.
                        {
                            if (cbrnScoutData .scoutItems[k] != null)
                            {   //��ü ���� �� ����Ʈ�� ����
                                GameObject scoutItem = Instantiate(UImanager.centerPanel.cbrnScoutPanel.scoutPrefItem, UImanager.centerPanel.cbrnScoutPanel.scoutItemParent);
                                scoutItem.GetComponent<CBRNScoutItem>().myPos = cbrnScoutData.scoutItems[k].myPos;
                                scoutItem.GetComponent<CBRNScoutItem>().classifications = cbrnScoutData.scoutItems[k].classifications;
                                scoutItem.GetComponent<CBRNScoutItem>().property = cbrnScoutData.scoutItems[k].property;
                                scoutItem.GetComponent<CBRNScoutItem>().kinds = cbrnScoutData.scoutItems[k].kinds;
                                scoutItem.GetComponent<CBRNScoutItem>().explosionShape = cbrnScoutData.scoutItems[k].explosionShape;
                                scoutItem.GetComponent<CBRNScoutItem>().radiationRate = cbrnScoutData.scoutItems[k].radiationRate.ToString();
                                UImanager.centerPanel.cbrnScoutPanel.SpecimenList.Add(scoutItem.GetComponent<CBRNScoutItem>());//�����ؼ� ����Ʈ�� ����
                            }
                        }
                        scoutUI.note.text = cbrnScoutData .note;
                        cbrnScoutData.isOpen = true;
                        if (cbrnScoutData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.cbrnScoutPanel.gameObject);
                    }
                }
                UImanager.centerPanel.cbrnScoutPanel.gameObject.SetActive(true);
                break;

            case MessageType.MY_STATE:
                MyStateData myStateData  = (MyStateData)messageManager.msgList[idx];
                myStateUI statusUI = UImanager.centerPanel.myStatePanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        statusUI.year.text = myStateData .year.ToString();
                        statusUI.month.text = myStateData .month.ToString();
                        statusUI.day.text = myStateData .day.ToString();
                        statusUI.hour.text = myStateData .hour.ToString();
                        statusUI.minute.text = myStateData .minute.ToString();
                        statusUI.title.text = myStateData .title;
                        statusUI.EnemyPostureDD.value = (int)myStateData .enemyPosture;
                        statusUI.myPos.text = myStateData .myPosition;
                        statusUI.EnemyPostureLevelDD.value = (int)myStateData .enemyPostureLevel;
                        statusUI.LastOrderDD.value = (int)myStateData .lastOrder;
                        statusUI.leftCoord.text = myStateData .LeftCoord;
                        statusUI.rightCoord.text = myStateData .RightCoord;
                        statusUI.combat_p.text = myStateData .combat.ToString();
                        statusUI.death_p.text = myStateData .death.ToString();
                        statusUI.injury_p.text = myStateData .injury.ToString();
                        statusUI.ammo_h.text = myStateData .ammo_h.ToString();
                        statusUI.ammo_a.text = myStateData .ammo_a.ToString();
                        statusUI.ammo_c.text = myStateData .ammo_c.ToString();
                        statusUI.ammo_s.text = myStateData .ammo_s.ToString();
                        statusUI.ammo_m.text = myStateData .ammo_m.ToString();
                        statusUI.note.text = myStateData .note;

                        myStateData.isOpen = true;
                        if (myStateData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.myStatePanel.gameObject);
                    }
                }
                UImanager.centerPanel.myStatePanel.gameObject.SetActive(true);
                break;

            case MessageType.OBSTACLE:
                ObstacleData obstacleData  = (ObstacleData)messageManager.msgList[idx];
                ObstacleUI obstacleUI = UImanager.centerPanel.obstaclePanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        obstacleUI.year.text = obstacleData .year.ToString();
                        obstacleUI.month.text = obstacleData .month.ToString();
                        obstacleUI.day.text = obstacleData .day.ToString();
                        obstacleUI.hour.text =  obstacleData .hour.ToString();
                        obstacleUI.min.text = obstacleData .minute.ToString();
                        obstacleUI.obstaclePos.text = obstacleData .obtaclePosition;
                        obstacleUI.classifyEnemyDD.value = (int)obstacleData .classifyEnemies;
                        obstacleUI.shapeDD.value = (int)obstacleData .obstacleShape;
                        obstacleUI.numberOfObstacles.text = obstacleData .numberOfObstacle;
                        obstacleUI.controlNum.text = obstacleData .controlNumber;
                        obstacleUI.installUnit.text = obstacleData .installUnit;
                        switch (obstacleUI.shapeDD.value)
                        {
                            case 0:
                                obstacleUI.typeDD.value = (int)obstacleData .obstacleBarbedWireType;
                                break;
                            case 1:
                                obstacleUI.typeDD.value = (int)obstacleData .obstacleMineType;
                                break;
                            case 2:
                                obstacleUI.typeDD.value = (int)obstacleData .obstacleWallType;
                                break;
                            case 3:
                                obstacleUI.typeDD.value = (int)obstacleData .obstacleCategory;
                                break;
                        }
                        obstacleUI.width.text = obstacleData .width.ToString();
                        obstacleUI.length.text = obstacleData .length.ToString();
                        obstacleUI.note.text = obstacleData .note;

                        obstacleData.isOpen = true;
                        if (obstacleData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.obstaclePanel.gameObject);
                    }
                }
                UImanager.centerPanel.obstaclePanel.gameObject.SetActive(true);
                break;

            case MessageType.TARGET_DAMAGE:
                TargetDamageData DamageData  = (TargetDamageData)messageManager.msgList[idx];//i��° ��Ŷ ã��
                TargetDamageUI damageUI = UImanager.centerPanel.targetDamagePanel;//ui����
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        damageUI.targetDD.value = (int)DamageData .targetType;
                        damageUI.scale.text = DamageData .targetScale;
                        damageUI.position.text = DamageData .targetPos;
                        damageUI.meansDD.value = (int)DamageData .measnsOfAttack;
                        damageUI.result.text = DamageData .note;
                        DamageData.isOpen = true;
                        if (DamageData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.targetDamagePanel.gameObject);
                    }
                }
                UImanager.centerPanel.targetDamagePanel.gameObject.SetActive(true);
                break;

            case MessageType.NO_FORMAT:
                NoFormatData noformatData  = (NoFormatData)messageManager.msgList[idx];
                noformUI noformatUI = UImanager.centerPanel.noformPanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        noformatUI.year.text = noformatData .year.ToString();
                        noformatUI.month.text = noformatData .month.ToString();
                        noformatUI.day.text = noformatData .day.ToString();
                        noformatUI.hour.text = noformatData .hour.ToString();
                        noformatUI.min.text = noformatData .minute.ToString();
                        noformatUI.title.text = noformatData .title;

                        for (int k = 0; k < noformatUI.elements.Length;k++)
                        {
                            noformatUI.elements[k].text = noformatData .lines[k];
                        }

                        noformatData.isOpen = true;
                        if (noformatData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.noformPanel.gameObject);
                    }
                }
                UImanager.centerPanel.noformPanel.gameObject.SetActive(true);
                break;

            case MessageType.FIRE_SUPPORT:
                FireSupportData fireSupportData  = (FireSupportData)messageManager.msgList[idx];
                FireSupportUI fireSupportUI = UImanager.centerPanel.fireSupportPanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    {
                        fireSupportUI.missionTypeDD.value = (int)fireSupportData .missionType;
                        fireSupportUI.SquadSizeDD.value = (int)fireSupportData .squadSize;
                        fireSupportUI.targetPos.text = fireSupportData .targetPos;
                        fireSupportUI.plannedTarget.text = fireSupportData .plannedTarget;
                        fireSupportUI.targetTypeDD.value = (int)fireSupportData .targetType;
                        fireSupportUI.targetStateDD.value = (int)fireSupportData .targetActiveState;
                        fireSupportUI.ScaleSize.text = fireSupportData .numberOfScale.ToString();
                        fireSupportUI.TargetScaleDD.value = (int)fireSupportData .targetScale;
                        fireSupportUI.mixedTargetFormDD.value = (int)fireSupportData .mixedTargetType;
                        fireSupportUI.ShapeDD.value = (int)fireSupportData .shape;
                        fireSupportUI.size1.text = fireSupportData .size1.ToString();
                        fireSupportUI.size2.text = fireSupportData .size2.ToString();
                        fireSupportUI.rad.text = fireSupportData .rad.ToString();
                        fireSupportUI.note.text = fireSupportData .note;
                        fireSupportUI.atkMethod.text = fireSupportData .atkMethod;
                        fireSupportUI.ctrlMethod.text = fireSupportData .ctrlMethod;

                        fireSupportData.isOpen = true;
                        if (fireSupportData.isOpen)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.fireSupportPanel.gameObject);
                    }
                }
                UImanager.centerPanel.fireSupportPanel.gameObject.SetActive(true);
                break;

            case MessageType.COMMAND:
                CommandData commandData  = (CommandData)messageManager.msgList[idx];
                CommandPanelUI commandPanelUI = UImanager.centerPanel.commandPanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    { //������ �Է¹޴´�.
                        commandPanelUI.title.text = commandData .title;
                        if (commandData.marginalNoteInfo != null) commandPanelUI.Overlay.text = networkManager.checkData.missionName;
                        else commandPanelUI.Overlay.text = "";

                        for (int j = 0; j < commandPanelUI.textList.Count; j++)
                        {
                            commandPanelUI.textList[i].text = commandData .lines[j];
                        }
                        commandPanelUI.Job_PositionDD.value = (int)commandData .job_Position;
                        commandPanelUI.RankDD.value = (int)commandData .rank;
                        commandPanelUI.userName.text = commandData .userName;

                        commandData.isOpen = true;
                        if (buttonManager.prevButtonState == BottomButtonState._3RD_PRIORITY_ALARM)
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        }
                        else
                        {
                            GetComponentsInChildren<TextMeshProUGUI>()[6].text = "����";
                        }
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.commandPanel.gameObject);
                    }
                }
                UImanager.centerPanel.commandPanel.gameObject.SetActive(true);
                break;
            case MessageType.OVERLAY:
                MarginalNoteData marginalnoteData = (MarginalNoteData)messageManager.msgList[idx];
                MarginalNoteUI marginalNotePanelUI = UImanager.centerPanel.marginalNotePanel;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (idx == messageManager.msgList[i].index)//������ ��Ŷ�� �ε����� ���� ���ӿ�����Ʈ�� ���� �ε����� ���ؼ� ã��
                    { //������ �Է¹޴´�.
                        marginalNotePanelUI.SecretLvl = marginalnoteData.secretLevel;
                        marginalNotePanelUI.operationName.text = marginalnoteData.missionName;
                        marginalNotePanelUI.operationObject.text = marginalnoteData.missionTarget;
                        marginalNotePanelUI.jobPosition.text = marginalnoteData.jobPosition;
                        marginalNotePanelUI.platoon.text = marginalnoteData.platoonText;
                        marginalNotePanelUI.company.text = marginalnoteData.companyText;
                        marginalNotePanelUI.battalion.text = marginalnoteData.battalionText;
                        marginalNotePanelUI.userName.text = marginalnoteData.userName;
                        marginalNotePanelUI.date.text = marginalnoteData.date;
                        marginalNotePanelUI.note.text = marginalnoteData.note;
                        //marginalNotePanelUI.relevantReport.text = marginalnoteData.commandData.title;
                        for (int j = 0; j < marginalnoteData.overlayIconArr.Length; j++)//
                        {
                            if (marginalnoteData.overlayIconArr[i] != null)
                                icondata.Add(marginalnoteData.overlayIconArr[i]);

                            //������ ������ �׷�����
                        }
                        if (marginalnoteData.isOpen)
                            GetComponentsInChildren<TextMeshProUGUI>()[5].text = "����";
                        //���
                        UImanager.UnInteractableUI(UImanager.centerPanel.commandPanel.gameObject);
                    }
                }
                UImanager.centerPanel.marginalNotePanel.gameObject.SetActive(true);
                break;
            default:
                break;
        }
        UImanager.nonMsgPanel.alarmPanel.ReceiveReportCheck();
        if (buttonManager.prevButtonState == BottomButtonState._1ST_PRIORITY_ALARM || buttonManager.prevButtonState == BottomButtonState._2ND_PRIORITY_ALARM || 
            buttonManager.prevButtonState == BottomButtonState._3RD_PRIORITY_ALARM || buttonManager.prevButtonState == BottomButtonState._4TH_PRIORITY_ALARM) //�溸��ư���� ui�� �� ���̸�
        {
            buttonManager.currentButtonState = BottomButtonState.MESSAGE_RECV_OPEN;
        }
        else
        {
            buttonManager.currentButtonState = BottomButtonState.MESSAGE_SEND;
        }       
        buttonManager.ChangeButton();

    }
    //
    private void SelectCurrentMessageIcon(int i)
    {
        for (int j = 0; j < UImanager.nonMsgPanel.targetAssignmentPanel.msgSymbolList.Count; j++)
        {
            if (messageManager.msgList[i].index == UImanager.nonMsgPanel.targetAssignmentPanel.msgSymbolList[j].GetComponent<IconInfo>().index)
            {
                UImanager.lastSymbol = UImanager.nonMsgPanel.targetAssignmentPanel.msgSymbolList[j].gameObject;
            }
        }
    }
    //���� ������ UI ������ �Ұ����ϰ� ��� ��� 
}
