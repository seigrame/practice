using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class newMessageUI : MonoBehaviour
{
    /// <summary>
    /// 0. ���߰�, 1. �ļ�  2.ȭ���� ����, 3 ȭ���� ����, 4.����, 5.��ֹ�, 6.ǥ������, 7.�������, 8.����, 9.ȭ������, 10.����, 11.������ 
    /// </summary>
    public Toggle[] toggles;
    UIManager UImanager;
    SelectRole selectRole;
    private void Awake()
    {
        UImanager = FindObjectOfType<UIManager>();
        toggles = UImanager.centerPanel.msgTypeSelectToggle.transform.GetComponentsInChildren<Toggle>();
        selectRole = FindObjectOfType<SelectRole>();
    }

    private void OnEnable()
    {   //�Ҵ���ϰ�� ���ɰ� ������ �ɼ��� �������� ����
        StartCoroutine(toggleValueChange());
        toggles[0].Select();
        if (selectRole.setRole == SelectRole.SELECT_ROLE.PLATOON_MEMBER)
        {
            toggles[10].gameObject.SetActive(false);
            toggles[11].gameObject.SetActive(false);
        }
    }
    private void OnDisable()
    {
        StopCoroutine(toggleValueChange());
    }

    IEnumerator toggleValueChange()
    {
        while (true)
        {         
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                if (obj.name == "SpyReport")
                {
                    toggles[0].isOn = true;
                }
                if (obj.name == "TransferReport")
                {
                    toggles[1].isOn = true;
                }
                else if (obj.name == "FirstReport")
                {
                    toggles[2].isOn = true;
                }
                else if (obj.name == "ScoutReport")
                {
                    toggles[3].isOn = true;
                }
                else if (obj.name == "StateReport")
                {
                    toggles[4].isOn = true;
                }
                else if (obj.name == "ObstacleReport")
                {
                    toggles[5].isOn = true;
                }
                else if (obj.name == "TargetDamageReport")
                {
                    toggles[6].isOn = true;
                }
                else if (obj.name == "WeatherReport")
                {
                    toggles[7].isOn = true;
                }
                else if (obj.name == "NoFormReport")
                {
                    toggles[8].isOn = true;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
}
