using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
public class FindEnemyUI : MonoBehaviour
{
    public TMP_InputField day, hour, min, myPos, targetPos, target1Count, target2Count, target3Count, note;
    public TMP_Dropdown target1DD, target2DD, target3DD,postrueDD,directionDD;
    //ǥ�� ����
    List<string> targetType = new List<string> { "����", "�尩��","����","Ʈ��","����������","�װ���","���","����" };
    //ǥ�� �¼�
    List<string> targetPosture = new List<string> { "�⵿", "���", "����","����","�޽�" };
    //ǥ�� ����
    List<string> targetDirection = new List<string> { "�ϼ�", "��", "�ϵ�", "��", "��", "����", "��", "����" };

    DateTime dateTime;

    private void Start()
    {
        ClearDropdownList();
        AddDropdownList();
        this.gameObject.SetActive(false);
    }
    private void ClearDropdownList()
    {
        target1DD.ClearOptions();
        target2DD.ClearOptions();
        target3DD.ClearOptions();
        postrueDD.ClearOptions();
        directionDD.ClearOptions();
    }
    private void AddDropdownList()
    {
        target1DD.AddOptions(targetType);
        target2DD.AddOptions(targetType);
        target3DD.AddOptions(targetType);
        postrueDD.AddOptions(targetPosture);
        directionDD.AddOptions(targetDirection);
    }

    public void OnEnable()
    {
        if (myPos.interactable == true)
        {
            dateTime = DateTime.Now;
            day.text = dateTime.Day.ToString();
            hour.text = dateTime.Hour.ToString();
            min.text = dateTime.Minute.ToString();
            if (true)
            {
                myPos.text = MyInfo.instance.latlonText;
            }

            target1Count.text = "0";
            target2Count.text = "0";
            target3Count.text = "0";
        }
    }
    private void OnDisable()
    {
        UIManager.InteractableUI(this.gameObject);
    }
}
