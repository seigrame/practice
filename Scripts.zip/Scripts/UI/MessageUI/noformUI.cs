using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
public class noformUI : MonoBehaviour
{
    [SerializeField] GameObject textArea;
    public TMP_InputField title, year, month, day, hour, min;
    public TMP_InputField[] elements = new TMP_InputField[7];

    [SerializeField] TMP_InputField currentElement;

    DateTime dateTime = DateTime.Now;
    public int curPos;
    // Start is called before the first frame update
    void Awake()
    {
        elements = textArea.GetComponentsInChildren<TMP_InputField>();
        this.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        //Ŭ���� ��ǲ�ʵ��� ���� �޴� ������ �ʿ���

        //����Ű�� ������ �����ٷ�
        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter)) // 
        {
            curPos++;           
            //���������� �Ѿ�� ������ �ٿ� ��Ŀ��
            if (curPos > elements.Length -1)
            {
                curPos = elements.Length-1;
            }
            SelectInputField();
        }
        //���鿡�� �齺���̽��� ������ ���� �ٷ�
        else if (Input.GetKeyDown(KeyCode.Backspace))
        {
            if (currentElement.GetComponent<TMP_InputField>().text.Length ==0)
            {
                curPos--;
                //ù�� �������� ���ư��� ù �ٿ� ��Ŀ��
                if (curPos < -1)
                {
                    curPos = 0;
                }
                SelectInputField();
            } 
        }
    }

    void SelectInputField()
    {
        switch (curPos)
        {
            case 0:
                currentElement = elements[0];
                elements[0].Select();
                break;
            case 1:
                currentElement = elements[1];
                elements[1].Select();
                break;
            case 2:
                currentElement = elements[2];
                elements[2].Select();
                break;
            case 3:
                currentElement = elements[3];
                elements[3].Select();
                break;
            case 4:
                currentElement = elements[4];
                elements[4].Select();
                break;
            case 5:
                currentElement = elements[5];
                elements[5].Select();
                break;
            case 6:
                currentElement = elements[6];
                elements[6].Select();               
                break;
        }
    }

    private void OnEnable()
    {
        curPos = 0;
        SelectInputField();
        year.text = dateTime.Year.ToString();
        month.text = dateTime.Month.ToString();
        day.text = dateTime.Day.ToString();
        hour.text = dateTime.Hour.ToString();
        min.text = dateTime.Minute.ToString();
    }

    private void OnDisable()
    {
        for (int i = 0; i < elements.Length; i++)
        {
            elements[i].text = "";
        }
        UIManager.InteractableUI(this.gameObject);
    }
}
