using System.Collections;
using Vtas;
using UnityEngine;
using TMPro;
using System;
using UnityEngine.UI;
public class MarginalNoteUI : MonoBehaviour
{
    public TMP_InputField operationName, operationObject, jobPosition, platoon, company, battalion, userName, date, note, relevantReport;
    DateTime datetime = DateTime.Now;
    public SecretLevel SecretLvl;
    private void OnEnable()
    {
        date.text =  datetime.Year.ToString() + "�� "+ datetime.Month.ToString() + "�� "+ datetime.Day.ToString() + "�� "+ datetime.Hour.ToString() + " : "+ datetime.Minute.ToString();

        toggles = this.gameObject.transform.Find("Contents").transform.Find("SecretRankToggleGroup").GetComponentsInChildren<Toggle>();
        StartCoroutine(toggleValueChange());
        toggles[0].Select();
    }

    public Toggle[] toggles;

    private void OnDisable()
    {
        StopCoroutine(toggleValueChange());
    }
    IEnumerator toggleValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                if (obj.name == "III")
                {
                    toggles[0].isOn = true;
                    SecretLvl = SecretLevel.III;
                }
                else if (obj.name == "confidentiality")
                {
                    toggles[1].isOn = true;
                    SecretLvl = SecretLevel.CONFIDENTIALITY;
                }
                else if (obj.name == "Normal")
                {
                    toggles[1].isOn = true;
                    SecretLvl = SecretLevel.NORMAL;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
}
