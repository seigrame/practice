using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Vtas;

public class WayPointUI : MonoBehaviour
{
    public ToggleGroup controlPointToggleGroup;
    public Toggle[] controlPointToggles;
    public TMP_InputField PointPos, arrivalMon, arrivalDay, arrivalHour, arrivalMin, departureMon, departureDay, departureHour, departureMin, speed;
    public Image bg;
    public WayPointType pointType;
  
    // Start is called before the first frame update
    void Start()
    {
        SelectWayPointTypeToggle();
    }
    private void OnEnable()
    {
        StartCoroutine(toggleValueChange());
        if (arrivalMon.text =="")       arrivalMon.text = "0";
        if (arrivalDay.text == "")      arrivalDay.text = "0";
        if (arrivalHour.text == "")     arrivalHour.text = "0";
        if (arrivalMin.text == "")      arrivalMin.text = "0";
        if (departureMon.text =="")     departureMon.text = "0";
        if (departureDay.text =="")     departureDay.text = "0";
        if (departureHour.text =="")    departureHour.text = "0";
        if (departureMin.text =="")     departureMin.text = "0";
        if (speed.text =="")            speed.text = "0";
    }
    private void OnDisable()
    {
        StopCoroutine(toggleValueChange());
    }
    //Ȯ������ ��쿡�� �⺻���� �ְ�, 
    public void SelectWayPointTypeToggle()
    {
        IEnumerable<Toggle> toggles = controlPointToggleGroup.ActiveToggles();

        foreach (Toggle item in toggles)
        {
            if (item.name == "CheckToggle")
            {
                bg.color = Color.red;
                pointType = WayPointType.CHECK_POINT;
            }
            else if (item.name == "StartToggle")
            {
                bg.color = Color.black;
                pointType = WayPointType.START_POINT;
            }
            else if (item.name == "ReleaseToggle")
            {
                bg.color = Color.green;
                pointType = WayPointType.RELEASE_POINT;
            }
            else if (item.name == "NoneToggle")
            {
                bg.color = Color.gray;
                pointType = WayPointType.ROUTE_POINT;
            }
        }
    }

    IEnumerator toggleValueChange()
    {
        WaitForSeconds wfs = new WaitForSeconds(.2f);
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                if (obj.name == "CheckToggle")      controlPointToggles[0].isOn = true;
                if (obj.name == "StartToggle")      controlPointToggles[1].isOn = true;
                if (obj.name == "ReleaseToggle")    controlPointToggles[2].isOn = true;
                if (obj.name == "NoneToggle")       controlPointToggles[3].isOn = true;
            }
            yield return wfs;
        }
    }
}
