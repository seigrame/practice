using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vtas;
using TMPro;

public class CommandPanelUI : MonoBehaviour
{
    public TMP_InputField title, Overlay, userName; //Overlay ������
    public TMP_Dropdown Job_PositionDD, RankDD;
    //public CommandUIElements currentPanel;
    //[SerializeField] CommandUIElements defaultPanel;
    //public CommandReportType commandReportType;
    public List<TMP_InputField> textList;
    public void Awake()
    {
        //currentPanel = defaultPanel;
        this.gameObject.SetActive(false);
    }
    public void ClickButton()
    {
       title.Select(); //����� �� ��ư�� Ŭ���ϸ� ����â�� ��Ŀ���� ����
    }

    private void OnDisable()
    {
        UIManager.InteractableUI(this.gameObject);
    }
    List<string> Job_Position = new List<string> { "�ߴ���", "�����", "������" };

    List<string> Rank = new List<string> { "����", "�߷�", "���" };

    // Start is called before the first frame update
    private void Start()
    {
        ClearDropdownList();
        addDropdownList();
    }

    public void addDropdownList()
    {
        Job_PositionDD.AddOptions(Job_Position);
        RankDD.AddOptions(Rank);
    }

    public void ClearDropdownList()
    {
        Job_PositionDD.ClearOptions();
        RankDD.ClearOptions();
    }
}
