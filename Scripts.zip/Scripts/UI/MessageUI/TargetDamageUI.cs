using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;

public class TargetDamageUI : MonoBehaviour
{
    public TMP_Dropdown targetDD, meansDD;
    public TMP_InputField scale, position, result;
    //ǥ������
    public enum targetType
    {
        ����,
        �尩��,
        ����,
        Ʈ��,
        ��������������,
        �װ���,
        ���,
        ����,
    };
    //Ÿ�ݼ���
    public enum measnsOfAttack
    {
        �����װ�,
        ����,
    }

    private void AddDropdownList()
    {
        string[] targetTypeEnumName = Enum.GetNames(typeof(targetType));
        List<string> targetNames = new List<string>(targetTypeEnumName);
        targetDD.AddOptions(targetNames);

        string[] measnsOfAttackEnumName = Enum.GetNames(typeof(measnsOfAttack));
        List<string> measnsNames = new List<string>(measnsOfAttackEnumName);
        meansDD.AddOptions(measnsNames);
    }
    private void Start()
    {
        ClearDropdownList();
        AddDropdownList();
        this.gameObject.SetActive(false);
    }

    private void ClearDropdownList()
    {
        targetDD.ClearOptions();
        meansDD.ClearOptions();
    }
    private void OnDisable()
    {
        UIManager.InteractableUI(this.gameObject);
    }
}
