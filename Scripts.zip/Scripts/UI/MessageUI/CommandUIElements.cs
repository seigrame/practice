using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Vtas;
public class CommandUIElements : MonoBehaviour
{

    public TMP_InputField[] textContents = new TMP_InputField[7];
    public GameObject textArea;

    private void Start()
    {
        textContents = textArea.GetComponentsInChildren<TMP_InputField>();
    }
}
