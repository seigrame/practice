using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Vtas;

public class WeatherUI : MonoBehaviour
{
    public TMP_InputField month, day, currentWeather, startH, startM, endH, endM, moonriseH, moonriseM, moonsetH, moonsetM, lowtemper, hightemper, windSpeed, precipPer, precipAmount, note;
    public TMP_Dropdown moonlightDD, windSpeedDD;

    public TargetDirection windDir;

    List<string> moonlightOptions = new List<string> { "������", "1/4", "1/2", "3/4", "����" };

    List<string> windDirections = new List<string> { "�ϼ�","��", "�ϵ�", "��","��", "����", "��","����" };
    private void ClearDropdownList()
    {
        windSpeedDD.ClearOptions();
        moonlightDD.ClearOptions();
       
    }

    private void AddDropdownList()
    {
        windSpeedDD.AddOptions(windDirections);
        moonlightDD.AddOptions(moonlightOptions);
    }
}
