using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class MapSettingUI : MonoBehaviour
{    
    [SerializeField] UIManager buttonDefine;
    public ToggleGroup mapTileToggle, ScaleToggle, magnificationToggle;
    public ToggleGroup coordToggle, gridToggle, subGridToggle , mapMoveToggle;

    [SerializeField] TextMeshProUGUI scaleText , magnificationText;
    public ButtonManager buttonManager;
    public Toggle[] toggleArray;
    public TMP_InputField coordInputField;

    public FollowCamera followCamera;

    public void MapMoveToggle()
    {
        IEnumerable<Toggle> toggles = mapMoveToggle.ActiveToggles();
        foreach (Toggle item in toggles)
        {
            if (item.name == "myPosition")
            {
                followCamera.SetFocusOwnship();
            }
            else if (item.name == "Coord")
            {
                followCamera.SetFocusCoordinate();
            }
        }
    }

    //�����߽�

    public void MapSettings()
    {
        MapToggle();
        SelectScaleToggle();
        SelectMagnificationToggle();       
    }
    void MapToggle()
    {
        IEnumerable<Toggle> toggles = mapTileToggle.ActiveToggles();
        foreach (Toggle item in toggles)
        {
            if (item.name == "OSM")
            {
                VtasMapManager.Instance.SetMapType(TILE_TYPE.OSM);
            }
            else if (item.name == "Normal")
            {
                VtasMapManager.Instance.SetMapType(TILE_TYPE.NONE);
            }
        }
    }

    void SelectScaleToggle()
    {
        IEnumerable<Toggle> toggles = ScaleToggle.ActiveToggles();

        foreach (Toggle item in toggles)
        {
            if (item.name == "50000")
            {
                VtasMapManager.Instance.SetMapScale(MAP_SCALE.S5M);
                scaleText.text = "5��";
            }
            else if (item.name == "100000")
            {
                VtasMapManager.Instance.SetMapScale(MAP_SCALE.S10M);
                scaleText.text = "10��";
            }
            else if (item.name == "250000")
            {
                VtasMapManager.Instance.SetMapScale(MAP_SCALE.S25M);
                scaleText.text = "25��";
            }
            else if (item.name == "500000")
            {
                VtasMapManager.Instance.SetMapScale(MAP_SCALE.S50M);
                scaleText.text = "50��";
            }
            else if(item.name == "1000000")
            {
                VtasMapManager.Instance.SetMapScale(MAP_SCALE.S100M);
                scaleText.text = "100��";
            }      
        }
    }

    void SelectMagnificationToggle()
    {
        //SetDefaultValuesOfMapLevel();
        IEnumerable<Toggle> toggles = magnificationToggle.ActiveToggles();

        foreach (Toggle item in toggles)
        {
            if (item.name == "25")
            {
                VtasMapManager.Instance.SetMapMagnification(MAP_MAGNIFICATION.M25);                
                magnificationText.text = "25";
            }
            else if (item.name == "50")
            {
                VtasMapManager.Instance.SetMapMagnification(MAP_MAGNIFICATION.M50);
                magnificationText.text = "50";
            }
            else if (item.name == "100")
            {
                VtasMapManager.Instance.SetMapMagnification(MAP_MAGNIFICATION.M100);
                magnificationText.text = "100";
            }          
            else if (item.name == "150")
            {
                VtasMapManager.Instance.SetMapMagnification(MAP_MAGNIFICATION.M150);
                magnificationText.text = "150";
            }
            else if (item.name == "200")
            {
                VtasMapManager.Instance.SetMapMagnification(MAP_MAGNIFICATION.M200);
                magnificationText.text = "200";
            }
            else if (item.name == "300")
            {
                VtasMapManager.Instance.SetMapMagnification(MAP_MAGNIFICATION.M300);
                magnificationText.text = "300";
            }
            else if (item.name == "400")
            {
                VtasMapManager.Instance.SetMapMagnification(MAP_MAGNIFICATION.M400);
                magnificationText.text = "400";
            }
        }
    }

    public void MapCoordSettings()
    {
        SelectCoordToggle();
        SelectGridToggle();
        SelectSubGridToggle();
    }
    void SelectCoordToggle()
    {
        //��ǥ��ǥ�� ����
        IEnumerable<Toggle> toggles = coordToggle.ActiveToggles();

        foreach (Toggle item in toggles)
        {
            if (item.name == "MGRS")
            {
                VtasMapManager.Instance.SetMapCoord(MAP_COORD.MGRS);
            }
            else if (item.name == "UTM")
            {
                VtasMapManager.Instance.SetMapCoord(MAP_COORD.UTM);
            }
            else if (item.name == "LonLat")
            {
                VtasMapManager.Instance.SetMapCoord(MAP_COORD.WGS84);
            }            
        }
    }
    void SelectGridToggle()
    {
        //�׸���������
        IEnumerable<Toggle> toggles = gridToggle.ActiveToggles();

        foreach (Toggle item in toggles)
        {
            if (item.name == "none")
            {
                VtasMapManager.Instance.SetMapGrid(MAP_GRID.NONE);
            }
            else if (item.name == "1000m")
            {
                VtasMapManager.Instance.SetMapGrid(MAP_GRID.M1000);
            }
            else if (item.name == "10000m")
            {
                VtasMapManager.Instance.SetMapGrid(MAP_GRID.M10000);
            }
        }
    }
    void SelectSubGridToggle()
    {
        //�������ڼ� �������
        IEnumerable<Toggle> toggles = subGridToggle.ActiveToggles();

        foreach (Toggle item in toggles)
        {
            if (item.name == "none")
            {
                VtasMapManager.Instance.SetMapSubGrid(MAP_SUBGRID.NONE);
            }
            else if (item.name == "1/2")
            {
                VtasMapManager.Instance.SetMapSubGrid(MAP_SUBGRID.D2);
            }
            else if (item.name == "1/5")
            {
                VtasMapManager.Instance.SetMapSubGrid(MAP_SUBGRID.D5);
            }
            else if (item.name == "1/10")
            {
                VtasMapManager.Instance.SetMapSubGrid(MAP_SUBGRID.D10);
            }
        }
    }

    void OnEnable()
    {
        toggleArray = this.gameObject.transform.Find("BackGroundTab").transform.Find("Contents").GetComponentsInChildren<Toggle>();
        StartCoroutine(toggleValueChange());
    }
    private void OnDisable()
    {
        StopCoroutine(toggleValueChange());
    }

    IEnumerator toggleValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                switch (obj.name)
                {
                    case "Normal":
                        toggleArray[0].isOn = true;
                        break;
                    case "OSM":
                        toggleArray[1].isOn = true;
                        break;
                    case "50000":
                        toggleArray[2].isOn = true;
                        break;
                    case "100000":
                        toggleArray[3].isOn = true;
                        break;
                    case "250000":
                        toggleArray[4].isOn = true;
                        break;
                    case "500000":
                        toggleArray[5].isOn = true;
                        break;
                    case "1000000":
                        toggleArray[6].isOn = true;
                        break;
                    case "25":
                        toggleArray[7].isOn = true;
                        break;
                    case "50":
                        toggleArray[8].isOn = true;
                        break;
                    case "100":
                        toggleArray[9].isOn = true;
                        break;
                    case "150":
                        toggleArray[10].isOn = true;
                        break;
                    case "200":
                        toggleArray[11].isOn = true;
                        break;
                    case "300":
                        toggleArray[12].isOn = true;
                        break;
                    case "400":
                        toggleArray[13].isOn = true;
                        break;
                }
            }
            yield return new WaitForSeconds(.2f);
        }

    }

    //���� �� ����
    public void MapBackground()
    {
        buttonManager.currentButtonState = BottomButtonState.MAP;
        buttonManager.ChangeButton();
    }
    public void MapCoord()
    {
        buttonManager.currentButtonState = BottomButtonState.MAP_COORD;
        buttonManager.ChangeButton();
    }
    public void MapFeature()
    {
        buttonManager.currentButtonState = BottomButtonState.MAP_FEATURE;
        buttonManager.ChangeButton();
    }
    public void MapMove()
    {
        buttonManager.currentButtonState = BottomButtonState.MAP_MOVE;
        buttonManager.ChangeButton();
    }
}
