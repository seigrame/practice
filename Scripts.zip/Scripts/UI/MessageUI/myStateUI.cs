using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
public class myStateUI : MonoBehaviour
{
    public TMP_InputField year,month,day,hour,minute, title,myPos, leftCoord,rightCoord, combat_p, death_p,injury_p, ammo_h, ammo_a, ammo_c, ammo_s, ammo_m,note;
    public TMP_Dropdown EnemyPostureDD, EnemyPostureLevelDD, LastOrderDD;
    public Image oilFilledIamge;

    List<string> EnemyPosture = new List<string> { "����", "�������", "���" ,"����","����", "����"};

    List<string> EnemyPostureLevel = new List<string> { "��", "��", "��" };

    List<string> LastOrder = new List<string> { "�Һ�", "����", "����" ,"����" ,"����", "ö��" };

    DateTime dateTime = DateTime.Now;

    private void Start()
    {
        ClearDropdownList();
        addDropdownList();
        this.gameObject.SetActive(false);
    }
    void addDropdownList()
    {
        EnemyPostureDD.AddOptions(EnemyPosture);
        EnemyPostureLevelDD.AddOptions(EnemyPostureLevel);
        LastOrderDD.AddOptions(LastOrder);
    }

    void ClearDropdownList()
    {
        EnemyPostureDD.ClearOptions();
        EnemyPostureLevelDD.ClearOptions();
        LastOrderDD.ClearOptions();
    }

    void OnEnable()
    {
        if (myPos.interactable)
        {
            year.text = dateTime.Year.ToString();
            month.text = dateTime.Month.ToString();
            day.text = dateTime.Day.ToString();
            hour.text = dateTime.Hour.ToString();
            minute.text = dateTime.Minute.ToString();

            toggles = this.gameObject.transform.Find("Contents").transform.Find("CombatAreaInfoBox").GetComponentsInChildren<Toggle>();
            StartCoroutine(toggleValueChange());
            toggles[0].Select();

            if (MyInfo.instance.latlonText != null)
            {
                myPos.text = MyInfo.instance.latlonText;
            }
            combat_p.text = "0";
            death_p.text = "0";
            injury_p.text = "0";
            ammo_h.text = "0";
            ammo_a.text = "0";
            ammo_c.text = "0";
            ammo_s.text = "0";
            ammo_m.text = "0";
        }     
    }

    public Toggle[] toggles;

    private void OnDisable()
    {
        StopCoroutine(toggleValueChange());
        UIManager.InteractableUI(this.gameObject);
    }

    IEnumerator toggleValueChange()
    {
        while (true)
        {
            GameObject obj = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;//���� ���õ� ���ӿ�����Ʈ
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject != null)
            {
                if (obj.name == "LeftToggle")
                {
                    toggles[0].isOn = true;
                }
                if (obj.name == "RightToggle")
                {
                    toggles[1].isOn = true;
                }
            }
            yield return new WaitForSeconds(.2f);
        }
    }
}
