using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.Runtime.InteropServices;
using System;

namespace Vtas
{
    public class NetworkManager : MonoBehaviour
    {
        public static readonly int MAX_PACKET_SIZE = 8192;
        //singleton
        public static NetworkManager instance;
        void Awake() => instance = this;

        public IPAddress myIP;

        //1. 상위체계모의일 경우 서버만 연다
        //2. 하위체계모의(전차장)일 경우 서버를 열고 클라이언트로 상위모의체계로 접속한다.
        //3. 하위체계모의(사수,조종수)일 경우 클라이언트로 하위체계모의(전차장)에게 접속한다.

        //
        public TCPServer tcpServer;
        public UDPServer udpServer;

        //상위체계모의와 연결
        //혹은 조종수, 포수일경우는 
        public TCPClient tcpClient;
        public UDPClient udpClient;

        UIManager uiManager;
        WayPointManager wayPointManager;
        ButtonManager buttonManager;
        ContentsItemManager itemManager;
        public List<Packet> packetList = new List<Packet> { };        //복사 및 주고받은 패킷의 갯수와 그 정보, 열람버튼을 눌렀을 때, 상단 리스트와 이 리스트의 인덱스를 비교하고, 일치하면 이 패킷의 정보를 ui에 넣음 
        MessageManager messageManager;
        public MARGINAL_NOTE checkData;
        // Start is called before the first frame update
        void Start()
        {
            myIP = GetMyIP();
            messageManager = FindObjectOfType<MessageManager>(); //추가한 부분
            uiManager = FindObjectOfType<UIManager>();
            wayPointManager = FindObjectOfType<WayPointManager>();
            buttonManager = FindObjectOfType<ButtonManager>();
            itemManager = FindObjectOfType<ContentsItemManager>();
        }

        // Update is called once per frame
        void Update()
        {   //메인쓰레드에서 송수신메세지를 처리한다
            //송신데이터 처리
            if (udpServer.SendMessageStack != null)
            {
                if (udpServer.SendMessageStack.Count > 0)
                {
                    PACKET_TYPE pType = udpServer.SendMessageStack.Pop();
                    switch (pType)
                    {
                        case PACKET_TYPE.U2L_MOVING_OBJECT:
                            udpServer.SendDataMovingObjectInfo();
                            break;
                    }
                    udpServer.SendMessageStack.Clear();
                }
            }

            //체계모의/전차장이 서버일때 메세지 수신
            if (udpServer.ReceiveMessageStack != null)
            {
                if (udpServer.ReceiveMessageStack.Count > 0)
                {   //수신데이터 처리
                    Packet packet = udpServer.ReceiveMessageStack.Pop();
                    udpServer.ProcessReceivePacket(packet);
                    udpServer.ReceiveMessageStack.Clear();
                }
            }
            if (uiManager.selectRole.setRole == SelectRole.SELECT_ROLE.TANK_COMMANDER || uiManager.selectRole.setRole == SelectRole.SELECT_ROLE.PLATOON_MEMBER)
            {
                if (udpClient.ReceiveMessageStack != null)
                {   //전차장이 클라이언트 일때 메세지 수신
                    if (udpClient.ReceiveMessageStack.Count > 0)//전차장으로부터 받은 메세지 스택
                    {
                        Packet clientpacket = udpClient.ReceiveMessageStack.Pop();
                        udpClient.ProcessReceivePacket(clientpacket);
                        udpClient.ReceiveMessageStack.Clear();
                    }
                }
            }        
        }

        public IPAddress GetMyIP()
        {
            IPHostEntry IPHost = Dns.GetHostEntry(Dns.GetHostName());
            for (int i = 0; i < IPHost.AddressList.Length; i++)
            {
                IPAddress IPAddress = IPHost.AddressList[i];
                if (IPAddress.AddressFamily == AddressFamily.InterNetwork)
                {
                    return IPAddress;
                }
            }
            return null;
        }

        #region 추가한 부분

        //메세지를 보낼 때
        public void DataToPacket(MsgData msgInfo) //데이터를 패킷으로 메세지 데이터로부터 패킷정보를 담기만 하면된다.
        {
            #region 일반전문 영역
            if (msgInfo is FindEnemyData)
            {
                FIND_ENEMY findEnemyPacket = new FIND_ENEMY();
                FindEnemyData data = (FindEnemyData)msgInfo;
                findEnemyPacket.day = data.day;
                findEnemyPacket.hour = data.hour;
                findEnemyPacket.min = data.min;
                findEnemyPacket.myPosition = data.myPosition;
                findEnemyPacket.targetPosition = data.targetPosition;
                findEnemyPacket.targetType1 = data.targetType1;
                findEnemyPacket.target1Count = data.target1Count;
                findEnemyPacket.targetType2 = data.targetType2;
                findEnemyPacket.target2Count = data.target2Count;
                findEnemyPacket.targetType3 = data.targetType3;
                findEnemyPacket.target3Count = data.target3Count;
                findEnemyPacket.targetPosture = data.targetPosture;
                findEnemyPacket.targetDirection = data.targetDirection;
                findEnemyPacket.note = data.note;
                findEnemyPacket.packetType = PACKET_TYPE.FIND_ENEMY;
                findEnemyPacket.createDate = data.date;
                SendPacketData(findEnemyPacket);
                data.messageState = MessageState.SEND;
                buttonManager.prevButtonState = BottomButtonState.FIND_ENEMY_SEND;
            }
            else if (msgInfo is TransferData)
            {
                TRANSFER transferPacket = new TRANSFER();
                TransferData data = (TransferData)msgInfo;
                transferPacket.rescuePosition = data.rescuePosition;
                transferPacket.patient = data.patient;
                transferPacket.stretcher = data.stretcher;
                transferPacket.transferPriority = data.transferPriority;
                transferPacket.mark = data.mark;
                transferPacket.pollution = data.pollution;
                transferPacket.markColor = data.markColor;
                transferPacket.areaSafetyLevel = data.areaSafetyLevel;
                transferPacket.national = data.national;
                transferPacket.note = data.note;
                transferPacket.packetType = PACKET_TYPE.TRANSFER;
                transferPacket.createDate = data.date;
                SendPacketData(transferPacket);
                data.messageState = MessageState.SEND;
                buttonManager.prevButtonState = BottomButtonState.TRANSFER_SEND;
            }
            else if (msgInfo is CBRN_FirstData)
            {
                CBRN_FIRST cbrnFirstPacket = new CBRN_FIRST();
                CBRN_FirstData data = (CBRN_FirstData)msgInfo;
                cbrnFirstPacket.cbrnType = data.cbrnType;
                cbrnFirstPacket.myPosition = data.myPosition;
                cbrnFirstPacket.myRotation_do = data.myRotation_do;
                cbrnFirstPacket.myRotation_mil = data.myRotation_mil;
                cbrnFirstPacket.atkStartD = data.atkStartD;
                cbrnFirstPacket.atkStartH = data.atkStartH;
                cbrnFirstPacket.atkStartM = data.atkStartM;
                cbrnFirstPacket.atkEndD = data.atkEndD;
                cbrnFirstPacket.atkEndH = data.atkEndH;
                cbrnFirstPacket.atkEndM = data.atkEndM;
                cbrnFirstPacket.attackedPosition = data.attackedPosition;
                cbrnFirstPacket.situation = data.situation;
                cbrnFirstPacket.classifications = data.classifications;
                cbrnFirstPacket.property = data.property;
                cbrnFirstPacket.kinds = data.kinds;
                cbrnFirstPacket.explosionShape = data.explosionShape;
                cbrnFirstPacket.fireMethod = data.fireMethod;
                cbrnFirstPacket.NumberOfAmmunition = data.NumberOfAmmunition;
                cbrnFirstPacket.NumberOfAircraft = data.NumberOfAircraft;
                cbrnFirstPacket.note = data.note;
                cbrnFirstPacket.packetType = PACKET_TYPE.CBRN_FIRST;
                cbrnFirstPacket.createDate = data.date;
                SendPacketData(cbrnFirstPacket);
                data.messageState = MessageState.SEND;
                data.priority = Priority.FIRST;
                buttonManager.prevButtonState = BottomButtonState.CBRN_FIRST_SEND;
            }
            else if (msgInfo is CBRN_ScoutData)
            {
                CBRN_SCOUT cbrnScoutPacket = new CBRN_SCOUT();   //패킷 객체 생성
                CBRN_ScoutData data = (CBRN_ScoutData)msgInfo; //ui정보 추가
                cbrnScoutPacket.startDay = data.startDay;
                cbrnScoutPacket.startHour = data.startHour;
                cbrnScoutPacket.startMin = data.startMin;
                cbrnScoutPacket.classifications = data.classifications;
                cbrnScoutPacket.property = data.property;
                cbrnScoutPacket.kinds = data.kinds;
                cbrnScoutPacket.explosionShape = data.explosionShape;
                cbrnScoutPacket.radiationRate = data.radiationRate;
                //리스트 넘김
                for (int i = 0; i < data.scoutItems.Length; i++)
                {
                    cbrnScoutPacket.scoutItemArr[i] = data.scoutItems[i];
                }
                cbrnScoutPacket.note = data.note;
                cbrnScoutPacket.packetType = PACKET_TYPE.CBRN_SCOUT;
                cbrnScoutPacket.createDate = data.date;
                SendPacketData(cbrnScoutPacket);
                data.messageState = MessageState.SEND;
                data.priority = Priority.FOURTH;

                buttonManager.prevButtonState = BottomButtonState.CBRN_SCOUT_SEND;
            }
            else if (msgInfo is MyStateData)
            {
                MY_STATE myStatePacket = new MY_STATE();
                MyStateData data = (MyStateData)msgInfo; //ui정보 추가
                myStatePacket.year = data.year;
                myStatePacket.month = data.month;
                myStatePacket.day = data.day;
                myStatePacket.hour = data.hour;
                myStatePacket.minute = data.minute;
                myStatePacket.title = data.title;
                myStatePacket.enemyPosture = data.enemyPosture;
                myStatePacket.myPosition = data.myPosition;
                myStatePacket.enemyPostureLevel = data.enemyPostureLevel;
                myStatePacket.lastOrder = data.lastOrder;
                myStatePacket.LeftCoord = data.LeftCoord;
                myStatePacket.RightCoord = data.RightCoord;
                myStatePacket.combat = data.combat;
                myStatePacket.death = data.death;
                myStatePacket.injury = data.injury;
                myStatePacket.ammo_h = data.ammo_h;
                myStatePacket.ammo_a = data.ammo_a;
                myStatePacket.ammo_c = data.ammo_c;
                myStatePacket.ammo_s = data.ammo_s;
                myStatePacket.ammo_m = data.ammo_m;
                myStatePacket.note = data.note;
                myStatePacket.packetType = PACKET_TYPE.MY_STATE;
                myStatePacket.createDate = data.date;
                SendPacketData(myStatePacket);
                data.messageState = MessageState.SEND;
                buttonManager.prevButtonState = BottomButtonState.MY_STATE_SEND;
            }
            else if (msgInfo is ObstacleData)
            {
                OBSTACLE obstaclePacket = new OBSTACLE();
                ObstacleData data = (ObstacleData)msgInfo; //ui정보 추가

                obstaclePacket.year = data.year;
                obstaclePacket.month = data.month;
                obstaclePacket.day = data.day;
                obstaclePacket.hour = data.hour;
                obstaclePacket.minute = data.minute;
                obstaclePacket.obtaclePosition = data.obtaclePosition;
                obstaclePacket.classifyEnemies = data.classifyEnemies;
                obstaclePacket.obstacleShape = data.obstacleShape;
                obstaclePacket.numberOfObstacle = data.numberOfObstacle;
                obstaclePacket.controlNumber = data.controlNumber;
                obstaclePacket.installUnit = data.installUnit;
                obstaclePacket.obstacleShape = data.obstacleShape; // 장애물  드롭다운 정보가 잘 넘어가는지 확인할 것, 살짝 애매함
                switch (obstaclePacket.obstacleShape)
                {
                    case ObstacleShape.WIRE:
                        obstaclePacket.obstacleBarbedWireType = data.obstacleBarbedWireType;
                        break;
                    case ObstacleShape.MINE:
                        obstaclePacket.obstacleMineType = data.obstacleMineType;
                        break;
                    case ObstacleShape.WALL:
                        obstaclePacket.obstacleWallType = data.obstacleWallType;
                        break;
                    case ObstacleShape.OBSTACLE_CATEGORY:
                        obstaclePacket.obstacleCategory = data.obstacleCategory;
                        break;
                }
                obstaclePacket.width = data.width;
                obstaclePacket.length = data.length;
                obstaclePacket.note = data.note;
                obstaclePacket.packetType = PACKET_TYPE.OBSTACLE;
                obstaclePacket.createDate = data.date;
                SendPacketData(obstaclePacket);
                data.messageState = MessageState.SEND;
                buttonManager.prevButtonState = BottomButtonState.OBSTACLE_SEND;
            }
            else if (msgInfo is TargetDamageData)
            {
                TARGET_DAMAGE targetDamagePacket = new TARGET_DAMAGE();   //패킷 객체 생성
                TargetDamageData data = (TargetDamageData)msgInfo;
                targetDamagePacket.targetType = data.targetType;
                targetDamagePacket.targetScale = data.targetScale;
                targetDamagePacket.targetPos = data.targetPos;
                targetDamagePacket.measnsOfAttack = data.measnsOfAttack;
                targetDamagePacket.note = data.note;
                targetDamagePacket.packetType = PACKET_TYPE.TARGET_DAMAGE;
                targetDamagePacket.createDate = data.date;
                SendPacketData(targetDamagePacket);
                data.messageState = MessageState.SEND;
                buttonManager.prevButtonState = BottomButtonState.TARGET_DAMAGE_SEND;
            }
            else if (msgInfo is NoFormatData)
            {
                NO_FORMAT noFormatPacket = new NO_FORMAT();   //패킷 객체 생성
                NoFormatData data = (NoFormatData)msgInfo; //ui정보 추가
                noFormatPacket.year = data.year;
                noFormatPacket.month = data.month;
                noFormatPacket.day = data.day;
                noFormatPacket.hour = data.hour;
                noFormatPacket.minute = data.minute;
                noFormatPacket.title = data.title;
                for (int i = 0; i < data.lines.Length; i++)
                {
                    noFormatPacket.lines[i] = data.lines[i];
                }
                noFormatPacket.packetType = PACKET_TYPE.NO_FORMAT;
                noFormatPacket.createDate = data.date;
                SendPacketData(noFormatPacket);
                data.messageState = MessageState.SEND;
                buttonManager.prevButtonState = BottomButtonState.NO_FORMAT_SEND;
            }
            else if (msgInfo is FireSupportData)
            {
                FIRE_SUPPORT fireRequirePacket = new FIRE_SUPPORT();   //패킷 객체 생성
                FireSupportData data = (FireSupportData)msgInfo; //ui정보 추가
                fireRequirePacket.missionType = data.missionType;
                fireRequirePacket.squadSize = data.squadSize;
                fireRequirePacket.targetPos = data.targetPos;
                fireRequirePacket.plannedTarget = data.plannedTarget;
                fireRequirePacket.targetType = data.targetType;
                fireRequirePacket.targetActiveState = data.targetActiveState;
                fireRequirePacket.numberOfScale = data.numberOfScale;
                fireRequirePacket.targetScale = data.targetScale;
                fireRequirePacket.mixedTargetType = data.mixedTargetType;
                fireRequirePacket.shape = data.shape;
                fireRequirePacket.size1 = data.size1;
                fireRequirePacket.size2 = data.size2;
                fireRequirePacket.rad = data.rad;
                fireRequirePacket.note = data.note;
                fireRequirePacket.atkMethod = data.atkMethod;
                fireRequirePacket.ctrlMethod = data.ctrlMethod;
                fireRequirePacket.packetType = PACKET_TYPE.FIRE_SUPPORT;
                fireRequirePacket.createDate = data.date;
                SendPacketData(fireRequirePacket);
                data.messageState = MessageState.SEND;
                data.priority = Priority.SECOND;
                buttonManager.prevButtonState = BottomButtonState.FIRE_SUPPORT_SEND;

            }
            #endregion
            else if (msgInfo is CommandData)
            {
                COMMAND commandPacket = new COMMAND();   //패킷 객체 생성
                CommandData data = (CommandData)msgInfo;
                commandPacket.title = Encoding.Unicode.GetBytes(data.title);
                int row = commandPacket.lines.GetLength(1);
                for (int i = 0; i < data.lines.Length; i++)//35줄만큼 반복 col
                {   //string 배열을 byte2차원 배열로
                    byte[] arr = Encoding.Unicode.GetBytes(data.lines[i].Trim());//string 한줄을 byte 배열로 변환
                    for (int j = 0; j < arr.Length; j++)
                    {
                        commandPacket.lines[i, j] = arr[j];
                    }
                }
                commandPacket.job_Position = data.job_Position;
                commandPacket.rank = data.rank;
                commandPacket.name = Encoding.Unicode.GetBytes(data.userName);
                commandPacket.marginalNoteInfo = checkData;//임시 데이터를 여기에 대입
                commandPacket.createDate = data.date;
                commandPacket.packetType = PACKET_TYPE.COMMAND;
                commandPacket.isLink = data.isLink;
                buttonManager.prevButtonState = BottomButtonState.COMMAND_SEND;

                SendPacketData(commandPacket);
                data.messageState = MessageState.SEND;
                for (int i = 0; i < messageManager.msgList.Count; i++)
                {
                    if (commandPacket.marginalNoteInfo.index == messageManager.msgList[i].index)
                    {
                        messageManager.msgList[i].messageState = MessageState.SEND; //명령전문에 첨부된 난외주기 정보도 보냄처리 
                    }
                }            
            }            
        }
        public void SaveMarginalPacketData(MsgData msgInfo) //데이터를 패킷으로 메세지 데이터로부터 패킷정보를 담기만 하면된다.
        {
            if (msgInfo is MarginalNoteData) //저장 시점을 바꾸고, 임시 데이터 폴더에 담음 
            {
                MARGINAL_NOTE marginalNotePacket = new MARGINAL_NOTE();   //패킷 객체 생성
                MarginalNoteData marginalNoteData = (MarginalNoteData)msgInfo;
                marginalNotePacket.secretLevel = marginalNoteData.secretLevel;
                marginalNotePacket.missionName = marginalNoteData.missionName;
                marginalNotePacket.misstionTarget = marginalNoteData.missionTarget;
                marginalNotePacket.jobPosition = Encoding.Unicode.GetBytes(marginalNoteData.jobPosition);
                marginalNotePacket.platoonText = Encoding.Unicode.GetBytes(marginalNoteData.platoonText);
                marginalNotePacket.companyText = Encoding.Unicode.GetBytes(marginalNoteData.companyText);
                marginalNotePacket.battalionText = Encoding.Unicode.GetBytes(marginalNoteData.battalionText);
                marginalNotePacket.userName = Encoding.Unicode.GetBytes(marginalNoteData.userName);
                marginalNotePacket.date = Encoding.Unicode.GetBytes(marginalNoteData.date);
                marginalNotePacket.note = Encoding.Unicode.GetBytes(marginalNoteData.note);
                for (int i = 0; i < marginalNoteData.overlayIconArr.Length; i++)
                {
                    marginalNotePacket.overlayDataArr[i] = marginalNoteData.overlayIconArr[i];
                }
                marginalNotePacket.packetType = PACKET_TYPE.OVERLAY;
                checkData = marginalNotePacket; //송신 버튼을 눌러 임시 데이터에 저장
            }        
        }
        //메세지를 받았을 때
        public void PacketToData(Packet packetInfo) //패킷을 데이터로
        {
            #region 일반 전문 영역
            if (packetInfo is FIND_ENEMY)
            {
                FindEnemyData findEnemyInfo = new FindEnemyData();
                FIND_ENEMY PacketData = (FIND_ENEMY)packetInfo;
                findEnemyInfo.day = PacketData.day;
                findEnemyInfo.hour = PacketData.hour;
                findEnemyInfo.min = PacketData.min;
                findEnemyInfo.myPosition = PacketData.myPosition;
                findEnemyInfo.targetPosition = PacketData.targetPosition;
                findEnemyInfo.targetType1 = PacketData.targetType1;
                findEnemyInfo.target1Count = PacketData.target1Count;
                findEnemyInfo.targetType2 = PacketData.targetType2;
                findEnemyInfo.target2Count = PacketData.target2Count;
                findEnemyInfo.targetType3 = PacketData.targetType3;
                findEnemyInfo.target3Count = PacketData.target3Count;
                findEnemyInfo.targetPosture = PacketData.targetPosture;
                findEnemyInfo.targetDirection = PacketData.targetDirection;
                findEnemyInfo.messageTitle = findEnemyInfo.note = PacketData.note;
                findEnemyInfo.messageType = MessageType.FIND_ENEMY;
                findEnemyInfo.messageState = MessageState.RECV;
                findEnemyInfo.index = messageManager.messageIndex;
                findEnemyInfo.messageCategoryTxt = "적발견";
                findEnemyInfo.priority = Priority.THIRD;
                findEnemyInfo.date = PacketData.createDate;
                messageManager.msgList.Add(findEnemyInfo);
            }
            else if (packetInfo is TRANSFER)
            {
                TransferData transferInfo = new TransferData();
                TRANSFER PacketData = (TRANSFER)packetInfo;
                transferInfo.rescuePosition = PacketData.rescuePosition;
                transferInfo.patient = PacketData.patient;
                transferInfo.stretcher = PacketData.stretcher;
                transferInfo.transferPriority = PacketData.transferPriority;
                transferInfo.mark = PacketData.mark;
                transferInfo.pollution = PacketData.pollution;
                transferInfo.markColor = PacketData.markColor;
                transferInfo.areaSafetyLevel = PacketData.areaSafetyLevel;
                transferInfo.national = PacketData.national;
                transferInfo.messageTitle = transferInfo.note = PacketData.note;
                transferInfo.messageType = MessageType.TRANSFER;
                transferInfo.messageState = MessageState.RECV;
                transferInfo.index = messageManager.messageIndex;
                transferInfo.messageCategoryTxt = "후송";
                transferInfo.priority = Priority.SECOND;
                transferInfo.date = PacketData.createDate;
                messageManager.msgList.Add(transferInfo);
            }
            else if (packetInfo is CBRN_FIRST)
            {
                CBRN_FirstData cbrnFirstInfo = new CBRN_FirstData();
                CBRN_FIRST PacketData = (CBRN_FIRST)packetInfo;
                cbrnFirstInfo.cbrnType = PacketData.cbrnType;
                cbrnFirstInfo.myPosition = PacketData.myPosition;
                cbrnFirstInfo.myRotation_do = PacketData.myRotation_do;
                cbrnFirstInfo.myRotation_mil = PacketData.myRotation_mil;
                cbrnFirstInfo.atkStartD = PacketData.atkStartD;
                cbrnFirstInfo.atkStartH = PacketData.atkStartH;
                cbrnFirstInfo.atkStartM = PacketData.atkStartM;
                cbrnFirstInfo.atkEndD = PacketData.atkEndD;
                cbrnFirstInfo.atkEndH = PacketData.atkEndH;
                cbrnFirstInfo.atkEndM = PacketData.atkEndM;
                cbrnFirstInfo.attackedPosition = PacketData.attackedPosition;
                cbrnFirstInfo.situation = PacketData.situation;
                cbrnFirstInfo.classifications = PacketData.classifications;
                cbrnFirstInfo.property = PacketData.property;
                cbrnFirstInfo.kinds = PacketData.kinds;
                cbrnFirstInfo.explosionShape = PacketData.explosionShape;
                cbrnFirstInfo.fireMethod = PacketData.fireMethod;
                cbrnFirstInfo.NumberOfAmmunition = PacketData.NumberOfAmmunition;
                cbrnFirstInfo.NumberOfAircraft = PacketData.NumberOfAircraft;
                cbrnFirstInfo.messageTitle = cbrnFirstInfo.note = PacketData.note;
                cbrnFirstInfo.messageType = MessageType.CBRN_FIRST;
                cbrnFirstInfo.messageState = MessageState.RECV;
                cbrnFirstInfo.index = messageManager.messageIndex;
                cbrnFirstInfo.messageCategoryTxt = "화생방최초";
                cbrnFirstInfo.priority = Priority.FIRST;
                cbrnFirstInfo.date = PacketData.createDate;
                messageManager.msgList.Add(cbrnFirstInfo);
            }

            else if (packetInfo is CBRN_SCOUT)
            {
                CBRN_ScoutData cbrnScoutInfo = new CBRN_ScoutData();   //패킷 객체 생성
                CBRN_SCOUT PacketData = (CBRN_SCOUT)packetInfo; //ui정보 추가
                cbrnScoutInfo.startDay = PacketData.startDay;
                cbrnScoutInfo.startHour = PacketData.startHour;
                cbrnScoutInfo.startMin = PacketData.startMin;
                cbrnScoutInfo.classifications = PacketData.classifications;
                cbrnScoutInfo.property = PacketData.property;
                cbrnScoutInfo.kinds = PacketData.kinds;
                cbrnScoutInfo.explosionShape = PacketData.explosionShape;
                cbrnScoutInfo.radiationRate = PacketData.radiationRate;
                //패킷 데이터를 메세지 데이터로 
                for (int i = 0; i < PacketData.scoutItemArr.Length; i++)
                {
                    cbrnScoutInfo.scoutItems[i] = PacketData.scoutItemArr[i];
                }
                cbrnScoutInfo.messageTitle = cbrnScoutInfo.note = PacketData.note;
                cbrnScoutInfo.messageType = MessageType.CBRN_SCOUT;
                cbrnScoutInfo.messageState = MessageState.RECV;
                cbrnScoutInfo.index = messageManager.messageIndex;
                cbrnScoutInfo.messageCategoryTxt = "화생방정찰";
                cbrnScoutInfo.priority = Priority.FOURTH;
                cbrnScoutInfo.date = PacketData.createDate;
                messageManager.msgList.Add(cbrnScoutInfo);
            }
            else if (packetInfo is MY_STATE)
            {
                MyStateData myStateInfo = new MyStateData();
                MY_STATE PacketData = (MY_STATE)packetInfo; //ui정보 추가
                myStateInfo.year = PacketData.year;
                myStateInfo.month = PacketData.month;
                myStateInfo.day = PacketData.day;
                myStateInfo.hour = PacketData.hour;
                myStateInfo.minute = PacketData.minute;
                myStateInfo.messageTitle = myStateInfo.title = PacketData.title;
                myStateInfo.enemyPosture = PacketData.enemyPosture;
                myStateInfo.myPosition = PacketData.myPosition;
                myStateInfo.enemyPostureLevel = PacketData.enemyPostureLevel;
                myStateInfo.lastOrder = PacketData.lastOrder;
                myStateInfo.LeftCoord = PacketData.LeftCoord;
                myStateInfo.RightCoord = PacketData.RightCoord;
                myStateInfo.combat = PacketData.combat;
                myStateInfo.death = PacketData.death;
                myStateInfo.injury = PacketData.injury;
                myStateInfo.ammo_h = PacketData.ammo_h;
                myStateInfo.ammo_a = PacketData.ammo_a;
                myStateInfo.ammo_c = PacketData.ammo_c;
                myStateInfo.ammo_s = PacketData.ammo_s;
                myStateInfo.ammo_m = PacketData.ammo_m;
                myStateInfo.note = PacketData.note;
                myStateInfo.messageType = MessageType.MY_STATE;
                myStateInfo.messageState = MessageState.RECV;
                myStateInfo.index = messageManager.messageIndex;
                myStateInfo.messageCategoryTxt = "자차상황";
                myStateInfo.priority = Priority.THIRD;
                myStateInfo.date = PacketData.createDate;
                messageManager.msgList.Add(myStateInfo);
            }
            else if (packetInfo is OBSTACLE)
            {
                ObstacleData obstacleInfo = new ObstacleData();
                OBSTACLE PacketData = (OBSTACLE)packetInfo; //ui정보 추가

                obstacleInfo.year = PacketData.year;
                obstacleInfo.month = PacketData.month;
                obstacleInfo.day = PacketData.day;
                obstacleInfo.hour = PacketData.hour;
                obstacleInfo.minute = PacketData.minute;
                obstacleInfo.obtaclePosition = PacketData.obtaclePosition;
                obstacleInfo.classifyEnemies = PacketData.classifyEnemies;
                obstacleInfo.obstacleShape = PacketData.obstacleShape;
                obstacleInfo.numberOfObstacle = PacketData.numberOfObstacle;
                obstacleInfo.controlNumber = PacketData.controlNumber;
                obstacleInfo.installUnit = PacketData.installUnit;
                obstacleInfo.obstacleShape = PacketData.obstacleShape;
                switch (obstacleInfo.obstacleShape)
                {
                    case ObstacleShape.WIRE:
                        obstacleInfo.obstacleBarbedWireType = PacketData.obstacleBarbedWireType;
                        break;
                    case ObstacleShape.MINE:
                        obstacleInfo.obstacleMineType = PacketData.obstacleMineType;
                        break;
                    case ObstacleShape.WALL:
                        obstacleInfo.obstacleWallType = PacketData.obstacleWallType;
                        break;
                    case ObstacleShape.OBSTACLE_CATEGORY:
                        obstacleInfo.obstacleCategory = PacketData.obstacleCategory;
                        break;
                }
                obstacleInfo.width = PacketData.width;
                obstacleInfo.length = PacketData.length;
                obstacleInfo.messageTitle = obstacleInfo.note = PacketData.note;
                obstacleInfo.messageType = MessageType.OBSTACLE;
                obstacleInfo.messageState = MessageState.RECV;
                obstacleInfo.index = messageManager.messageIndex;
                obstacleInfo.messageCategoryTxt = "장애물";
                obstacleInfo.priority = Priority.THIRD;
                obstacleInfo.date = PacketData.createDate;
                messageManager.msgList.Add(obstacleInfo);
            }
            else if (packetInfo is TARGET_DAMAGE)
            {
                TargetDamageData targetDamageInfo = new TargetDamageData();   //패킷 객체 생성
                TARGET_DAMAGE PacketData = (TARGET_DAMAGE)packetInfo;
                targetDamageInfo.targetType = PacketData.targetType;
                targetDamageInfo.targetScale = PacketData.targetScale;
                targetDamageInfo.targetPos = PacketData.targetPos;
                targetDamageInfo.measnsOfAttack = PacketData.measnsOfAttack;
                targetDamageInfo.messageTitle = targetDamageInfo.note = PacketData.note;
                targetDamageInfo.messageType = MessageType.TARGET_DAMAGE;
                targetDamageInfo.messageState = MessageState.RECV;
                targetDamageInfo.index = messageManager.messageIndex;
                targetDamageInfo.messageCategoryTxt = "표적피해";
                targetDamageInfo.priority = Priority.THIRD;
                messageManager.msgList.Add(targetDamageInfo);
            }

            else if (packetInfo is NO_FORMAT)
            {
                NoFormatData noFormatInfo = new NoFormatData();   //패킷 객체 생성
                NO_FORMAT PacketData = (NO_FORMAT)packetInfo; //ui정보 추가
                noFormatInfo.year = PacketData.year;
                noFormatInfo.month = PacketData.month;
                noFormatInfo.day = PacketData.day;
                noFormatInfo.hour = PacketData.hour;
                noFormatInfo.minute = PacketData.minute;
                noFormatInfo.messageTitle = noFormatInfo.title = PacketData.title;
                for (int i = 0; i < PacketData.lines.Length; i++)
                {
                    noFormatInfo.lines[i] = PacketData.lines[i];
                }
                noFormatInfo.messageType = MessageType.NO_FORMAT;
                noFormatInfo.messageState = MessageState.RECV;
                noFormatInfo.index = messageManager.messageIndex;
                noFormatInfo.messageCategoryTxt = "비양식";
                noFormatInfo.priority = Priority.THIRD;
                noFormatInfo.date = PacketData.createDate;
                messageManager.msgList.Add(noFormatInfo);
            }

            else if (packetInfo is FIRE_SUPPORT)
            {
                FireSupportData fireSupportInfo = new FireSupportData();   //패킷 객체 생성
                FIRE_SUPPORT PacketData = (FIRE_SUPPORT)packetInfo; //ui정보 추가
                fireSupportInfo.missionType = PacketData.missionType;
                fireSupportInfo.squadSize = PacketData.squadSize;
                fireSupportInfo.targetPos = PacketData.targetPos;
                fireSupportInfo.plannedTarget = PacketData.plannedTarget;
                fireSupportInfo.targetType = PacketData.targetType;
                fireSupportInfo.targetActiveState = PacketData.targetActiveState;
                fireSupportInfo.numberOfScale = PacketData.numberOfScale;
                fireSupportInfo.targetScale = PacketData.targetScale;
                fireSupportInfo.mixedTargetType = PacketData.mixedTargetType;
                fireSupportInfo.shape = PacketData.shape;
                fireSupportInfo.size1 = PacketData.size1;
                fireSupportInfo.size2 = PacketData.size2;
                fireSupportInfo.rad = PacketData.rad;
                fireSupportInfo.messageTitle = fireSupportInfo.note = PacketData.note;
                fireSupportInfo.atkMethod = PacketData.atkMethod;
                fireSupportInfo.ctrlMethod = PacketData.ctrlMethod;
                fireSupportInfo.messageType = MessageType.FIRE_SUPPORT;
                fireSupportInfo.messageState = MessageState.RECV;
                fireSupportInfo.index = messageManager.messageIndex;
                fireSupportInfo.messageCategoryTxt = "화력지원";
                fireSupportInfo.priority = Priority.SECOND;
                fireSupportInfo.date = PacketData.createDate;
                messageManager.msgList.Add(fireSupportInfo);
            }
            #endregion
            else if (packetInfo is COMMAND)
            {
                CommandData commandInfo = new CommandData();   //패킷 객체 생성
                COMMAND PacketData = (COMMAND)packetInfo;
                commandInfo.messageTitle = commandInfo.title = Encoding.Unicode.GetString(PacketData.title);

               
                int col = PacketData.lines.GetLength(1);//한줄에 들어가는 바이트 수
                for (int i = 0; i < PacketData.lines.GetLength(0); i++)//35줄 만듬
                {
                    //var data = PacketData.lines.GetRow(i);
                    //commandInfo.lines[i] = Encoding.Unicode.GetString(data);
                    for (int j = 0; j < col; j++)//28글자씩 끊어서 => 길이를 35로 나누어  
                    {
                        byte[] newbyte = new byte[PacketData.lines.GetLength(0)];
                        Buffer.BlockCopy(PacketData.lines, 0, newbyte, 0, sizeof(byte) * newbyte.Length);
                        commandInfo.lines[i] = Encoding.Unicode.GetString(newbyte);
                    }
                }
                //commandPacket.releavantOverlay 관련 투명도를 어떻게 보내야할 것인지
                commandInfo.job_Position = PacketData.job_Position;
                commandInfo.rank = PacketData.rank;
                commandInfo.userName = Encoding.Unicode.GetString(PacketData.name);
                commandInfo.messageType = MessageType.COMMAND;
                commandInfo.messageState = MessageState.RECV;
                commandInfo.index = messageManager.messageIndex;
                commandInfo.messageCategoryTxt = "명령";
                commandInfo.priority = Priority.THIRD;
                commandInfo.marginalNoteInfo = PacketData.marginalNoteInfo;
                commandInfo.isLink = PacketData.isLink;
                commandInfo.date = PacketData.createDate;
                if (commandInfo.isLink == true)//난외지도가 포함되어있다면
                {
                    MarginalNoteData marginalNoteInfo = new MarginalNoteData();
                    MARGINAL_NOTE MnPacketData = commandInfo.marginalNoteInfo;   //패킷 객체 생성
                    marginalNoteInfo.secretLevel = MnPacketData.secretLevel;
                    marginalNoteInfo.missionName = MnPacketData.missionName;
                    marginalNoteInfo.missionTarget = MnPacketData.misstionTarget;
                    marginalNoteInfo.jobPosition = Encoding.Unicode.GetString(MnPacketData.jobPosition);
                    marginalNoteInfo.platoonText = Encoding.Unicode.GetString(MnPacketData.platoonText);
                    marginalNoteInfo.companyText = Encoding.Unicode.GetString(MnPacketData.companyText);
                    marginalNoteInfo.battalionText = Encoding.Unicode.GetString(MnPacketData.battalionText);
                    marginalNoteInfo.userName = Encoding.Unicode.GetString(MnPacketData.userName);
                    marginalNoteInfo.date = Encoding.Unicode.GetString(MnPacketData.date);
                    marginalNoteInfo.note = Encoding.Unicode.GetString(MnPacketData.note);
                    for (int i = 0; i < MnPacketData.overlayDataArr.Length; i++)
                    {                      
                        if (MnPacketData.overlayDataArr[i] != null)
                        {
                            OverlayIconData icondata = new OverlayIconData();//데이터 객체 생성
                            icondata = MnPacketData.overlayDataArr[i];//패킷으로부터 정보 저장
                            uiManager.rightPanel.overlayTool.Return_Icon(icondata.iconIndex);//인덱스 값에 일치하는 리소스 불러옴
                            uiManager.nonMsgPanel.overlayPanel.RecvIdentity(icondata.identity);// 아이콘 색 변경 
                            GameObject go = Instantiate(itemManager.overlayIconPrefab,uiManager.rightPanel.OverlayContainer.transform);//아이콘생성
                            go.GetComponent<Image>().sprite = uiManager.nonMsgPanel.overlayPanel.image_BG.sprite;//아이콘 참조
                            go.GetComponent<Image>().color = uiManager.nonMsgPanel.overlayPanel.image_BG.color; //색 결정 참조                           
                            go.GetComponent<IconInfo>().myIcon = icondata.iconIndex;//아이콘 정보 받음 
                            go.GetComponent<IconInfo>().myIdentity = icondata.identity;                        
                            //트랜스폼 정보
                            go.GetComponent<IconInfo>().myPosition = new Vector3(icondata.PosX, icondata.PosY, icondata.PosZ);
                            go.GetComponent<IconInfo>().myRotation = new Vector3(icondata.RotX,icondata.RotY, icondata.RotZ);
                            go.GetComponent<IconInfo>().myScale = new Vector3(icondata.ScaleX, icondata.ScaleY, icondata.ScaleZ);
                            go.transform.position = uiManager.rightPanel.overlayIcon.GetScreenPosition(go.GetComponent<IconInfo>().myPosition);
                            marginalNoteInfo.overlayList.Add(icondata);//수신받은 난외주기 메세지 정보에 추가 
                        }                     
                    }
                    marginalNoteInfo.messageTitle = marginalNoteInfo.missionName;
                    
                    marginalNoteInfo.messageType = MessageType.OVERLAY;
                    marginalNoteInfo.messageState = MessageState.RECV;
                    marginalNoteInfo.index = commandInfo.index + 50000;
                    marginalNoteInfo.priority = Priority.THIRD;
                    marginalNoteInfo.date = PacketData.createDate;
                    messageManager.msgList.Add(marginalNoteInfo);
                }
                messageManager.msgList.Add(commandInfo);
            }
            messageManager.SaveFile();
        }

        //클라인지 서버인지에 따라 전송방법이 바뀌는 패킷 데이터 
        private void SendPacketData(Packet infoPacket)
        {
            //전차장이 클라이언트일 경우 + 소대원이 클라, 전차장이 서버일 경우도 추가해야함 
            if (messageManager.selectRole.setRole == SelectRole.SELECT_ROLE.TANK_COMMANDER || messageManager.selectRole.setRole == SelectRole.SELECT_ROLE.PLATOON_MEMBER)
            {
                bool bSend = tcpClient.SendData(infoPacket); // 클라이언트로 보냄
                if (bSend)
                {
                    string str = "Send TCP Data" + infoPacket.ToString();
                    print(str);
                }
            }
            else if (messageManager.selectRole.setRole == SelectRole.SELECT_ROLE.HIGH_COMMANDER)//상위체계는 서버가 된다.
            {
                tcpServer.SendData(infoPacket);
            }
            packetList.Add(infoPacket); //패킷 리스트에 추가 
        }
        #endregion

        #region 이동로 송수신 관련 함수들
        //메세지 데이터를 패킷 데이터로
        public void SendWayPointData()
        {
            messageManager.SaveWayPoint();
            WAY_POINT wpPkt = new WAY_POINT();// 패킷정보
            WayPointData data = new WayPointData();//메세지 데이터
            //messageManager.wayPointDatas 메세지 데이터
            for (int i = 0; i < messageManager.wayPointDatas.Count; i++)
            {
                wpPkt.wayPointArr[i] = messageManager.wayPointDatas[i];
            }
            if (messageManager.selectRole.setRole == SelectRole.SELECT_ROLE.TANK_COMMANDER || messageManager.selectRole.setRole == SelectRole.SELECT_ROLE.PLATOON_MEMBER)//전차장이라면 
            {
                string str = "Send TCP Data" + wpPkt.ToString();
                print(str);
                tcpServer.SendData(wpPkt); //하위로 보냄, 전차장이 조종수에게...
            }
        }
        public void ReceiveWayPointData(Packet packet)
        {
            wayPointManager.uiLines.Points = new Vector2[0];//라인렌더러 초기화
            wayPointManager.lineConnect.transforms = new RectTransform[0];//라인 커넥터 초기화
            if (wayPointManager.saveWayPointList.Count > 0)
            {
                for (int i = 0; i < wayPointManager.saveWayPointList.Count; i++)
                {
                    Destroy(wayPointManager.saveWayPointList[i].gameObject);//객체를 삭제
                }
            }
            wayPointManager.saveWayPointList.Clear();
            CreateRecvWayPoint(packet);
        }
        private void CreateRecvWayPoint(Packet packet)
        {
            WAY_POINT wpPktData = (WAY_POINT)packet;//패킷 정보 받음
            if (buttonManager.currentButtonState == BottomButtonState.WAY_POINT) //현재 이동로 화면을 보고 있다면  
            {
                StartCoroutine(RedrawRoutine(wpPktData));
            }
            else
            {
                CreateWayPoint(wpPktData);
            }      //현재 이동로를 보고 있는게 아니라면 세로 받고 갱신하는 문제없음     
        }
        IEnumerator RedrawRoutine(WAY_POINT wpPktData)
        {
            wayPointManager.DriverWayPointClose();//지우고 
            yield return new WaitForSeconds(.1f);
            CreateWayPoint(wpPktData);//점을 그리고
            yield return new WaitForSeconds(.1f);
            wayPointManager.DriverWayPointOpen();//
        }
        private void CreateWayPoint(WAY_POINT wpPktData)
        {
            //정보를 받아서 객체를 생성 후, 비활성화 
            for (int i = 0; i < wpPktData.wayPointArr.Length; i++)
            {
                if (wpPktData.wayPointArr[i] != null) //객체 생성부분
                {   //패킷 데이터에서 saveList에 바로 저장                   
                    GameObject go = Instantiate(itemManager.PointPref, wayPointManager.transform);//오브젝트 생성
                    WayPointObjectInfo info = go.GetComponent<WayPointObjectInfo>();//오브젝트의 정보
                    string myPos = wpPktData.wayPointArr[i].myPosition;
                    float lat = float.Parse(myPos.Substring(0, 9));
                    float lon = float.Parse(myPos[10..]);
                    //string pos = (GPSEncoder.GPSToUCS(lat, lon) / 3000 - new Vector3(140.987f, 0, 32.818f)).ToString("F3");
                    //좌표로 표시
                    //string pos_x = pos.Substring(1, 8);
                    //string pos_z = pos.Substring(18, 8);
                    //Vector3 myPosVec = new Vector3(float.Parse(pos_x), 0, float.Parse(pos_z));
                    Vector3 ucs = VtasMapManager.instance.GPStoUCS(new Vector2(lat, lon));
                    go.transform.position = uiManager.rightPanel.overlayIcon.GetScreenPosition(ucs);
                    info.myPosition = uiManager.rightPanel.overlayIcon.GetWorldPosition(go.transform.position);
                    info.index = wpPktData.wayPointArr[i].index;
                    go.GetComponentsInChildren<Image>()[1].color = uiManager.nonMsgPanel.wayPointPanel.bg.color;
                    go.GetComponentsInChildren<Image>()[0].gameObject.SetActive(false);
                    //세부속성 입력
                    info.lonLatText = wpPktData.wayPointArr[i].myPosition;
                    info.startMonth = wpPktData.wayPointArr[i].startMinute;
                    info.startDay = wpPktData.wayPointArr[i].startMinute;
                    info.startHour = wpPktData.wayPointArr[i].startMinute;
                    info.startMinute = wpPktData.wayPointArr[i].startMinute;
                    info.endMonth = wpPktData.wayPointArr[i].endMonth;
                    info.endDay = wpPktData.wayPointArr[i].endDay;
                    info.endHour = wpPktData.wayPointArr[i].endHour;
                    info.endMinute = wpPktData.wayPointArr[i].endMinute;
                    info.speed = wpPktData.wayPointArr[i].speed;
                    info.wayPointType = wpPktData.wayPointArr[i].pointType; // 여기서 받아야함.
                    if (info.wayPointType == WayPointType.CHECK_POINT)
                    {
                        info.isCheckPoint = true;
                    }
                    switch (info.wayPointType)
                    {
                        case WayPointType.CHECK_POINT:
                            info.mainIcon.color = Color.red;
                            break;
                        case WayPointType.START_POINT:
                            info.mainIcon.color = Color.black;
                            break;
                        case WayPointType.RELEASE_POINT:
                            info.mainIcon.color = Color.green;
                            break;
                        case WayPointType.ROUTE_POINT:
                            info.mainIcon.color = Color.gray;
                            break;
                    }
                    uiManager.nonMsgPanel.wayPointCanvas.GetComponent<WayPointManager>().wayPointIndex++; ////wayPointIndex는 이동점 객체를 구분하기 위해 부여하는 인덱스, 이거 지우면 선이 안나타남
                    wayPointManager.saveWayPointList.Add(info);
                    go.SetActive(false);
                }
            }
        }
        #endregion
    }
}
