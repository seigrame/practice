using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TILE_TYPE
{
    NONE,
    OSM,
}

public enum MAP_SCALE
{
    S5M = 1,
    S10M = 2,
    S25M = 4,
    S50M = 8,
    S100M = 16
}

public enum MAP_MAGNIFICATION
{
    M25 = 0,
    M50,
    M100,
    M150,
    M200,
    M300,
    M400,
}

public enum MAP_COORD
{
    MGRS,
    UTM,
    WGS84
}

public enum MAP_GRID
{
    NONE = 0,
    M1000,
    M10000
}

public enum MAP_SUBGRID
{
    NONE = 0,
    D2,
    D5,
    D10
}

public class VtasMapManager : MonoBehaviour
{
    //�ʱ���ġ�� �޾Ƽ� ���� ��ġ�� ����ڰ� ���� �� �� �ְ� �ؾ���    
    public double minLongtitude;
    public double maxLongtitude;
    public double minLatitude;
    public double maxLatitude;

    [SerializeField] public Texture [] mapTextures;

    [Header("Ÿ�� ����")]
    [Space(10)]
    public TILE_TYPE tileType = TILE_TYPE.NONE;
    public MAP_GRID gridState;
    public MAP_SUBGRID subGridState;
    public MAP_COORD coordState;
    public MAP_SCALE mapScaleState;

    public GameObject osmTileManager;
    public GameObject CheorwonMapObject;
    public GameObject mapGrid;
    public GameObject mapSubGrid;
    public OSMTile osmTile;
    public static VtasMapManager instance = null;
    // Start is called before the first frame update

    Vector3 origin, difference; //���콺Ŀ�� ����

    UIManager uiManager;

    void Awake()
    {          
        if (null == instance)
        {
            //�� Ŭ���� �ν��Ͻ��� ź������ �� �������� instance�� ���ӸŴ��� �ν��Ͻ��� ������� �ʴٸ�, �ڽ��� �־��ش�.
            instance = this;

            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            Destroy(this.gameObject);
        }
    }
    public static VtasMapManager Instance
    {
        get
        {
            if (null == instance)
            {
                return null;
            }
            return instance;
        }
    }

    public void Start()
    {
        uiManager = FindObjectOfType<UIManager>();

        InitMapSetting();
    }
    // Update is called once per frame
    void Update()
    {
        //Ŭ���� ȭ����ǥ ������Ʈ
        //if(Input.GetMouseButtonDown(0))
        //{
            MapCoordinate.UpdateCoord(Input.mousePosition);

            string str = "";
            if (coordState == MAP_COORD.WGS84)
            {
                str = MapCoordinate.latitude.ToString("F6") + " " + MapCoordinate.longtitude.ToString("F6");
            }
            else if (coordState == MAP_COORD.UTM)
            {
                int zone = 0;
                double lat = 0;
                double lon = 0;
                UTMConverter.LatLonToUTMXY(MapCoordinate.latitude, MapCoordinate.longtitude, ref zone, ref lat, ref lon);
                str = "UTM " + zone + " " + lat.ToString("F0") + " " + lon.ToString("F0");
            }
            else if (coordState == MAP_COORD.MGRS)
            {
                str = "MGRS " + Worldwind.Coordinates.MGRSFromLatLon(MapCoordinate.latitude, MapCoordinate.longtitude);
            }
            uiManager.topPanel.SetCoordText(str);

        //}        

        //���� �̵�      
        if (Input.GetMouseButtonDown(1))
        {
            origin = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        }
        if (Input.GetMouseButton(1))
        {
            difference = origin - Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Camera.main.transform.position += difference;
        }
    }

    public void InitMapSetting()
    {       
        SetMapType(TILE_TYPE.NONE);
        SetMapScale(MAP_SCALE.S5M);
        SetMapMagnification(MAP_MAGNIFICATION.M100);

        SetMapCoord(MAP_COORD.WGS84);
        SetMapGrid(MAP_GRID.NONE);
        SetMapSubGrid(MAP_SUBGRID.NONE);
    }

    public void SetMapType(TILE_TYPE type)
    {
        tileType = type;

        if (tileType == TILE_TYPE.OSM)
        {
            osmTileManager.SetActive(true);
            CheorwonMapObject.SetActive(false);
        }
        else if (tileType == TILE_TYPE.NONE)
        {
            osmTileManager.SetActive(false);
            CheorwonMapObject.SetActive(true);
        }
    }

    public void SetMapScale(MAP_SCALE scale)
    {
        mapScaleState = scale;

        if (tileType == TILE_TYPE.NONE)
        {
            switch (scale)
            {
                case MAP_SCALE.S5M:
                    minLongtitude = 127.1944;
                    minLatitude = 38.1240;
                    maxLongtitude = 127.3801;
                    maxLatitude = 38.2624;

                    Camera.main.orthographicSize = 100;
                    CheorwonMapObject.GetComponent<MeshRenderer>().material.mainTexture = mapTextures[0];
                    break;
                case MAP_SCALE.S10M:
                    minLongtitude = 127.1060;
                    minLatitude = 38.0507;
                    maxLongtitude = 127.4751;
                    maxLatitude = 38.3400;

                    Camera.main.orthographicSize = 100;
                    CheorwonMapObject.GetComponent<MeshRenderer>().material.mainTexture = mapTextures[1];
                    break;
                case MAP_SCALE.S25M:
                    minLongtitude = 126.9257;
                    minLatitude = 37.9087;
                    maxLongtitude = 127.6234;
                    maxLatitude = 38.4611;

                    Camera.main.orthographicSize = 100;
                    CheorwonMapObject.GetComponent<MeshRenderer>().material.mainTexture = mapTextures[2];
                    break;
                case MAP_SCALE.S50M:
                    minLongtitude = 126.5574;
                    minLatitude = 37.6074;
                    maxLongtitude = 128.0299;
                    maxLatitude = 38.7803;

                    Camera.main.orthographicSize = 100;
                    CheorwonMapObject.GetComponent<MeshRenderer>().material.mainTexture = mapTextures[3];
                    break;
                case MAP_SCALE.S100M:
                    minLongtitude = 125.8868;
                    minLatitude = 36.9938;
                    maxLongtitude = 128.6774;
                    maxLatitude = 39.3258;

                    Camera.main.orthographicSize = 100;
                    CheorwonMapObject.GetComponent<MeshRenderer>().material.mainTexture = mapTextures[4];
                    break;
                default: break;
            }
        }
        else
        {            
            switch (scale)
            {
                case MAP_SCALE.S5M:
                    osmTile.tile_zoom = 13;
                    Camera.main.orthographicSize = 250;
                    break;
                case MAP_SCALE.S10M:
                    osmTile.tile_zoom = 12;
                    Camera.main.orthographicSize = 500;
                    break;
                case MAP_SCALE.S25M:
                    osmTile.tile_zoom = 11;
                    Camera.main.orthographicSize = 1000;
                    break;
                case MAP_SCALE.S50M:
                    osmTile.tile_zoom = 10;
                    Camera.main.orthographicSize = 2000;
                    break;
                case MAP_SCALE.S100M:
                    osmTile.tile_zoom = 9;
                    Camera.main.orthographicSize = 4000;
                    break;
                default: break;
            }
        }
        
    }

    public void SetMapMagnification(MAP_MAGNIFICATION mag)
    {
        if (tileType == TILE_TYPE.NONE)
        {
            switch (mag)
            {
                case MAP_MAGNIFICATION.M25: Camera.main.orthographicSize = 400; break;
                case MAP_MAGNIFICATION.M50: Camera.main.orthographicSize = 200; break;
                case MAP_MAGNIFICATION.M100: Camera.main.orthographicSize = 100; break;
                case MAP_MAGNIFICATION.M150: Camera.main.orthographicSize = 75; break;
                case MAP_MAGNIFICATION.M200: Camera.main.orthographicSize = 50; break;
                case MAP_MAGNIFICATION.M300: Camera.main.orthographicSize = 25; break;
                case MAP_MAGNIFICATION.M400: Camera.main.orthographicSize = 12.5f; break;
            }
        }
        else
        {
            switch (mag)
            {
                case MAP_MAGNIFICATION.M25: Camera.main.orthographicSize = 1000 * (int)mapScaleState; ; break;
                case MAP_MAGNIFICATION.M50: Camera.main.orthographicSize = 500 * (int)mapScaleState; ; break;
                case MAP_MAGNIFICATION.M100: Camera.main.orthographicSize = 250*(int)mapScaleState; break;
                case MAP_MAGNIFICATION.M150: Camera.main.orthographicSize = 125 * (int)mapScaleState; ; break;
                case MAP_MAGNIFICATION.M200: Camera.main.orthographicSize = 100 * (int)mapScaleState; ; break;
                case MAP_MAGNIFICATION.M300: Camera.main.orthographicSize = 50 * (int)mapScaleState; ; break;
                case MAP_MAGNIFICATION.M400: Camera.main.orthographicSize = 25 * (int)mapScaleState; ; break;
            }
        }
        
    }

    public void SetMapCoord(MAP_COORD coord)
    {
        coordState = coord;
    }

    public void SetMapGrid(MAP_GRID grid)
    {
        gridState = grid;

        switch (grid)
        {
            case MAP_GRID.NONE: mapGrid.SetActive(false); break;
            case MAP_GRID.M1000: mapGrid.SetActive(true); break;
            case MAP_GRID.M10000: mapGrid.SetActive(true); break;
        }
    }

    public void SetMapSubGrid(MAP_SUBGRID sub)
    {
        subGridState = sub;

        if (gridState == MAP_GRID.NONE)
        {
            subGridState = MAP_SUBGRID.NONE; 
        }

        switch (sub)
        {
            case MAP_SUBGRID.NONE: mapSubGrid.SetActive(false); break;
            case MAP_SUBGRID.D2: mapSubGrid.SetActive(true); break;
            case MAP_SUBGRID.D5: mapSubGrid.SetActive(true); break;
            case MAP_SUBGRID.D10: mapSubGrid.SetActive(true); break;
        }
    }


    //wgs84��ǥ�� ����Ƽ��ǥ��
    public Vector3 GPStoUCS(Vector2 gps)
    {
        int MapSize = 1000;
        //���� �浵�� �ּ��ִ밪���̿����� ������ ���Ѵ�
        //������ ����Ƽ ��ǥ�� ������ ��ȯ�ϸ� ��(0~1000)�����̹Ƿ� ������ 1000�� ���ϸ� ��
        double zRate =  (gps.x - minLatitude) / (maxLatitude - minLatitude);
        double xRate = (gps.y - minLongtitude) / (maxLatitude - minLatitude);

        double zPosition = zRate * MapSize; //Calc current lon
        double xPosition = xRate * MapSize; //Calc current lat
        return new Vector3((float)xPosition, 20, (float)zPosition);
    }

    //����Ƽ��ǥ�� wgs84��ǥ��
    public Vector2 UCStoGPS(Vector3 position)
    {
        int MapSize = 1000;

        double zRate = position.z / MapSize;
        double xRate = position.x / MapSize;
        double geoLocationX = minLatitude + (maxLatitude - minLatitude)* zRate; //Calc current lat
        double geoLocationY = minLongtitude + (maxLatitude - minLatitude)* xRate; //Calc current lon

        return new Vector2((float)geoLocationX, (float)geoLocationY);
    }

    //Ÿ�ϻ���� �ʷ� ��ȯ
    //0,0 �� 1,1�� Ÿ���� ��ǥ���� �̿��ؼ� ���� ��������  
    public Vector2 GetTileSizeToSecond(int x, int y, int zoom)
    {
        Vector2 size = Vector2.zero;

        if (zoom == 0)
        {
            float max_world_size = 360 * 3600; //360���� �ʷ� ��ȯ 

            size.x = max_world_size;
            size.y = max_world_size;
        }
        else
        {
            int max_size = (int)Math.Pow(2.0, zoom);
            if (x >= max_size) return size;
            if (y >= max_size) return size;

            //�κ����� ���̸� ������ ����Ѵ�
            Vector2 posA = GlobalDefine.TileToWorldPos(x, y, zoom);
            Vector3 posA_result = GPStoUCS(new Vector2(posA.y, posA.x));

            Vector2 posB = GlobalDefine.TileToWorldPos(x + 1, y + 1, zoom);
            Vector3 posB_result = GPStoUCS(new Vector2(posB.y, posB.x));

            size = posA_result - posB_result;

            size.x = Math.Abs(posA_result.x - posB_result.x);
            size.y = Math.Abs(posA_result.z - posB_result.z);
        }

        return size;
    }
}

