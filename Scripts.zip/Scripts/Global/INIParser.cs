using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.InteropServices;
using System.Text;

public class INIParser
{
    [DllImport("kernel32", CharSet = CharSet.Unicode)]
    static extern long WritePrivateProfileString(string Section, string Key, string Value, string FilePath);
    [DllImport("kernel32", CharSet = CharSet.Unicode)]
    static extern int GetPrivateProfileString(string Section, string Key, string Default, StringBuilder RetVal, int Size, string FilePath);

    public static string NetSessionPath = Application.dataPath + "\\..\\Config\\NetSessionInfo.ini";

    public static void Write(string filePath, string section, string key, string value)
    {
        WritePrivateProfileString(section, key, value, filePath);
    }

    public static string Read(string filePath, string section, string key)
    {
        var value = new StringBuilder(255);
        GetPrivateProfileString(section, key, "Error", value, 255, filePath);
        return value.ToString();
    }

}
