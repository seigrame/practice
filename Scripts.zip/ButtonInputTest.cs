using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine;

public class ButtonInputTest : MonoBehaviour
{
    ButtonManager buttonManager;



    // Start is called before the first frame update
    void Start()
    {
        buttonManager = FindObjectOfType<ButtonManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F1))
        {
            //buttonManager.bottomButtons[0].OnSubmit();
            //EventSystem.current.currentInputModule ���� �ϳ� ���ɼ� ����. newInputSystem�� �����غ� �� 
        }
        else if (Input.GetKeyDown(KeyCode.F2))
        {

        }
        else if (Input.GetKeyDown(KeyCode.F3))
        {

        }
        else if (Input.GetKeyDown(KeyCode.F4))
        {

        }
        else if (Input.GetKeyDown(KeyCode.F5))
        {

        }
        else if (Input.GetKeyDown(KeyCode.F6))
        {

        }
        else if (Input.GetKeyDown(KeyCode.F7))
        {

        }
        else if (Input.GetKeyDown(KeyCode.F8))
        {

        }
    }
}
