using UnityEngine.EventSystems;
using UnityEngine;
using TMPro;

public class OnScreenKeyboardInput : MonoBehaviour, IPointerDownHandler
{
    public VirtualKeyBoard targetOnScreenBoard;
    TMP_InputField _InputField;

    // Start is called before the first frame update
    void Start()
    {
        _InputField = null;//Ŭ���Ҷ����� Ŭ���� ������Ʈ�� �Է� ����� �ٲ����

        if (_InputField == null)
        {
            return;
        }
    }



    public void OnPointerDown(PointerEventData eventData)
    {
        if (targetOnScreenBoard)
        {
            targetOnScreenBoard.gameObject.SetActive(true);
        }
    }

}
